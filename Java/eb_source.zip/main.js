var current_word = "";
var loc = window.location;
var server_uri = loc.protocol + "//" + loc.host;
var ws_connect = false;
var myhistory = new History();
var listDictionaryTitleSize = 3;
var searchMethod = 0;
var pro = 0;
var play_sound = -1;
var wordlistComplete = [];
var wordlistComplete_dics = [];
var content_data;
var debug = false;
var send_increment = false;
var keep_increment_word = null ;
var now_searching_word = null ;
var scrolly = 0;
var is_search_empty = false;
var search_text_input_value = null ;
var dics_wordlist = [];
var g_word_emphasize = 1;
var g_history_words = null ;
var use_on_line_history = true;
var isShowSearchFullDialog = false;
var isShowHistoryWordsDialog = false;
var isShowConfirmAddWordDialog = false;
var isShowNotebookPagesDialog = false;
var isShowEditNoteDialog = false;
var isShowConfirmDeleteHighlightDialog = false;
var isShowSearchDicsDialog = false;
var isShowConfirmDeleteWordsDialog = false;
var isShowMenuDialog = false;
var isShowConfirmAddDBDialog = false;
var isShowAddWordDBSelectDialog = false;
var isShowDBSelectDialog = false;
var view_dic_index = -1;
var view_dic_index_map = {};
var view_index_dic_map = {};
var view_dics_size = 0;
var list_itemHeight = 27;
var current_database_file = "word.db";
var only_increment = 1;
var show_highlight_tool = 1;
var locale_language = 3;
var g_dbs = null ;
var serializedHighlights = decodeURIComponent(window.location.search.slice(window.location.search.indexOf("=") + 1));
var highlighter;
var initialDoc;
var go_history = 0;
var g_on_notebook_page = false;
var g_note_page = -1;
var g_note_offset = -1;
var g_note_book_index = -1;
var g_note_keyword = "";
var g_note_db_name = "";
var g_note_custom_word_row_id = -1;
var g_end_page = -1;
var g_end_offset = -1;
var g_end_book_index = -1;
var g_menu_list = null ;
var g_image_menu_list = null ;
var g_menu_list_index = null ;
var g_image_menu_list_index = null ;
var g_checkbox = false;
var g_checkbox_items = [];
var g_enable_resize = 1;
var g_highlight_show = false;
var g_rom_to_hina = 0;
var g_multi_rom_to_hina = 1;
var g_notebook_db_pos = -1;
var g_tnw = 0;
var g_add_btn_long_press = false;
var g_note_btn_long_press = false;
var g_highlight_btn_long_press = false;
var g_search_btn_long_press = false;
var g_word_tag_width = 5;
var g_dialog_listitem_heigh = 22;
var g_dialog_list_font_size = 14;
var g_haveMultSearchiInDics = 0;
var g_haveMenuInDics = 0;
var g_haveImageMenuInDics = 0;
var g_haveCopyRightInDics = 0;
var g_haveEpwingInDics = 0;
var g_haveStarDicInDics = 0;
var g_haveMDicInDics = 0;
var g_use_full_search = 0;
var g_notebook_row_id = -1;
var g_use_search_mode_hightlight = true;
var g_highlight_offset_search = 0;
var g_highlight_offset_note = 0;
var g_test_highlight = false;
var g_calc_highlight_offset = 152;
var g_tnw_list_ui = true;
var g_max_page_offset_diff = 15;
var g_checkbox_selectIndex = -1;
var g_web_sites_name_list = null ;
var g_web_sites_url_list = null ;
var g_web_sites_font_size_list = null ;
var g_note_row_id = -1;
var g_cutom_word_content = "";
var g_cutom_word_name = "";
var go_position_label = "";
var g_init = true;
var g_delay_go_to_settings = true;
var g_scroll_bar_width;
var g_add_word_url = "";
var g_dics_type = [];
var g_dics_ids = [];
var g_dics_names = [];
var g_highlight_color = 0;
var g_highlight_check_timer = null ;
var g_stop_highlight_over = false;
var g_dynamic_highlight_tool = false;
var g_flash_card_row_id = -1;
var g_searchModeAddHighlight = true;
var g_add_history_timer = null ;
var isOpera = !!window.opera || navigator.userAgent.indexOf(" OPR/") >= 0;
var isFirefox = typeof InstallTrigger !== "undefined";
var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf("Constructor") > 0;
var isChrome = !!window.chrome && !isOpera;
var isIE = false || !!document.documentMode;
function initWebSocket() {
    webSocket.open = function() {
        ws_connect = true;
        log("Websocket connect");
        handleWidgetFlashCardEvent("connect", 1);
        mode = 1;
        if (ebdic_mode == 2) {
            mode = 2
        }
        webSocket.send({
            cmd: "req_set_status_mode",
            data: mode
        });
        if ($("#debug_btn") && debug == true) {
            $("#debug_btn").html("start");
            label = $("#debug_text").val();
            console.log("[debug click] label=" + label);
            webSocket.send({
                cmd: "req_get_debug_info",
                data: label,
                on: "1"
            })
        }
    }
    ;
    webSocket.error = function(a) {
        log("Server Error %0", a);
        toastr.options.timeOut = 0;
        toastr.error("WebSocket Close!! error = " + a);
        toastr.options.timeOut = 2000
    }
    ;
    webSocket.close = function() {
        log("WebSocket Close");
        setDisconnect(true);
        ws_connect = false;
        poll_timer = null ;
        handleWidgetFlashCardEvent("connect", 0);
        (function a() {
            poll_timer = setTimeout(function() {
                $.ajax({
                    url: "/ajax",
                    type: "POST",
                    data: {
                        cmd: "req_server_is_alive"
                    },
                    success: function(c) {
                        clearTimeout(poll_timer);
                        send_increment = false;
                        keep_increment_word = null ;
                        g_search_dics = null ;
                        g_search_dic_index = -2;
                        setStatus(0);
                        setDisconnect(false);
                        if (!ws_connect) {
                            webSocket.stop();
                            webSocket = jWebSocketDelegate(loc.host, true);
                            webSocket.start();
                            initWebSocket();
                            if (ws) {
                                g_init = false;
                                ws.send({
                                    cmd: "req_get_theme",
                                    data: "1"
                                });
                                ws.send({
                                    cmd: "req_settings_data"
                                });
                                ws.send({
                                    cmd: "req_get_history_words"
                                })
                            }
                        }
                    },
                    error: function(e, c, d) {
                        a()
                    }
                })
            }, 1000)
        })()
    }
    ;
    webSocket.addResponseEvent("rsp_get_web_search_site_list", function(a) {
        g_web_sites_name_list = [];
        g_web_sites_url_list = [];
        g_web_sites_font_size_list = [];
        ws.send({
            cmd: "req_get_web_search_site_list",
            type: 1
        });
        closeConfirmDeleteWebSearchDialog();
        closeEditWebSearchDialog();
        closeWebSearchDialog()
    });
    webSocket.addResponseEvent("rsp_flash_card", function(d, c) {
        var e = c.sub_cmd;
        var a = c.datas;
        handleWidgetFlashCardEvent(e, a)
    });
    webSocket.addResponseEvent("rsp_get_debug_info", function(d, c) {
        var e = c.data;
        var a = c.loop;
        if (e) {
            console.log("[d] " + e)
        }
        if (a) {
            return
        }
        status = c.status;
        if (status && status == 0) {
            $("#debug_btn").html("start");
            debug = false;
            console.log("[d] debug =" + debug)
        } else {
            $("#debug_btn").html("stop");
            debug = true
        }
    });
    webSocket.addResponseEvent("rsp_get_theme", function(c, a) {
        t_theme_type = a.data;
        log("t_theme_type=" + t_theme_type);
        log("theme_type=" + theme_type);
        if (theme_type != t_theme_type) {
            changeTheme(t_theme_type);
            handleWidgetFlashCardEvent("settings", {
                theme: g_theme_type
            });
            contentReload()
        }
        theme_type = t_theme_type
    });
    webSocket.addResponseEvent("rsp_update_history_words", function(d, a) {
        if (!use_on_line_history) {
            return
        }
        var e;
        var c = -1;
        if (typeof a.data != "undefined") {
            e = a.data
        }
        if (typeof a.type != "undefined") {
            c = a.type
        }
        if (c == 0) {
            closeHistoryWordsDialog();
            addHistoryWords(e, true)
        } else {
            if (c == 1) {
                closeHistoryWordsDialog();
                deleteHistoryWord(e)
            }
        }
    });
    webSocket.addResponseEvent("rsp_get_history_words", function(c, a) {
        if (!use_on_line_history) {
            return
        }
        g_history_words = [];
        if (typeof a.data != "undefined") {
            g_history_words = a.data
        }
        closeHistoryWordsDialog();
        if (g_autocomplete_show) {
            $("#search_text").autocomplete("close")
        }
        $("#search_text").autocomplete({
            source: g_history_words
        })
    });
    webSocket.addResponseEvent("rsp_play_sound", function(d, a) {
        var e = a.word;
        if (e) {
            var f = $("#audiotag").attr("src");
            $("#audiotag").attr("src", encodeURIComponent(e + ".mp3"));
            f = $("#audiotag").attr("src");
            try {
                document.getElementById("audiotag").play()
            } catch (c) {
                if (locale_language > 2) {
                    toastr.error(res_string_toastr_no_sound_for + _word + '" !!')
                } else {
                    toastr.error('"' + _word + res_string_toastr_no_sound_for)
                }
            }
        }
    });
    webSocket.addResponseEvent("rsp_word_emphasize", function(e, a) {
        var d = a.value;
        if (g_word_emphasize != d) {
            if (ebdic_mode == 1 && g_go_book_index >= 0 && g_go_position) {
                var c = $("#search_text").val().trim();
                ws.send({
                    cmd: "req_go_to_eb_position",
                    data: g_go_position,
                    scrolly: scrolly,
                    keyword: c
                })
            }
        }
        g_word_emphasize = d
    });
    webSocket.addResponseEvent("rsp_db_op_change", function(e, a) {
        var f = a.page;
        var g = a.add;
        var d = a.total_page;
        if (ebdic_mode == 2 && ((f == -2 || f == -8) || (currentPage == f + 1) || (currentPage > d))) {
            if (currentPage > d) {
                currentPage = d
            }
            closeAllDBDialogs();
            if (g == 4) {
                if (g_go_page == -2) {
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage,
                        type: 2
                    })
                } else {
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage,
                        type: 1
                    })
                }
            } else {
                if (f == -8) {
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage,
                        type: 1
                    })
                } else {
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage
                    })
                }
            }
        } else {
            if (g_use_search_mode_hightlight && ebdic_mode == 1 && g_go_book_index >= 0 && g_go_position && f != -8) {
                var c = $("#search_text").val().trim();
                ws.send({
                    cmd: "req_go_to_eb_position",
                    data: g_go_position,
                    scrolly: scrolly,
                    keyword: c
                })
            } else {
                if (ebdic_mode == 2) {
                    changeCurrentDB(current_database_file, currentPage, d)
                }
            }
        }
    });
    webSocket.addResponseEvent("rsp_pro_change", function(c, a) {
        var d = a.data;
        if (pro != d) {
            pro = d;
            updatePro()
        }
    });
    webSocket.addResponseEvent("rsp_get_search_method", function(c, a) {
        searchMethod = a.data;
        log("searchMethod=" + searchMethod);
        updateSearchMethod()
    });
    webSocket.addResponseEvent("rsp_get_web_search_method", function(c, a) {
        if (typeof a.value != "undefined") {
            g_use_web_search_in_ebdic = a.value
        }
    });
    webSocket.addResponseEvent("rsp_get_dictionary_title_size", function(c, a) {
        if (typeof a.value != "undefined") {
            listDictionaryTitleSize = a.value;
            handleWidgetFlashCardEvent("settings", {
                title_size: listDictionaryTitleSize
            })
        }
    });
    webSocket.addResponseEvent("rsp_highlight_change", function(a, o) {
        var l = -1;
        var g = -1;
        var c = -1;
        var e = -1;
        l = o.page;
        g = o.offset;
        c = o.book_index;
        e = o.note_row_id;
        var f = false;
        if (g_go_page >= 0 || (g_go_page == -1 && g_go_book_index >= 0 && g_go_offset >= 0)) {
            var m = g_max_page_offset_diff;
            if (c >= 0 && g_dics_type[c] && g_dics_type[c] != 0) {
                m = 0
            }
            var n = (g_go_offset >= g ? g_go_offset - g : g - g_go_offset);
            if (g_go_page == l && n <= m && g_go_book_index == c) {
                f = true
            }
        } else {
            if (g_go_page == -2) {
                if (l == -2 && e == g_note_row_id) {
                    f = true
                }
            } else {
                if (g_go_page == -3) {
                    if (l == -3 && e == g_note_row_id) {
                        f = true
                    }
                }
            }
        }
        if (f) {
            if ((g_go_note == 1 && g_go_history == 0 && ebdic_mode == 2) || (g_use_search_mode_hightlight && ebdic_mode == 1)) {
                closeAllDBDialogs();
                var d = $("#search_text").val().trim();
                ws.send({
                    cmd: "req_go_to_eb_position",
                    data: g_go_position,
                    scrolly: scrolly,
                    keyword: d
                })
            }
        }
    });
    webSocket.addResponseEvent("rsp_dics_selection_change", function(c, a) {
        index = a.index;
        g_search_dics = null ;
        g_search_dic_index = -2;
        closeSearchDicsDialog()
    });
    webSocket.addResponseEvent("rsp_highlight_color_change", function(c, a) {
        g_highlight_color = a.hightLightColor;
        setHighlightColorImg(g_highlight_color)
    });
    webSocket.addResponseEvent("rsp_get_search_full_info", function(c, a) {
        dic_name = "";
        progress = -1;
        total_hits = -1;
        dic_hits = -1;
        dic_name = a.dic_name;
        progress = a.progress;
        total_hits = a.total_hits;
        dic_hits = a.dic_hits;
        if (isShowSearchFullDialog) {
            $("#dialog-message").dialog("option", "title", dic_name + " (" + dic_hits + ")");
            $("#search_full_progress").text(progress);
            $("#search_full_dic_hits").text(total_hits);
            $("#progressbar").progressbar("option", "value", progress)
        }
    });
    webSocket.addResponseEvent("rsp_page_size", function(c, a) {
        t_page_size = a.data;
        log("t_page_size=" + t_page_size);
        currentPage = -1;
        closeNotebookPagesDialog();
        if (ebdic_mode == 2) {
            setStatus(2);
            ws.send({
                cmd: "req_get_note",
                page: currentPage
            })
        }
    });
    webSocket.addResponseEvent("rsp_db_name_change", function(f, c) {
        var a = null ;
        var e = 0;
        if (typeof c.current_database_file != "undefined") {
            a = c.current_database_file
        }
        if (a == current_database_file) {
            return
        }
        if (typeof c.pageCount != "undefined") {
            pageCount = c.pageCount
        }
        if (typeof c.currentPage != "undefined") {
            currentPage = c.currentPage
        }
        if (typeof c.type != "undefined") {
            e = c.type
        }
        if (a) {
            changeCurrentDB(a, currentPage, pageCount)
        }
        currentPage = -1;
        closeAllDBDialogs();
        closeEditCustomWordDialog();
        closeConfirmExitEditCustomWordDialog();
        if (ebdic_mode == 2) {
            setStatus(2);
            ws.send({
                cmd: "req_get_note",
                page: currentPage
            })
        } else {
            if (g_use_search_mode_hightlight && ebdic_mode == 1 && g_go_book_index >= 0 && g_go_position) {
                var d = $("#search_text").val().trim();
                ws.send({
                    cmd: "req_go_to_eb_position",
                    data: g_go_position,
                    scrolly: scrolly,
                    keyword: d
                });
                createCookie("currentPage", currentPage);
                createCookie("current_database_file", current_database_file)
            }
        }
    });
    webSocket.addResponseEvent("rsp_notebook_db_change", function(c, a) {
        isDelete = a.data;
        g_dbs = null ;
        closeAllDBDialogs();
        ws.send({
            cmd: "req_get_notebook_db_file_list",
            type: 0
        })
    });
    webSocket.addResponseEvent("raw_data", function(a) {})
}
var search_methods_items = ["Begin", "End", "Exact", "Cross"];
var search_methods_items_pro = ["Begin", "End", "Exact", "Cross", "Full", "Multi"];
var dialog_title_recent_word_label = "Recent words";
var dialog_title_notebook_pages_label = "Page no.";
var dialog_title_search_dictionaries_label = "Dictionaries groups";
var dialog_title_web_search_label = "Web search";
var res_string_all = "All";
var dialog_full_search_searching_label = "Searching ... ";
var res_string_yahoo = "Web search";
var res_string_play_sound = "Play sound";
var res_string_add_word = "Add the word";
var res_string_backward = "Backward";
var res_string_forward = "Forward";
var res_string_notebook = "Notebook";
var res_string_previous_paragraph = "Previous paragraph";
var res_string_next_paragraph = "Next paragraph";
var res_string_checkboxes = "Checkboxes";
var res_string_delete_note = "Delete words";
var res_string_tag_note = "Tag words";
var res_string_previous_paragraph = "Previous paragraph";
var res_string_next_paragraph = "Next paragraph";
var ui_widget_font_family = "Lucida Grande,Lucida Sans,Arial,sans-serif";
var res_string_toastr_add_success = "Add the word successfully!!";
var res_string_toastr_input_empty = "Input text is empty!!";
var res_string_toastr_unable_connect = "Unable to connect to server!!";
var res_string_toastr_note_connected = "Not connected!!";
var res_string_toastr_not_suppor_video = "Not support for video!!";
var res_string_toastr_no_sound_for = 'No sound for "';
var res_string_toastr_no_menu = "No menu!!";
var res_string_toastr_delete_successfully = "Delete successfully.";
var res_string_toastr_tag_successfully = "Tag successfully.";
var res_string_toastr_no_word_added = "No word can be added!!";
var res_string_toastr_current_db = "The current notebook: ";
var res_string_start_autocomplete = "on";
var res_string_stop_autocomplete = "off";
var dialog_title_add_word = "Add the word";
var dialog_title_delete_highlight = "Delete";
var dialog_message_delete_highlight = "Do you want to delete?";
var dialog_message_delete_highlight_all = "Do you want to delete all?";
var dialog_message_add_word = "The word has already existed!!<br>Do you want to add the word again?";
var dialog_search_label = "Search";
var dialog_ok_label = "OK";
var dialog_add_label = "Add";
var dialog_edit_label = "Edit";
var dialog_delete_label = "Delete";
var dialog_search_label = "Search";
var dialog_backward_label = "Backward";
var dialog_cancel_label = "Cancel";
var dialog_clear_label = "Clear";
var dialog_yes_label = "Yes";
var dialog_no_label = "No";
var dialog_title_edit_note = "Memo";
var dialog_edit_note_tag = "Tag";
var g_menu_type_label = ["menu", "Image menu"];
var dialog_title_menu_label = "menu";
var dialog_title_add_word_db_label = "Which db file to add the word?";
var dialog_title_add_search_word_db_label = "Which db file to add the word for searching?";
var dialog_title_add_cutom_word_db_label = "Which db file to add cutom word for searching?";
var dialog_title_db_select_label = "Select a notebook";
var dialog_title_select_multi_search_dics_label = "Multi Search Dictionaries";
var res_string_add_db_name = "Name:";
var dialog_title_add_db = "Create a notebook";
var res_string_toastr_db_name_invalid = "The name is invalid!!";
var res_string_toastr_db_name_existed = "The name has existed!!";
var res_string_toastr_add_db_successfully = "Create notebook successfully!!";
var res_string_rom_to_hira = "Romaji -> Hiragana";
var res_string_romaji = "Romaji";
var res_string_websearch_name_label = "Name:";
var res_string_websearch_url_label = "URL:";
var res_string_toastr_input_invalid = "The field is empty!!";
var res_string_toastr_web_site_incorrect_url = "URL is invalid!!";
var res_string_edit_custom_word_heading = "Heading:";
var res_string_edit_ebidc_word_heading = "Keyword:";
var res_string_edit_word_use_html_label = "html";
var dialog_title_add_custom_word_label = "Add a custom word";
var dialog_title_edit_custom_word_label = "Edit the word";
var res_string_add_custom_word_successfully = "Add a custom word successfully.";
var res_string_update_custom_word_successfully = "Edit the custom word successfully.";
var dialog_confirm_custom_word_exit_title = "Do you want to stop editing?";
var res_string_confirm_exit = "Confirm";
var res_string_toastr_edit_word_not_exist = "The edited word has not existed!!";
var res_string_choice_custom_word = "Custom word";
var res_string_choice_web_search = "Web search";
var res_string_choice_search_word = "Search word";
var res_string_toast_notebook_operation_busy = "The operations of the notebook is busy!!";
var res_string_toast_please_do_web_search_setting = "The Web search is not set up on the device";
var res_string_toastr_unable_add_web_search = "Unable to add a word for web search!!";
var res_string_highlight = "Highlight";
var res_string_memo = "Memo";
var res_string_earser = "Earser";
var res_string_clear = "clear";
var dialog_title_choice_highlight_color = "Highlight color";
var res_string_highlight_green = "Green highlight";
var res_string_highlight_orange = "Orange highlight";
var res_string_highlight_blue = "Blue highlight";
var item_title_search_word = "Word";
var item_title_web_search = "Web search";
var item_title_custom_word = "Notebook";
var res_string_toastr_keyword_is_empty = "Keyword is empty!!";
var res_discard_highlight = "Discard highlights?";
function updateLocale(a) {
    if (a == locale_language) {
        return
    }
    locale_language = a;
    if (locale_language == 0) {
        search_methods_items = ["前方一致", "後方一致", "完全一致", "クロス"];
        search_methods_items_pro = ["前方一致", "後方一致", "完全一致", "クロス", "全文", "複合"];
        dialog_title_recent_word_label = "検索語履歴";
        dialog_title_add_word = "単語の追加";
        dialog_message_add_word = "単語がもうあります!!<br>もう一度追加しますか？";
        dialog_title_notebook_pages_label = "単語帳のページ";
        dialog_title_search_dictionaries_label = "辞書グループ";
        dialog_title_web_search_label = "Web検索";
        dialog_search_label = "検索";
        dialog_ok_label = "OK";
        dialog_add_label = "新規作成";
        dialog_edit_label = "編輯";
        dialog_delete_label = "削除";
        dialog_search_label = "検索";
        dialog_backward_label = "戻る";
        dialog_cancel_label = "キャンセル";
        dialog_clear_label = "クリア";
        dialog_yes_label = "はい";
        dialog_no_label = "いいえ";
        res_string_all = "すべて";
        dialog_full_search_searching_label = "検索中 ... ";
        res_string_yahoo = "Web検索";
        res_string_play_sound = "プレイサウンド";
        res_string_add_word = "単語の追加";
        res_string_backward = "戻る";
        res_string_forward = "進む";
        res_string_notebook = "単語帳";
        res_string_previous_paragraph = "前の段落";
        res_string_next_paragraph = "次の段落";
        res_string_checkboxes = "チェックボックス";
        res_string_delete_note = "単語の削除";
        res_string_tag_note = "単語のタグ";
        ui_widget_font_family = "メイリオ,ＭＳ Ｐゴシック,ＭＳ Ｐ明朝,Lucida Grande,Lucida Sans,Arial,sans-serif";
        res_string_toastr_add_success = "単語の追加が成功しました!!";
        res_string_toastr_input_empty = "入力されていません!!";
        res_string_toastr_unable_connect = "ウェブサービスが繋がりません!!";
        res_string_toastr_note_connected = "繋がっていません!!";
        res_string_toastr_not_suppor_video = "動画に対応していません!!";
        res_string_toastr_no_sound_for = '"の音声ファイルがありません!!';
        res_string_toastr_no_menu = "メニューがありません!!";
        res_string_toastr_delete_successfully = "削除しました。";
        res_string_toastr_tag_successfully = "タグの編輯が完成しました。";
        res_string_toastr_no_word_added = "単語の追加ができません!!";
        res_string_toastr_current_db = "単語帳: ";
        res_string_start_autocomplete = "が起動しました。";
        res_string_stop_autocomplete = "が停止しました。";
        dialog_title_edit_note = "メモ";
        dialog_title_delete_highlight = "ハイライトの削除";
        dialog_message_delete_highlight = "削除しますか?";
        dialog_message_delete_highlight_all = "全て削除しますか?";
        dialog_edit_note_tag = "タグ";
        g_menu_type_label = ["メニュー", "図版メニュー"];
        dialog_title_menu_label = "メニュー";
        dialog_title_add_word_db_label = "どの単語帳に追加しますか？";
        dialog_title_add_search_word_db_label = "どの単語帳に検索語を追加しますか？";
        dialog_title_add_cutom_word_db_label = "どの単語帳にカスタム単語を追加しますか？";
        dialog_title_db_select_label = "単語帳の選び";
        dialog_title_select_multi_search_dics_label = "複合検索の辞書";
        res_string_add_db_name = "名前:";
        dialog_title_add_db = "単語帳の作成";
        res_string_toastr_db_name_invalid = "無効のネーム!!";
        res_string_toastr_db_name_existed = "そのネームはもうあります!!";
        res_string_toastr_add_db_successfully = "単語帳を作成しました。";
        res_string_rom_to_hira = "ローマ字 -> ひらがな";
        res_string_romaji = "ローマ字";
        res_string_websearch_name_label = "名前:";
        res_string_websearch_url_label = "URL:";
        res_string_toastr_input_invalid = "入力されていません!!";
        res_string_toastr_web_site_incorrect_url = "URLは無効です!!";
        res_string_edit_custom_word_heading = "見出し:";
        res_string_edit_ebidc_word_heading = "キーワード:";
        res_string_edit_word_use_html_label = "html";
        dialog_title_add_custom_word_label = "カスタム単語の作成";
        dialog_title_edit_custom_word_label = "単語の編輯";
        res_string_add_custom_word_successfully = "カスタム単語の作成が成功しました。";
        res_string_update_custom_word_successfully = "カスタム単語の編輯が成功しました。";
        dialog_confirm_custom_word_exit_title = "編輯をやめますか？";
        res_string_confirm_exit = "確認";
        res_string_toastr_edit_word_not_exist = "編輯の単語はもうありません!!";
        res_string_choice_custom_word = "カスタム単語";
        res_string_choice_web_search = "Web検索";
        res_string_choice_search_word = "検索語";
        res_string_toast_notebook_operation_busy = "単語帳の編輯は処理中です!!";
        res_string_toast_please_do_web_search_setting = "装置でWeb検索の設定をしてください!!";
        res_string_toastr_unable_add_web_search = "Web検索で単語を追加すことが!!";
        res_string_highlight = "ハイライト";
        res_string_memo = "メモ";
        res_string_earser = "消しゴム";
        res_string_clear = "全削除";
        res_string_highlight_green = "緑色　ハイライト";
        res_string_highlight_orange = "オレンジ色　ハイライト";
        res_string_highlight_blue = "青色 ハイライト";
        item_title_search_word = "検索語";
        item_title_web_search = "Web検索";
        item_title_custom_word = "単語帳";
        res_string_toastr_keyword_is_empty = "キーワードが存在しません!!";
        res_discard_highlight = "ハイライトを捨てますか?"
    } else {
        if (locale_language == 1) {
            search_methods_items = ["字首", "字尾", "一致", "交叉"];
            search_methods_items_pro = ["字首", "字尾", "一致", "交叉", "全文", "複合"];
            dialog_title_recent_word_label = "最近查詢的單字";
            dialog_title_add_word = "新增單字";
            dialog_message_add_word = "單字已經存在!!<br>確定要再一次新增嗎？";
            dialog_title_notebook_pages_label = "單字帳頁碼";
            dialog_title_search_dictionaries_label = "字典群組";
            dialog_title_web_search_label = "Web查詢";
            dialog_search_label = "查詢";
            dialog_ok_label = "確定";
            dialog_add_label = "新增";
            dialog_edit_label = "編輯";
            dialog_delete_label = "刪除";
            dialog_search_label = "查詢";
            dialog_backward_label = "返回";
            dialog_cancel_label = "取消";
            dialog_clear_label = "清除";
            dialog_yes_label = "是的";
            dialog_no_label = "不要";
            res_string_all = "全部";
            dialog_full_search_searching_label = "搜尋中 ... ";
            res_string_yahoo = "Web查詢";
            res_string_play_sound = "播放聲音";
            res_string_add_word = "新增單字";
            res_string_backward = "往後";
            res_string_forward = "往前";
            res_string_notebook = "單字帳";
            res_string_previous_paragraph = "前一段落";
            res_string_next_paragraph = "下一段落";
            res_string_checkboxes = "選擇框";
            res_string_delete_note = "刪除單字";
            res_string_tag_note = "標記單字";
            ui_widget_font_family = "Lucida Grande,Lucida Sans,Arial,sans-serif";
            res_string_toastr_add_success = "新增單字完成!!";
            res_string_toastr_input_empty = "輸入的欄位是空的!!";
            res_string_toastr_unable_connect = "無法連線到服務器!!";
            res_string_toastr_note_connected = "未連線!!";
            res_string_toastr_not_suppor_video = "不支援影片!!";
            res_string_toastr_no_sound_for = '"　沒有聲音檔!!';
            res_string_toastr_no_menu = "沒有附錄!!";
            res_string_toastr_delete_successfully = "刪除完成";
            res_string_toastr_tag_successfully = "標記操作完成";
            res_string_toastr_no_word_added = "没有單字可以新增!!";
            res_string_toastr_current_db = "單字帳: ";
            res_string_start_autocomplete = "啟動";
            res_string_stop_autocomplete = "停止";
            dialog_title_edit_note = "筆記";
            dialog_title_delete_highlight = "標記刪除";
            dialog_message_delete_highlight = "確定要刪除?";
            dialog_message_delete_highlight_all = "確定要刪除全部?";
            dialog_edit_note_tag = "標簽";
            g_menu_type_label = ["附錄", "圖版附錄"];
            dialog_title_menu_label = "附錄";
            dialog_title_add_word_db_label = "新增在哪個單字帳?";
            dialog_title_add_search_word_db_label = "新增檢索語在哪個單字帳?";
            dialog_title_add_cutom_word_db_label = "新增自訂單字在哪個單字帳?";
            dialog_title_db_select_label = "選擇單字帳";
            dialog_title_select_multi_search_dics_label = "複合查詢的字典";
            res_string_add_db_name = "名稱:";
            dialog_title_add_db = "建立單字帳";
            res_string_toastr_db_name_invalid = "無效名稱!!";
            res_string_toastr_db_name_existed = "名稱已存在!!";
            res_string_toastr_add_db_successfully = "單字帳新增完成!!";
            res_string_rom_to_hira = "羅馬字 -> 平假名";
            res_string_romaji = "羅馬字";
            res_string_websearch_name_label = "名稱:";
            res_string_websearch_url_label = "URL:";
            res_string_toastr_input_invalid = "輸入的欄位是空的!!";
            res_string_toastr_web_site_incorrect_url = "URL 無効!!";
            res_string_edit_custom_word_heading = "標題:";
            res_string_edit_ebidc_word_heading = "關鍵字:";
            res_string_edit_word_use_html_label = "html";
            dialog_title_add_custom_word_label = "自訂單字";
            dialog_title_edit_custom_word_label = "編輯單字";
            res_string_add_custom_word_successfully = "自訂單字完成";
            res_string_update_custom_word_successfully = "編輯自訂單字完成";
            dialog_confirm_custom_word_exit_title = "確定要放棄編輯?";
            res_string_confirm_exit = "確認";
            res_string_toastr_edit_word_not_exist = "編輯的單字已不存在!!";
            res_string_choice_custom_word = "自訂單字";
            res_string_choice_web_search = "Web查詢";
            res_string_choice_search_word = "查詢語";
            res_string_toast_notebook_operation_busy = "單字帳的操作正處理中!!";
            res_string_toast_please_do_web_search_setting = "Web查询還沒在裝置上作設定!!";
            res_string_toastr_unable_add_web_search = "無法在Web查询新增單字!!";
            res_string_highlight = "螢光筆";
            res_string_memo = "筆記";
            res_string_earser = "擦除";
            res_string_clear = "全部清除";
            res_string_highlight_green = "綠色 螢光筆";
            res_string_highlight_orange = "橙色 螢光筆";
            res_string_highlight_blue = "藍色 螢光筆";
            item_title_search_word = "查詢語";
            item_title_web_search = "Web查詢";
            item_title_custom_word = "單語帳";
            res_string_toastr_keyword_is_empty = "關鍵字是空的!!";
            res_discard_highlight = "放棄螢光筆的編輯?"
        } else {
            if (locale_language == 2) {
                search_methods_items = ["字首", "字尾", "一致", "交叉"];
                search_methods_items_pro = ["字首", "字尾", "一致", "交叉", "全文", "复合"];
                dialog_title_recent_word_label = "最近查询单字";
                dialog_title_add_word = "新增单字";
                dialog_message_add_word = "单字已经存在!!<br>确定要再一次新增吗？";
                dialog_title_notebook_pages_label = "单字帐页码";
                dialog_title_search_dictionaries_label = "字典群组";
                dialog_title_web_search_label = "Web查询";
                dialog_search_label = "查询";
                dialog_ok_label = "确定";
                dialog_add_label = "新增";
                dialog_edit_label = "编辑";
                dialog_delete_label = "删除";
                dialog_search_label = "查询";
                dialog_backward_label = "返回";
                dialog_cancel_label = "取消";
                dialog_clear_label = "清除";
                dialog_yes_label = "是的";
                dialog_no_label = "不要";
                res_string_all = "全部";
                dialog_full_search_searching_label = "查找中 ... ";
                res_string_yahoo = "Web查询";
                res_string_play_sound = "播放声音";
                res_string_add_word = "新增单字";
                res_string_backward = "往后";
                res_string_forward = "往前";
                res_string_notebook = "单字帐";
                res_string_previous_paragraph = "前一段落";
                res_string_next_paragraph = "下一段落";
                res_string_checkboxes = "选择框";
                res_string_delete_note = "删除单字";
                res_string_tag_note = "标记单字";
                ui_widget_font_family = "Lucida Grande,Lucida Sans,Arial,sans-serif";
                res_string_toastr_add_success = "新增单字完成!!";
                res_string_toastr_input_empty = "输入的栏位是空的!!";
                res_string_toastr_unable_connect = "无法连接到服务器!!";
                res_string_toastr_note_connected = "未连接!!";
                res_string_toastr_not_suppor_video = "不支援視頻!!";
                res_string_toastr_no_sound_for = '"　没有声音档';
                res_string_toastr_no_menu = "没有附录!!";
                res_string_toastr_delete_successfully = "删除完成";
                res_string_toastr_tag_successfully = "标记操作完成";
                res_string_toastr_no_word_added = "没有单字可以新增!!";
                res_string_toastr_current_db = "单字帐: ";
                dialog_title_edit_note = "笔记";
                dialog_title_delete_highlight = "标记删除";
                dialog_message_delete_highlight = "确定要删除?";
                dialog_message_delete_highlight_all = "确定要删除全部?";
                dialog_edit_note_tag = "标签";
                g_menu_type_label = ["附录", "图版附录"];
                dialog_title_menu_label = "附录";
                dialog_title_add_word_db_label = "新增在哪个单字帐?";
                dialog_title_add_search_word_db_label = "新增検索語在哪个单字帐?";
                dialog_title_add_cutom_word_db_label = "新增自订单字在哪个单字帐?";
                dialog_title_db_select_label = "选择单字帐";
                dialog_title_select_multi_search_dics_label = "复合查询的字典";
                res_string_add_db_name = "名称:";
                dialog_title_add_db = "建立单字帐";
                res_string_toastr_db_name_invalid = "无效名称!!";
                res_string_toastr_db_name_existed = "名称已存在!!";
                res_string_toastr_add_db_successfully = "单字帐新增完成!!";
                res_string_start_autocomplete = "起动";
                res_string_stop_autocomplete = "停止";
                res_string_rom_to_hira = "罗马字 -> 平假名";
                res_string_romaji = "罗马字";
                res_string_websearch_name_label = "名称:";
                res_string_websearch_url_label = "URL:";
                res_string_toastr_input_invalid = "输入的栏位是空的!!";
                res_string_toastr_web_site_incorrect_url = "URL 无效!!";
                res_string_edit_custom_word_heading = "标题:";
                res_string_edit_ebidc_word_heading = "关键字:";
                res_string_edit_word_use_html_label = "html";
                dialog_title_add_custom_word_label = "自订单字";
                dialog_title_edit_custom_word_label = "编辑单字";
                res_string_add_custom_word_successfully = "自订单字完成";
                res_string_update_custom_word_successfully = "编辑自订单字完成";
                dialog_confirm_custom_word_exit_title = "确定要放弃编辑?";
                res_string_confirm_exit = "确认";
                res_string_toastr_edit_word_not_exist = "编辑的单字已不存在!!";
                res_string_choice_custom_word = "自订单字";
                res_string_choice_web_search = "Web查询";
                res_string_choice_search_word = "查询语";
                res_string_toast_notebook_operation_busy = "单字帐的操作正处理中!!";
                res_string_toast_please_do_web_search_setting = "Web查询还没在装置上作设定!!";
                res_string_toastr_unable_add_web_search = "无法在Web查询新增单字!!";
                res_string_highlight = "萤光笔";
                res_string_memo = "笔记";
                res_string_earser = "擦除";
                res_string_clear = "全部清除";
                res_string_highlight_green = "绿色 萤光笔";
                res_string_highlight_orange = "橙色 萤光笔";
                res_string_highlight_blue = "蓝色 萤光笔";
                item_title_search_word = "查询语";
                item_title_web_search = "Web查询";
                item_title_custom_word = "单字帐";
                res_string_toastr_keyword_is_empty = "关键字是空的!!";
                res_discard_highlight = "放弃萤光笔的编辑?"
            } else {
                search_methods_items = ["Begin", "End", "Exact", "Cross"];
                search_methods_items_pro = ["Begin", "End", "Exact", "Cross", "Full", "Multi"];
                dialog_title_recent_word_label = "Recent Words";
                dialog_title_add_word = "Add the word";
                dialog_message_add_word = "The word has already existed!!<br>Do you want to add the word again?";
                dialog_title_notebook_pages_label = "Page no.";
                dialog_title_search_dictionaries_label = "Dictionaries groups";
                dialog_title_web_search_label = "Web search";
                dialog_search_label = "Search";
                dialog_ok_label = "OK";
                dialog_add_label = "Add";
                dialog_edit_label = "Edit";
                dialog_delete_label = "Delete";
                dialog_search_label = "Search";
                dialog_backward_label = "Backward";
                dialog_cancel_label = "Cancel";
                dialog_clear_label = "Clear";
                dialog_yes_label = "Yes";
                dialog_no_label = "No";
                res_string_all = "All";
                dialog_full_search_searching_label = "Searching ... ";
                res_string_yahoo = "Web search";
                res_string_play_sound = "Play sound";
                res_string_add_word = "Add the word";
                res_string_backward = "Backward";
                res_string_forward = "Forward";
                res_string_notebook = "Notebook";
                res_string_previous_paragraph = "Previous paragraph";
                res_string_next_paragraph = "Next paragraph";
                res_string_checkboxes = "Checkboxes";
                res_string_delete_note = "Delete words";
                res_string_tag_note = "Tag words";
                ui_widget_font_family = "Lucida Grande,Lucida Sans,Arial,sans-serif";
                res_string_toastr_add_success = "Add the word successfully!!";
                res_string_toastr_input_empty = "Input text is empty!!";
                res_string_toastr_unable_connect = "Unable to connect to server!!";
                res_string_toastr_note_connected = "Not connected!!";
                res_string_toastr_not_suppor_video = "Not support for video!!";
                res_string_toastr_no_sound_for = 'No sound for "';
                res_string_toastr_no_menu = "No menu!!";
                res_string_toastr_delete_successfully = "Delete successfully.";
                res_string_toastr_tag_successfully = "Tag successfully.";
                res_string_toastr_no_word_added = "No word can be added!!";
                res_string_toastr_current_db = "The current notebook: ";
                dialog_title_edit_note = "Memo";
                dialog_title_delete_highlight = "Delete highlight";
                dialog_message_delete_highlight = "Do you want to delete?";
                dialog_message_delete_highlight_all = "Do you want to delete all?";
                dialog_edit_note_tag = "Tag";
                g_menu_type_label = ["Menu", "Image menu"];
                dialog_title_menu_label = "Menu";
                dialog_title_add_word_db_label = "Which db file to add the word?";
                dialog_title_add_search_word_db_label = "Which db file to add the word for searching?";
                dialog_title_add_cutom_word_db_label = "Which db file to add the custom word for searching?";
                dialog_title_db_select_label = "Select a notebook";
                dialog_title_select_multi_search_dics_label = "Multi search dictionaries";
                res_string_add_db_name = "Name:";
                dialog_title_add_db = "Create a notebook";
                res_string_toastr_db_name_invalid = "The name is invalid!!";
                res_string_toastr_db_name_existed = "The name has existed!!";
                res_string_toastr_add_db_successfully = "Create notebook successfully!!";
                res_string_start_autocomplete = "on";
                res_string_stop_autocomplete = "off";
                res_string_rom_to_hira = "Romaji -> Hiragana";
                res_string_romaji = "Romaji";
                res_string_websearch_name_label = "Name:";
                res_string_websearch_url_label = "URL:";
                res_string_toastr_input_invalid = "The field is empty!!";
                res_string_toastr_web_site_incorrect_url = "URL is invalid!!";
                res_string_edit_custom_word_heading = "Heading:";
                res_string_edit_ebidc_word_heading = "Keyword:";
                res_string_edit_word_use_html_label = "html";
                dialog_title_add_custom_word_label = "Add a custom word";
                dialog_title_edit_custom_word_label = "Edit the word";
                res_string_add_custom_word_successfully = "Add a custom word successfully.";
                res_string_update_custom_word_successfully = "Edit the custom word successfully.";
                dialog_confirm_custom_word_exit_title = "Do you want to stop editing?";
                res_string_confirm_exit = "Confirm";
                res_string_toastr_edit_word_not_exist = "The edited word has not existed!!";
                res_string_choice_custom_word = "Custom word";
                res_string_choice_web_search = "Web search";
                res_string_choice_search_word = "Search word";
                res_string_toast_notebook_operation_busy = "The operations of the notebook is busy!!";
                res_string_toast_please_do_web_search_setting = "The Web search is not set up on the device!!";
                res_string_toastr_unable_add_web_search = "Unable to add a word for web search!!";
                res_string_highlight = "Highlight";
                res_string_memo = "Memo";
                res_string_earser = "Earser";
                res_string_clear = "clear";
                res_string_highlight_green = "Green highlight";
                res_string_highlight_orange = "Orange highlight";
                res_string_highlight_blue = "Blue highlight";
                item_title_search_word = "Word";
                item_title_web_search = "Web search";
                item_title_custom_word = "Notebook";
                res_string_toastr_keyword_is_empty = "Keyword is empty!!";
                res_discard_highlight = "Discard highlights?"
            }
        }
    }
    update_setting_locale();
    updatePro();
    updateSearchMethod();
    updateRomHina();
    $("#history_btn").attr("title", dialog_title_recent_word_label);
    $("#yahoo_btn").attr("title", res_string_yahoo);
    $("#dics_btn").attr("title", dialog_title_search_dictionaries_label);
    $("#play_btn").attr("title", res_string_play_sound);
    $("#add_btn").attr("title", res_string_add_word);
    $("#setting_btn").attr("title", settings_title);
    $("#prev_btn").attr("title", res_string_backward);
    $("#next_btn").attr("title", res_string_forward);
    $("#left_left_btn").attr("title", "");
    $("#left_btn").attr("title", "");
    $("#note_btn").attr("title", res_string_notebook);
    $("#pages_btn").attr("title", dialog_title_notebook_pages_label);
    $("#right_btn").attr("title", "");
    $("#right_right_btn").attr("title", "");
    $("#memo_btn").attr("title", res_string_memo);
    $("#eraser_btn").attr("title", res_string_earser);
    $("#clear_btn").attr("title", res_string_clear);
    $("#menu_btn").attr("title", g_menu_type_label[0]);
    $("#prev_paragraph_btn").attr("title", res_string_previous_paragraph);
    $("#next_paragraph_btn").attr("title", res_string_next_paragraph);
    $("#flashcard_btn").attr("title", dialog_title_add_db);
    $("#checkbox_btn").attr("title", res_string_checkboxes);
    $("#delete_note_btn").attr("title", res_string_delete_note);
    $("#tag_note_btn").attr("title", res_string_tag_note);
    $("#custom_word").attr("title", dialog_title_add_custom_word_label);
    $("#edit_custom_word").attr("title", dialog_title_edit_custom_word_label);
    $("#dialog-settings").css("fontFamily", ui_widget_font_family);
    $("#toast-container").css("fontFamily", ui_widget_font_family)
}
function updatePro() {
    var a = search_methods_items;
    if (g_haveMultSearchiInDics == 0) {
        search_methods_items_pro = search_methods_items_pro.slice(0, 5)
    }
    if (pro == 1 || g_use_full_search == 1) {
        a = search_methods_items_pro
    }
    if (pro != 1) {
        g_searchModeAddHighlight = false
    }
    $("#search_method_select option").remove();
    for (i = 0; i < a.length; i++) {
        $("#search_method_select").append($("<option></option>").attr("value", i).text(a[i]))
    }
    if ((pro == 1 || g_use_full_search == 1) && $("#dics_btn")) {
        $("#dics_btn").show()
    } else {
        if (pro == 0 && g_use_full_search == 0 && $("#dics_btn")) {
            $("#dics_btn").hide()
        }
    }
    if (pro == 1) {
        if (g_haveImageMenuInDics == 0 && g_haveMenuInDics == 0) {
            $("#menu_btn").attr("disabled", true)
        } else {
            $("#menu_btn").attr("disabled", false)
        }
    }
    updateShowHighlightTool(show_highlight_tool)
}
function updateShowHighlightTool(a) {
    isShow = a;
    temp_highlight_show = g_highlight_show;
    if (pro == 0) {
        $("#highlight_btn").hide();
        $("#memo_btn").hide();
        $("#eraser_btn").hide();
        $("#clear_btn").hide();
        $("#prev_paragraph_btn").hide();
        $("#next_paragraph_btn").hide();
        $("#menu_btn").hide();
        $("#flashcard_btn").hide();
        $("#checkbox_btn").hide();
        $("#delete_note_btn").hide();
        $("#tag_note_btn").hide();
        $("#custom_word").hide();
        $("#edit_custom_word").hide();
        temp_highlight_show = false
    } else {
        if (isShow == 0) {
            $("#highlight_btn").hide();
            $("#memo_btn").hide();
            $("#eraser_btn").hide();
            $("#clear_btn").hide();
            $("#prev_paragraph_btn").hide();
            $("#next_paragraph_btn").hide();
            $("#menu_btn").hide();
            $("#flashcard_btn").hide();
            $("#checkbox_btn").hide();
            $("#delete_note_btn").hide();
            $("#tag_note_btn").hide();
            $("#custom_word").hide();
            $("#edit_custom_word").hide();
            temp_highlight_show = false
        } else {
            $("#highlight_btn").show();
            $("#memo_btn").show();
            $("#eraser_btn").show();
            $("#clear_btn").show();
            $("#prev_paragraph_btn").show();
            $("#next_paragraph_btn").show();
            $("#menu_btn").show();
            $("#flashcard_btn").show();
            $("#checkbox_btn").show();
            $("#delete_note_btn").show();
            $("#tag_note_btn").show();
            $("#custom_word").show();
            $("#edit_custom_word").show();
            temp_highlight_show = true
        }
    }
    if (g_highlight_show != temp_highlight_show) {
        g_highlight_show = temp_highlight_show;
        resize(g_list_ratio)
    }
    g_highlight_show = temp_highlight_show
}
function updateSearchMethod() {
    $("#search_method_select").prop("selectedIndex", searchMethod)
}
function checkConnect() {
    if (!ws_connect) {
        toastr.error(res_string_toastr_note_connected)
    }
    return ws_connect
}
function contentReload() {
    location.reload()
}
var webSocket = jWebSocketDelegate(loc.host, true);
initWebSocket();
var useWebsocket = false;
var ws;
if (!useWebsocket) {
    ws = wsajax(loc.host)
} else {
    ws = jWebSocketDelegate(loc.host, true);
    ws.open = function() {
        log("Connectd to server.....")
    }
}
ws.addResponseEvent("rsp_set_web_settings", function(a) {
    setStatus(0)
});
ws.addResponseEvent("rsp_set_highlight_color", function(a) {
    if (typeof rsp.color != "undefined") {
        value = rsp.color
    }
    g_highlight_color = value;
    setHighlightColorImg(g_highlight_color);
    highlightSelectedText(g_highlight_color);
    unSelect();
    SendHighlightString()
});
ws.addResponseEvent("rsp_set_highlight", function(c) {
    result = 0;
    if (typeof rsp.result != "undefined") {
        result = rsp.result
    }
    if (result != 0) {
        if (ebdic_mode == 2) {
            var a = $("#search_text").val().trim();
            ws.send({
                cmd: "req_go_to_eb_position",
                data: g_go_position,
                scrolly: scrolly,
                keyword: a
            })
        } else {
            setStatus(0)
        }
    } else {
        setStatus(0)
    }
});
ws.addResponseEvent("rsp_add_db", function(a) {
    result = 0;
    db_name = "";
    if (typeof rsp.result != "undefined") {
        result = rsp.result
    }
    if (typeof rsp.current_database_file != "undefined") {
        db_name = rsp.current_database_file
    }
    if (result == -1) {
        toastr.error(res_string_toastr_db_name_invalid);
        setStatus(0)
    } else {
        if (result == -2) {
            toastr.error(res_string_toastr_db_name_existed);
            setStatus(0)
        } else {
            if (result == 0) {
                toastr.info(res_string_toastr_add_db_successfully);
                g_dbs = null ;
                changeCurrentDB(db_name);
                currentPage = -1;
                if (ebdic_mode == 2) {
                    setStatus(2);
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage
                    })
                } else {
                    setStatus(0)
                }
            }
        }
    }
});
ws.addResponseEvent("rsp_op_note", function(a) {
    type = 0;
    if (typeof rsp.type != "undefined") {
        type = rsp.type
    }
    if (type == 0) {
        toastr.info(res_string_toastr_delete_successfully);
        ws.send({
            cmd: "req_get_note",
            page: currentPage
        })
    } else {
        ws.send({
            cmd: "req_get_note",
            page: currentPage,
            type: 1
        })
    }
});
ws.addResponseEvent("rsp_get_multi_search_candidates", function(a) {
    setStatus(0);
    entrylist = [];
    if (typeof rsp.entrylist != "undefined") {
        entrylist = rsp.entrylist
    }
    if (typeof rsp.label != "undefined") {
        label = rsp.label
    }
    if (typeof rsp.candidate_id != "undefined") {
        candidate_id = rsp.candidate_id
    }
    showMutiSearchCandidatesDialog(entrylist, candidate_id, label)
});
ws.addResponseEvent("rsp_get_multi_search_info", function(a) {
    setStatus(0);
    if (typeof rsp.book_index != "undefined") {
        book_index = rsp.book_index
    }
    if (typeof rsp.name != "undefined") {
        name = rsp.name
    }
    if (typeof rsp.multi_search_list != "undefined") {
        multi_search_list = rsp.multi_search_list
    }
    if (typeof rsp.multi_search_entry_lists != "undefined") {
        multi_search_entry_lists = rsp.multi_search_entry_lists
    }
    info = {};
    info.multi_search_list = multi_search_list;
    info.multi_search_entry_lists = multi_search_entry_lists;
    info.name = name;
    info.book_index = book_index;
    g_multi_search_dics_info[book_index] = info;
    closeMultiSearchDialog();
    showMultiSearchDialog(info)
});
ws.addResponseEvent("rsp_get_web_search_site_list", function(m) {
    setStatus(0);
    g_web_sites_name_list = [];
    g_web_sites_url_list = [];
    g_web_sites_font_size_list = [];
    var l = 0;
    var c = 0;
    if (typeof rsp.web_sites_name_list != "undefined") {
        g_web_sites_name_list = rsp.web_sites_name_list
    }
    if (typeof rsp.web_sites_url_list != "undefined") {
        g_web_sites_url_list = rsp.web_sites_url_list
    }
    if (typeof rsp.type != "undefined") {
        l = rsp.type
    }
    if (typeof rsp.result != "undefined") {
        c = rsp.result
    }
    var f = g_web_sites_url_list;
    g_web_sites_url_list = [];
    for (i = 0; i < f.length; i++) {
        var d = f[i];
        var a = 0;
        var g = f[i].indexOf("\t");
        if (g >= 0) {
            d = f[i].substring(0, g);
            a = parseInt(f[i].substring(g + 1).trim())
        }
        g_web_sites_url_list.push(d);
        g_web_sites_font_size_list.push(a)
    }
    if (l == 0) {
        if (c == 0) {
            g_web_sites_name_list = null ;
            g_web_sites_url_list = null ;
            toastr.options.timeOut = 0;
            toastr.info(res_string_toast_please_do_web_search_setting);
            toastr.options.timeOut = 2000;
            return
        }
        if (g_web_sites_name_list.length <= 0) {
            var e = "http://search.yahoo.co.jp/search?p=%s \u3068\u306F";
            openWebSearch(e);
            return
        }
        showWebSearchDialog(g_web_sites_name_list, g_web_sites_url_list)
    }
});
ws.addResponseEvent("rsp_get_multi_search_dics", function(a) {
    setStatus(0);
    g_multi_search_dics_list = [];
    g_multi_search_dics_list_index = [];
    if (typeof rsp.multi_search_dics_list != "undefined") {
        g_multi_search_dics_list = rsp.multi_search_dics_list
    }
    if (typeof rsp.multi_search_dics_list_index != "undefined") {
        g_multi_search_dics_list_index = rsp.multi_search_dics_list_index
    }
    if (g_multi_search_dics_list.length <= 0) {
        toastr.info("no available dictionaries for multi search");
        return
    }
    ShowSelectMultiSearchDicsDialog()
});
ws.addResponseEvent("rsp_get_menu_list", function(a) {
    setStatus(0);
    g_menu_list = [];
    g_image_menu_list = [];
    g_menu_list_index = [];
    g_image_menu_list_index = [];
    if (typeof rsp.menu_list != "undefined") {
        g_menu_list = rsp.menu_list
    }
    if (typeof rsp.image_menu_list != "undefined") {
        g_image_menu_list = rsp.image_menu_list
    }
    if (typeof rsp.menu_list_index != "undefined") {
        g_menu_list_index = rsp.menu_list_index
    }
    if (typeof rsp.image_menu_list_index != "undefined") {
        g_image_menu_list_index = rsp.image_menu_list_index
    }
    if (g_menu_list.length <= 0 && g_image_menu_list.length <= 0) {
        toastr.info(res_string_toastr_no_menu);
        return
    }
    showMenuDialog()
});
ws.addResponseEvent("req_prev_paragraph_failed", function(a) {
    setStatus(0)
});
ws.addResponseEvent("req_next_paragraph_failed", function(a) {
    setStatus(0)
});
var g_content_scroll_timer = null ;
ws.addResponseEvent("raw_data", function(L) {
    g_flash_card_row_id = -1;
    g_highlight_data_string = "";
    go_note_status = 0;
    g_add_word_url = "";
    var P = null ;
    highlighter.removeAllHighlights();
    if (g_content_scroll_timer) {
        clearInterval(g_content_scroll_timer);
        g_content_scroll_timer = null
    }
    if (L.data.substring(0, 10) == "highlight:") {
        o = L.data.indexOf(",");
        highlight_len = parseInt(L.data.substring(10, o));
        end = o + 1 + highlight_len;
        P = L.data.substring(o + 1, o + 1 + highlight_len);
        L.data = L.data.substring(o + 1 + highlight_len)
    }
    if (pro == 0) {
        P = null
    }
    if (L.data.substring(0, 7) == "db_pos:") {
        o = L.data.indexOf(",");
        g_notebook_db_pos = parseInt(L.data.substring(7, o));
        L.data = L.data.substring(o + 1)
    }
    if (L.data.substring(0, 8) == "history:") {
        o = L.data.indexOf(",");
        go_history = parseInt(L.data.substring(8, o));
        L.data = L.data.substring(o + 1)
    } else {
        go_history = 0
    }
    if (L.data.substring(0, 4) == "end:") {
        o = L.data.indexOf(",");
        end_info = L.data.substring(4, o);
        infos = end_info.split(":");
        g_end_page = parseInt(infos[0]);
        g_end_offset = parseInt(infos[1]);
        g_end_book_index = parseInt(infos[2]);
        L.data = L.data.substring(o + 1)
    }
    if (L.data.substring(0, 3) == "go:") {
        o = L.data.indexOf(",");
        go_info = L.data.substring(3, o);
        go_infos = go_info.split(":");
        g_go_page = parseInt(go_infos[0]);
        g_go_offset = parseInt(go_infos[1]);
        g_go_book_index = parseInt(go_infos[2]);
        L.data = L.data.substring(o + 1)
    } else {
        if (L.data.substring(0, 8) == "menu_go:") {
            o = L.data.indexOf(",");
            go_info = L.data.substring(8, o);
            go_infos = go_info.split(":");
            g_go_page = parseInt(go_infos[0]);
            g_go_offset = parseInt(go_infos[1]);
            g_go_book_index = parseInt(go_infos[2]);
            myhistory.clear();
            myhistory.add("<ref " + g_go_page + ":" + g_go_offset + ":" + g_go_book_index + ">");
            L.data = L.data.substring(o + 1)
        }
    }
    var a = 0;
    if (L.data.substring(0, 7) == "bottom:") {
        o = L.data.indexOf(",");
        a = parseInt(L.data.substring(7, o));
        L.data = L.data.substring(o + 1)
    } else {
        a = 0
    }
    var J = false;
    if (L.data.substring(0, 7) == "status:") {
        o = L.data.indexOf(",");
        status = parseInt(L.data.substring(7, o));
        L.data = L.data.substring(o + 1);
        if (status == 1) {
            P = null ;
            if (go_history == 0) {}
            setDicNotExist()
        } else {
            if (status == 3) {
                J = true
            }
        }
    }
    g_notebook_row_id = -1;
    if (L.data.substring(0, 7) == "row_id:") {
        o = L.data.indexOf(",");
        g_notebook_row_id = parseInt(L.data.substring(7, o));
        L.data = L.data.substring(o + 1)
    }
    if (L.data.substring(0, 12) == "note_row_id:") {
        o = L.data.indexOf(",");
        g_note_row_id = parseInt(L.data.substring(12, o));
        L.data = L.data.substring(o + 1)
    }
    if (L.data.substring(0, 18) == "flash_card_row_id:") {
        o = L.data.indexOf(",");
        g_flash_card_row_id = parseInt(L.data.substring(18, o));
        L.data = L.data.substring(o + 1)
    }
    go_position_label = "";
    if (L.data.substring(0, 6) == "label:") {
        o = L.data.indexOf(",");
        var C = parseInt(L.data.substring(6, o));
        end = o + 1 + C;
        go_position_label = L.data.substring(o + 1, o + 1 + C);
        L.data = L.data.substring(o + 1 + C + 1)
    }
    if (L.data.substring(0, 8) == "hitWord:") {
        o = L.data.indexOf(",");
        var C = parseInt(L.data.substring(8, o));
        end = o + 1 + C;
        var f = L.data.substring(o + 1, o + 1 + C);
        L.data = L.data.substring(o + 1 + C + 1);
        if (f && ebdic_mode == 1) {
            $("#search_text").val(f)
        }
    }
    var q = null ;
    if (L.data.substring(0, 7) == "anchor:") {
        o = L.data.indexOf(",");
        var C = parseInt(L.data.substring(7, o));
        end = o + 1 + C;
        q = L.data.substring(o + 1, o + 1 + C);
        L.data = L.data.substring(o + 1 + C + 1)
    }
    var N = null ;
    if (L.data.substring(0, 15) == "convertChinese:") {
        o = L.data.indexOf(",");
        var C = parseInt(L.data.substring(15, o));
        end = o + 1 + C;
        N = L.data.substring(o + 1, o + 1 + C);
        L.data = L.data.substring(o + 1 + C + 1)
    }
    var g = L.data;
    var o = g.indexOf(",");
    var R = g.substring(0, o);
    var H = R.split(":");
    var A = 0;
    is_search_empty = false;
    if (!useWebsocket && g.substring(o, o + 6) != ",data:") {
        var E = g.substring(o + 6);
        o = E.indexOf("},data:");
        g = E;
        E = E.substring(0, o + 1);
        var M;
        var I = false;
        if (g.substring(o + 6 + 1) == "<stop>") {
            I = true
        }
        try {
            M = $.parseJSON(E)
        } catch (l) {
            log("json parse error [" + l.message + "]")
        }
        if (M && (typeof M.cmd != "undefined") && !I) {
            var m = M.cmd;
            if (ws.rspCmdMap[m]) {
                var L = {};
                L.data = E;
                ws.rspCmdMap[m](L, M)
            }
        }
        if (I) {
            send_increment = false;
            if (keep_increment_word != null ) {
                log("search keep_increment_word=" + keep_increment_word);
                setStatus(1);
                g_multi_search_words = null ;
                if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
                    ws.send({
                        cmd: "req_search",
                        data: convertToKana(keep_increment_word),
                        data2: romnih(keep_increment_word),
                        increment: only_increment,
                        from_increment: 1
                    })
                } else {
                    ws.send({
                        cmd: "req_search",
                        data: convertToKana(keep_increment_word),
                        increment: only_increment,
                        from_increment: 1
                    })
                }
                send_increment = true;
                keep_increment_word = null
            }
        }
        if (M && (typeof M.scrolly != "undefined") && !I) {
            A = M.scrolly
        }
        o++
    }
    var S = g.substring(o + 6);
    if (S == "<increment>" || S == "<stop>") {
        if (!send_increment) {
            setStatus(0)
        }
        closeSearchFullDialog();
        return
    }
    if (H[1] == "rsp_search") {
        content_data = S;
        if (g_go_page) {
            g_cutom_word_content = content_data
        } else {
            g_cutom_word_content = ""
        }
        keyword = $("#search_text").val();
        KEYWORD_COLOR = 16217088;
        if (theme_type == 1) {
            KEYWORD_COLOR = 12262165
        }
        $("#content").css("overflow-y", "scroll");
        $("#content").css("overflow-x", "auto");
        var d = -1;
        if (g_go_book_index >= 0) {
            d = g_dics_type[g_go_book_index]
        }
        if (g_go_page == -4) {
            var z = "";
            if (settings_web_search_in_new_tab == 1) {
                var e = "<br><br><div style='margin: 0 auto; text-align: center;'><a target='_blank' href='" + S + "'>" + S + "</a></div>";
                $("#content").html(e);
                g_add_word_url = S
            } else {
                z = '<iframe id="content_iframe" width="100%" height="100%" scrolling="yes" frameborder="no"></iframe>';
                $("#content").css("overflow-y", "hidden");
                $("#content").css("overflow-x", "hidden");
                $("#content").html(z);
                initIframe();
                changeIFrameUrl(S)
            }
        } else {
            if (ebdic_mode == 2) {
                if (g_go_page == -2) {
                    showContent(S)
                } else {
                    S = autoLinkSearchWord(S, d);
                    showContent(S)
                }
            } else {
                if (g_multi_search_words != null ) {
                    S = EmphasizeSearchWord(N, autoLinkSearchWord(S, d), keyword, KEYWORD_COLOR, g_multi_search_words);
                    showContent(S)
                } else {
                    S = EmphasizeSearchWord(N, autoLinkSearchWord(S, d), keyword, KEYWORD_COLOR);
                    showContent(S)
                }
            }
        }
        if (g_tnw == 0) {
            if (theme_type == 1) {
                if (g_dics_type[g_go_book_index] == 1) {
                    $("#content a[href]").css("color", "#0000ff").css("text-decoration", "none").css("border-bottom", "1px dashed")
                } else {
                    if (g_dics_type[g_go_book_index] == 2) {
                        $("#content a[href]").css("color", "#0000ff").css("text-decoration", "underline")
                    } else {
                        if (g_dics_type[g_go_book_index] == 0) {
                            $("#content a[href]").css("color", "#0000ff").css("text-decoration", "none")
                        }
                    }
                }
                $(".keysearch").css("color", "#BB1B15")
            } else {
                if (g_dics_type[g_go_book_index] == 1) {
                    $("#content a[href]").css("color", "#33b5e5").css("text-decoration", "none").css("border-bottom", "1px dashed")
                } else {
                    if (g_dics_type[g_go_book_index] == 2) {
                        $("#content a[href]").css("color", "#33b5e5").css("text-decoration", "underline")
                    } else {
                        if (g_dics_type[g_go_book_index] == 0) {
                            $("#content a[href]").css("color", "#33b5e5").css("text-decoration", "none")
                        }
                    }
                }
                $(".keysearch").css("color", "#F77400")
            }
        } else {
            if (theme_type == 1) {
                if (g_dics_type[g_go_book_index] != 0) {
                    $("#content a[href]").css("color", "#0000ff").css("text-decoration", "none").css("border-bottom", "1px dashed")
                } else {
                    $("#content a[href]").css("color", "#0000ff").css("text-decoration", "none")
                }
                $(".keysearch").css("color", "#BB1B15")
            } else {
                if (g_dics_type[g_go_book_index] != 0) {
                    $("#content a[href]").css("color", "#33b5e5").css("text-decoration", "none").css("border-bottom", "1px dashed")
                } else {
                    $("#content a[href]").css("color", "#33b5e5").css("text-decoration", "none")
                }
                $(".keysearch").css("color", "#F77400")
            }
        }
        updateCSS();
        updateTitle()
    }
    if (q != null ) {
        var D = document.getElementById("content");
        var x = document.getElementById(q);
        if (x) {
            x.scrollIntoView()
        } else {
            var u = document.getElementsByName(q);
            if (u && u.length > 0) {
                u[0].scrollIntoView()
            }
        }
        if (!x) {
            x.scrollIntoView()
        }
    } else {
        if (a == 1) {
            $("#content").scrollTop($("#content")[0].scrollHeight)
        } else {
            var Q = $("#content").innerHeight();
            if (A <= 0 || ($("#content")[0].scrollHeight - Q) >= A) {
                if (A < 0) {
                    A = 0
                }
                $("#content").scrollTop(A)
            } else {
                g_content_scroll_timer = setInterval(function() {
                    if (($("#content")[0].scrollHeight - Q) >= A) {
                        $("#content").scrollTop(A);
                        if (g_content_scroll_timer) {
                            clearInterval(g_content_scroll_timer);
                            g_content_scroll_timer = null
                        }
                    }
                }, 200)
            }
        }
    }
    $("#content img.fontcode").css("height", settings_font_size + "px");
    $("#content img.fontcode").css("width", "auto");
    g_on_notebook_page = false;
    if (ebdic_mode == 2) {
        var n = false;
        if (g_go_page >= 0 || (g_go_page == -1 && g_go_book_index >= 0 && g_go_offset >= 0)) {
            var B = g_max_page_offset_diff;
            if (g_note_book_index >= 0 && g_dics_type[g_note_book_index] && g_dics_type[g_note_book_index] != 0) {
                B = 0
            }
            var O = (g_go_offset >= g_note_offset ? g_go_offset - g_note_offset : g_note_offset - g_go_offset);
            if (g_go_page == g_note_page && O <= B && g_go_book_index == g_note_book_index) {
                n = true
            }
        } else {
            if (g_go_page == -2 && g_note_page == -2) {
                if (!g_go_db_name && !g_note_db_name) {
                    n = true
                } else {
                    if (!g_go_db_name || !g_note_db_name) {
                        n = false
                    } else {
                        if (g_go_db_name == g_note_db_name && g_go_custom_word_row_id == g_note_custom_word_row_id) {
                            n = true
                        }
                    }
                }
            } else {
                if (g_go_page == -3 && g_note_page == -3 && g_note_keyword && g_go_keyword && g_note_keyword == g_go_keyword) {
                    n = true
                }
            }
        }
        if (n) {
            g_on_notebook_page = true;
            g_notebook_db_pos = -1
        } else {
            P = null
        }
    } else {
        if (!g_use_search_mode_hightlight) {
            P = null
        }
    }
    var F = rangy.createRange();
    var c = document.getElementById("wordlist");
    F.selectNode(document.body);
    b = F.getBookmark(c);
    var K = b.end;
    c = document.getElementById("maintool");
    F.selectNode(document.body);
    b = F.getBookmark(c);
    K = b.end + K;
    if (g_go_page == -3) {
        K += 1
    }
    if (g_test_highlight) {
        console.log("content_offset_base=" + K)
    }
    g_content_offset = K + g_calc_highlight_offset;
    K = g_content_offset;
    highlight_offset = K;
    if (P) {
        p_data = parseHighlightExtra(P, K);
        highlight_data = generateRangyHighlightString();
        if (highlight_data) {
            highlighter.deserialize(highlight_data)
        }
        updateHighlightColor();
        if (ebdic_mode != 2 && g_searchModeAddHighlight) {
            g_highlight_data_string = generateBase0HighlightString()
        }
    } else {
        notebook_highlight_map = {};
        sort_notebook_highlight = []
    }
    updateNav();
    var G = mobileAndTabletcheck();
    if (!G) {
        disableHighlight()
    } else {
        if (ebdic_mode == 2 && !isEmpty(notebook_highlight_map)) {
            $("#clear_btn").attr("disabled", false)
        } else {
            $("#clear_btn").attr("disabled", true)
        }
    }
    if (g_go_book_index == -1) {
        enableParagraphBtn(false)
    } else {
        enableParagraphBtn(true)
    }
    if (g_go_page == -4) {
        if (settings_web_search_in_new_tab == 0) {
            $("#content a, #content area").attr("target", "_self")
        }
    } else {
        if (g_go_page == -2) {
            $("#content a, #content area").attr("target", "_blank");
            $("#content a, #content area").click(function(X) {
                var T = $(this).attr("href");
                if (T.startsWith("ebdic://")) {
                    $(this).attr("target", "_self");
                    try {
                        var U = T.substring("ebdic://".length);
                        var Y = U.split(":");
                        var W = parseInt(Y[0]);
                        if (W == 0) {}
                        if (W == -3) {
                            var aa = Y[1]
                        } else {
                            if (W == -2) {
                                var y = Y[1];
                                var Z = parseInt(Y[2])
                            }
                        }
                    } catch (V) {
                        toastr.error("URL error!!")
                    }
                    X.preventDefault();
                    X.stopPropagation();
                    return
                }
            })
        } else {
            $("#content a, #content area").click(function(ac) {
                var T = $(this).attr("href");
                if (!T) {
                    return
                }
                if (T.startsWith("sound://")) {
                    $("#audiotag").attr("src", "/file" + T.substr("sound://".length));
                    try {
                        audioElement = document.getElementById("audiotag");
                        audioElement.play()
                    } catch (Y) {
                        toastr.error("No sound!!")
                    }
                    return
                }
                if (T.startsWith("http://") || T.startsWith("https://") || T.startsWith("ftp://") || T.startsWith("image://") || T.startsWith("/file/")) {
                    if (T.startsWith("image://")) {
                        $(this).attr("href", "/file" + T.substr("image://".length))
                    }
                    $(this).attr("target", "_blank");
                    return
                }
                if (T.startsWith("#")) {
                    return
                }
                ac.preventDefault();
                if (!checkConnect()) {
                    return
                }
                log("href=" + T);
                if (T.startsWith("mdict://")) {
                    var W = T.substr("mdict://".length);
                    var ae = W.indexOf("/");
                    if (ae < 0) {
                        return
                    }
                    var ah = W.substr(0, ae);
                    W = W.substr(ae + 1);
                    if (W.startsWith("sound:/")) {
                        var W = W.substr("sound:/".length);
                        var af = W;
                        setStatus(2);
                        ws.send({
                            cmd: "req_generate_mdict_sound",
                            book_index: ah,
                            key: af
                        });
                        return
                    } else {
                        if (W.startsWith("entry://")) {
                            var y = W.substr("entry://".length);
                            var aa = null ;
                            var X = y.indexOf("#");
                            if (X > 1 && X != y.length - 1) {
                                aa = y.substring(X + 1);
                                y = y.substring(0, X)
                            }
                            setStatus(2);
                            if (aa != null && aa.length > 0) {
                                ws.send({
                                    cmd: "req_go_to_stardic_bword",
                                    data: y,
                                    book_index: ah,
                                    anchor: aa,
                                    type: "1"
                                })
                            } else {
                                ws.send({
                                    cmd: "req_go_to_stardic_bword",
                                    data: y,
                                    book_index: ah,
                                    type: "1"
                                })
                            }
                            return
                        } else {
                            return
                        }
                    }
                } else {
                    if (T.startsWith("bword://")) {
                        var ah = g_go_book_index;
                        var ae = T.lastIndexOf("/");
                        var ab = T.substr("bword://".length);
                        if (ae >= 0) {
                            ah = parseInt(T.substr(ae + 1));
                            ab = T.substr("bword://".length, ae)
                        }
                        setStatus(2);
                        ws.send({
                            cmd: "req_go_to_stardic_bword",
                            data: ab,
                            book_index: ah
                        });
                        return
                    }
                }
                var V = "<ref " + T;
                var ag = "s.mp3";
                var Z = ".basename";
                if (T.endsWith(ag)) {
                    setStatus(2);
                    var ad = $(this).text();
                    ws.send({
                        cmd: "req_generate_sound",
                        data: T,
                        text: ad
                    })
                } else {
                    if (T.endsWith(Z)) {
                        setStatus(2);
                        var ad = $(this).text();
                        ws.send({
                            cmd: "req_generate_sound",
                            data: T,
                            text: ad
                        })
                    } else {
                        V += ">";
                        log("ref=" + V);
                        setStatus(2);
                        myhistory.removeAfterCur();
                        myhistory.add(V);
                        parseGoToPage(V);
                        var U = $("#search_text").val().trim();
                        ws.send({
                            cmd: "req_go_to_eb_position",
                            data: V,
                            keyword: U
                        });
                        updateNav()
                    }
                }
            })
        }
    }
    if (!send_increment) {
        setStatus(0)
    }
    closeSearchFullDialog()
});
ws.addResponseEvent("rsp_generate_mdict_sound", function(d, a) {
    setStatus(0);
    if (typeof a.data != "undefined") {
        data = a.data
    }
    if (data) {
        $("#audiotag").attr("src", data);
        src = $("#audiotag").attr("src");
        log("src=" + src);
        try {
            audioElement = document.getElementById("audiotag");
            audioElement.play()
        } catch (c) {
            toastr.error("No sound!!")
        }
    }
});
ws.addResponseEvent("rsp_generate_sound", function(e, a) {
    setStatus(0);
    data = "";
    text = "";
    if (typeof a.data != "undefined") {
        data = a.data
    }
    if (typeof a.text != "undefined") {
        text = a.text
    }
    if (data) {
        var g = $("#audiotag").attr("src");
        var f = ".basename";
        var c = ".mpg";
        if ((data.indexOf(f, data.length - f.length) !== -1) || (data.indexOf(c, data.length - c.length) !== -1)) {
            openpopupvideo(data, text);
            return
        } else {
            $("#audiotag").attr("src", data + ".mp3")
        }
        g = $("#audiotag").attr("src");
        log("src=" + g);
        try {
            audioElement = document.getElementById("audiotag");
            audioElement.play()
        } catch (d) {
            toastr.error("No sound!!")
        }
    }
});
ws.addResponseEvent("rsp_edit_custom_word", function(a) {
    setStatus(0);
    if (typeof rsp.result != "undefined") {
        result = rsp.result
    }
    var c = 0;
    if (typeof rsp.add != "undefined") {
        c = rsp.add
    }
    if (result < 0) {
        if (result == -2 && c != 1) {
            toastr.warning(res_string_toastr_edit_word_not_exist)
        } else {
            toastr.warning("Database error!!")
        }
    } else {
        if (c == 1) {
            toastr.info(res_string_add_custom_word_successfully)
        } else {
            toastr.info(res_string_update_custom_word_successfully)
        }
        if (pageCount != -1) {
            if (pageCount != result) {
                pageCount = result;
                changeCurrentDB(current_database_file, currentPage, pageCount)
            } else {
                if (c == 1 && currentPage == result && ebdic_mode == 2) {
                    setStatus(2);
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage
                    })
                } else {
                    if (c == 0 && ebdic_mode == 2) {
                        setStatus(2);
                        ws.send({
                            cmd: "req_get_note",
                            page: currentPage,
                            type: 2
                        })
                    }
                }
            }
        }
    }
});
ws.addResponseEvent("rsp_add_word", function(l, e) {
    var f = 0;
    var c = null ;
    var a = 0;
    var d = 0;
    setStatus(0);
    if (typeof e.result != "undefined") {
        a = e.result
    }
    if (typeof e.type != "undefined") {
        f = e.type
    }
    if (typeof e.db_name != "undefined") {
        c = e.db_name
    }
    if (typeof e.addSearchWord != "undefined") {
        d = e.addSearchWord
    }
    if (a == -3) {
        toastr.warning(res_string_toastr_input_empty)
    } else {
        if (a == -2) {
            showConfirmAddWordDialog(c, d);
            return
        } else {
            if (a == -1 || a <= -3) {
                toastr.warning("Database error!!")
            } else {
                if (a >= 0) {
                    var g = c;
                    if (!c) {
                        g = current_database_file
                    }
                    toastr.info(res_string_toastr_add_success + "<br>(" + g + ")");
                    if (typeof e.notebook_row_id != "undefined") {
                        g_notebook_row_id = e.notebook_row_id;
                        updateTitle();
                        selected = isSelectedText();
                        if ((selected == true && g_use_search_mode_hightlight && g_notebook_row_id >= 0) || (selected == true && g_searchModeAddHighlight)) {
                            enableHighlight()
                        }
                    }
                    if (f == 0 && pageCount != -1) {
                        if (pageCount != a) {
                            pageCount = a;
                            changeCurrentDB(current_database_file, currentPage, pageCount)
                        } else {
                            if (currentPage == a) {
                                disabled = $("#pages_btn").attr("disabled");
                                if (!disabled) {
                                    setStatus(2);
                                    ws.send({
                                        cmd: "req_get_note",
                                        page: currentPage
                                    })
                                }
                            }
                        }
                    }
                    if (g_searchModeAddHighlight && g_highlight_data_string && ebdic_mode != 2 && g_notebook_row_id < 0 && highlighter) {
                        removeAllHighlight();
                        disableHighlight()
                    }
                }
            }
        }
    }
});
ws.addResponseEvent("rsp_get_word_list", function(d, c) {
    wordlist = [];
    var a = send_increment;
    log("send_increment =" + send_increment);
    send_increment = false;
    if (keep_increment_word != null ) {
        log("search keep_increment_word=" + keep_increment_word);
        setStatus(1);
        g_multi_search_words = null ;
        if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
            ws.send({
                cmd: "req_search",
                data: convertToKana(keep_increment_word),
                data2: romnih(keep_increment_word),
                increment: only_increment,
                from_increment: 1
            })
        } else {
            ws.send({
                cmd: "req_search",
                data: convertToKana(keep_increment_word),
                increment: only_increment,
                from_increment: 1
            })
        }
        send_increment = true;
        keep_increment_word = null
    }
    if (typeof c.data != "undefined") {
        wordlist = c.data
    }
    log("wordlist=" + wordlist.length);
    if (!a && wordlist.length <= 0) {
        is_search_empty = true
    }
    if (wordlist.length > 0) {
        current_word = wordlist[0]
    } else {
        current_word = ""
    }
    if (a && only_increment == 1) {
        current_word = ""
    }
    if (ebdic_mode == 3) {
        current_word = ""
    }
    if (wordlist.length > 0) {
        if (!a || only_increment == 0) {
            if (ebdic_mode != 3) {
                myhistory.clear();
                myhistory.add(current_word);
                parseGoToPage(current_word);
                if (g_go_note == 0) {
                    g_end_book_index = g_go_book_index
                }
            }
        }
    }
    updateNav();
    wordlistComplete = wordlist.slice(0);
    wordlistComplete_dics = wordlistComplete;
    dics_wordlist = {};
    view_dic_index_map = {};
    view_index_dic_map = {};
    size = 0;
    for (i = 0; i < wordlist.length; i++) {
        title = dictionaryTitle(wordlist[i]);
        if (!dics_wordlist[title]) {
            dics_wordlist[title] = [];
            view_dic_index_map[title] = size;
            view_index_dic_map[size] = title;
            size++
        }
        dics_wordlist[title].push(wordlist[i]);
        wordlist[i] = adjustDictionaryTitle(wordlist[i])
    }
    $("#wordlist").jqxListBox({
        source: wordlist
    });
    changelistfontFamily(settings_list_font_family);
    if (!a || only_increment == 0) {
        if (ebdic_mode != 3) {
            g_resize_set_item_index = true;
            $("#wordlist").jqxListBox("selectedIndex", 0)
        }
    }
    $("#dics_select option").remove();
    view_dic_index = -1;
    view_dics_size = size;
    if (size > 0) {
        view_dic_index = 0
    }
    if (size >= 2) {
        $("#dics_select").append($("<option></option>").attr("value", "All").attr("selected", true).text(res_string_all))
    }
    for (dic_name in dics_wordlist) {
        $("#dics_select").append($("<option></option>").attr("value", dic_name).text(dic_name))
    }
    updateViewDicsNav()
});
var ebdic_mode = 1;
function setMode(a) {
    ebdic_mode = a;
    if (a != 2) {
        $("#left_left_btn").attr("disabled", true);
        $("#left_btn").attr("disabled", true);
        $("#right_btn").attr("disabled", true);
        $("#right_right_btn").attr("disabled", true);
        $("#pages_btn").attr("disabled", true);
        $("#note_btn").attr("disabled", false);
        $("#add_btn").attr("disabled", false);
        $("#checkbox_btn").attr("disabled", true);
        $("#delete_note_btn").attr("disabled", true);
        $("#tag_note_btn").attr("disabled", true);
        $("#edit_custom_word").attr("disabled", true);
        g_dbs = null ;
        $("#dics_select option").remove();
        disableHighlight()
    } else {
        enableNote()
    }
    if (g_checkbox) {
        $("#wordlist").jqxListBox({
            checkboxes: false
        });
        g_checkbox = false;
        changelistfontFamily(settings_list_font_family)
    }
    g_checkbox = false;
    g_checkbox_items = []
}
function updateNoteNavi() {
    if (ebdic_mode != 2) {
        return
    }
    var a = false;
    if (currentPage <= 1) {
        a = true
    }
    $("#left_btn").attr("disabled", a);
    $("#left_left_btn").attr("disabled", a);
    var c = false;
    if (currentPage >= pageCount) {
        c = true
    }
    $("#right_btn").attr("disabled", c);
    $("#right_right_btn").attr("disabled", c)
}
function enableNote() {
    var c = false;
    if (currentPage <= 1) {
        c = true
    }
    ebdic_mode = 2;
    $("#left_btn").attr("disabled", c);
    $("#left_left_btn").attr("disabled", c);
    var d = false;
    if (currentPage >= pageCount) {
        d = true
    }
    $("#right_btn").attr("disabled", d);
    $("#right_right_btn").attr("disabled", d);
    $("#pages_btn").attr("disabled", false);
    changeCurrentDB(current_database_file, currentPage, pageCount);
    $("#note_btn").attr("disabled", true);
    $("#add_btn").attr("disabled", true);
    $("#prev_dic_btn").attr("disabled", c);
    $("#next_dic_btn").attr("disabled", d);
    $("#checkbox_btn").attr("disabled", false);
    updateNoteOpBtn();
    var a = mobileAndTabletcheck();
    if (a) {
        enableHighlight()
    }
}
function updateNoteOpBtn() {
    var a = $("#wordlist").jqxListBox("selectedIndex");
    var c = null ;
    if (g_checkbox) {
        c = $("#wordlist").jqxListBox("getCheckedItems")
    }
    if ((!g_checkbox && a < 0) || (g_checkbox && (!c || c.length <= 0)) || ebdic_mode != 2) {
        $("#delete_note_btn").attr("disabled", true);
        $("#tag_note_btn").attr("disabled", true)
    } else {
        $("#delete_note_btn").attr("disabled", false);
        $("#tag_note_btn").attr("disabled", false)
    }
}
var currentPage = -1;
var pageCount = -1;
var theme_type = 1;
ws.addResponseEvent("rsp_get_theme", function(c, a) {
    t_theme_type = a.data;
    r = a.reload;
    log("t_theme_type=" + t_theme_type);
    log("r=" + r);
    if (theme_type != t_theme_type) {
        changeTheme(t_theme_type);
        handleWidgetFlashCardEvent("settings", {
            theme: g_theme_type
        });
        if (r == 1) {
            contentReload()
        }
    }
    theme_type = t_theme_type
});
function closeAllDBDialogs() {
    closeEditNoteDialog();
    closeNotebookPagesDialog();
    closeDBSelectDialog();
    closeAddWordDBSelectDialog();
    closeConfirmDeleteEditNoteDialog();
    closeConfirmDeleteHighlightDialog();
    closeConfirmDeleteWordsDialog();
    closeConfirmAddWordDialog();
    closeConfirmAddDBDialog()
}
ws.addResponseEvent("rsp_get_settings_data", function(z, C) {
    if (typeof C.pro != "undefined") {
        pro = C.pro
    } else {
        pro = 0
    }
    g_use_full_search = 0;
    if (typeof C.use_full_search != "undefined") {
        g_use_full_search = C.use_full_search
    }
    g_haveMultSearchiInDics = 0;
    if (typeof C.haveMultSearchiInDics != "undefined") {
        g_haveMultSearchiInDics = C.haveMultSearchiInDics
    }
    g_haveMenuInDics = 0;
    if (typeof C.haveMenuInDics != "undefined") {
        g_haveMenuInDics = C.haveMenuInDics
    }
    g_haveImageMenuInDics = 0;
    if (typeof C.haveImageMenuInDics != "undefined") {
        g_haveImageMenuInDics = C.haveImageMenuInDics
    }
    g_haveCopyRightInDics = 0;
    if (typeof C.haveCopyRightInDics != "undefined") {
        g_haveCopyRightInDics = C.haveCopyRightInDics
    }
    g_haveEpwingInDics = 0;
    if (typeof C.haveEpwingInDics != "undefined") {
        g_haveEpwingInDics = C.haveEpwingInDics
    }
    g_haveStarDicInDics = 0;
    if (typeof C.haveStarDicInDics != "undefined") {
        g_haveStarDicInDics = C.haveStarDicInDics
    }
    g_haveMDicInDics = 0;
    if (typeof C.haveMDicInDics != "undefined") {
        g_haveMDicInDics = C.haveMDicInDics
    }
    g_use_web_search_in_ebdic = 1;
    if (typeof C.use_web_search_in_ebdic != "undefined") {
        g_use_web_search_in_ebdic = C.use_web_search_in_ebdic
    }
    g_highlight_color = 0;
    if (typeof C.hightLightColor != "undefined") {
        g_highlight_color = C.hightLightColor
    }
    setHighlightColorImg(g_highlight_color);
    var u = [];
    if (typeof C.dics_type != "undefined") {
        var q = C.dics_type;
        u = q.split(",")
    }
    var y = [];
    if (typeof C.dics_ids != "undefined") {
        var a = C.dics_ids;
        y = a.split(",")
    }
    var B = [];
    if (typeof C.dics_names != "undefined") {
        var o = C.dics_names;
        B = o.split(":")
    }
    if (g_dics_type.length > 0) {
        var n = false;
        if (g_dics_type.length != u.length) {
            n = true
        }
        if (g_dics_ids.length != y.length) {
            n = true
        }
        if (g_dics_names.length != B.length) {
            n = true
        }
        if (!n) {
            for (i = 0; i < u.length; i++) {
                if (g_dics_type[i] != u[i]) {
                    n = true;
                    break
                }
                if (g_dics_ids[i] != y[i]) {
                    n = true;
                    break
                }
                if (g_dics_names[i] != B[i]) {
                    n = true;
                    break
                }
            }
        }
        if (n) {
            contentReload();
            return
        }
    }
    g_dics_type = u;
    g_dics_ids = y;
    g_dics_names = B;
    updatePro();
    if (typeof C.tnw != "undefined") {
        g_tnw = C.tnw;
        if (g_tnw == 1) {
            g_multi_rom_to_hina = 0
        } else {
            g_multi_rom_to_hina = 1
        }
    }
    if (typeof C.max_page_offset_diff != "undefined") {
        g_max_page_offset_diff = C.max_page_offset_diff
    }
    if (typeof C.listDictionaryTitleSize != "undefined") {
        listDictionaryTitleSize = C.listDictionaryTitleSize;
        log("listDictionaryTitleSize=" + listDictionaryTitleSize)
    }
    if (typeof C.searchMethod != "undefined") {
        searchMethod = C.searchMethod;
        log("searchMethod=" + searchMethod);
        updateSearchMethod()
    }
    if (typeof C.web_settings_autocomplete != "undefined") {
        settings_autocomplete = C.web_settings_autocomplete
    } else {
        settings_autocomplete = 1
    }
    updateAutoComplete(settings_autocomplete);
    if (typeof C.web_settings_web_search_in_new_tab != "undefined") {
        settings_web_search_in_new_tab = C.web_settings_web_search_in_new_tab
    } else {
        settings_web_search_in_new_tab = 0
    }
    if (typeof C.web_settings_list_size != "undefined") {
        settings_search_size = C.web_settings_list_size
    } else {
        settings_search_size = 100
    }
    if (typeof C.web_settings_inc_list_size != "undefined") {
        settings_inc_search_size = C.web_settings_inc_list_size
    } else {
        settings_inc_search_size = 10
    }
    web_settings_volume = 50;
    if (typeof C.web_settings_volume != "undefined") {
        web_settings_volume = C.web_settings_volume
    }
    if (typeof C.web_settings_font_family != "undefined") {
        font_family = C.web_settings_font_family;
        if (font_family) {
            settings_font_family = font_family
        }
        $("#content").css("fontFamily", settings_font_family)
    }
    if (typeof C.web_settings_font_size != "undefined") {
        settings_font_size = C.web_settings_font_size;
        $("#content").css("fontSize", settings_font_size + "px");
        $("#content img.fontcode").css("height", settings_font_size + "px");
        $("#content img.fontcode").css("width", "auto")
    }
    if (typeof C.web_settings_list_font_family != "undefined") {
        font_family = C.web_settings_list_font_family;
        if (font_family) {
            settings_list_font_family = font_family
        }
        changelistfontFamily(settings_list_font_family)
    }
    if (typeof C.web_settings_list_font_size != "undefined") {
        settings_list_font_size = C.web_settings_list_font_size;
        changelistFontSize(settings_list_font_size);
        changelistfontFamily(settings_list_font_family)
    }
    if (typeof C.web_settings_word_emphasize != "undefined") {
        g_word_emphasize = C.web_settings_word_emphasize
    }
    if (typeof C.web_settings_line_height != "undefined") {
        settings_line_height = C.web_settings_line_height;
        $("#content").css("lineHeight", settings_line_height)
    }
    if (typeof C.web_settings_list_layout_ratio != "undefined") {
        g_list_ratio = C.web_settings_list_layout_ratio;
        resize(g_list_ratio)
    }
    if (typeof C.web_settings_only_increment != "undefined") {
        only_increment = C.web_settings_only_increment
    }
    if (typeof C.web_settings_show_highlight_tool != "undefined") {
        show_highlight_tool = C.web_settings_show_highlight_tool;
        updateShowHighlightTool(show_highlight_tool)
    }
    if (typeof C.web_settings_click_search != "undefined") {
        g_click_search = C.web_settings_click_search
    }
    updateClickSearchIcon();
    if (typeof C.web_settings_paragraphs_size != "undefined") {
        settings_paragraphs_size = C.web_settings_paragraphs_size
    }
    if (typeof C.locale != "undefined") {
        _locale_language = C.locale;
        updateLocale(_locale_language)
    }
    if (typeof C.web_settings_romaji_to_hiragana != "undefined") {
        g_rom_to_hina = C.web_settings_romaji_to_hiragana;
        updateRomHina()
    }
    if (typeof C.current_use_dics_index != "undefined") {
        g_current_use_dics_index = C.current_use_dics_index
    }
    if (typeof C.haveMultiSearch != "undefined") {
        g_haveMultiSearch = C.haveMultiSearch
    }
    audioElement = document.getElementById("audiotag");
    audioElement.volume = web_settings_volume / 100;
    if (typeof C.play_sound != "undefined") {
        play_sound = C.play_sound
    } else {
        play_sound = -1
    }
    if (play_sound >= 0 && $("#play_btn")) {
        $("#play_btn").show()
    } else {
        $("#play_btn").hide()
    }
    var m = false;
    var e = false;
    var A = false;
    if (typeof C.current_database_file != "undefined") {
        db_file = C.current_database_file;
        if (db_file != current_database_file && ebdic_mode == 2) {
            g_dbs = null ;
            currentPage = -2;
            if (ebdic_mode == 2) {
                closeAllDBDialogs();
                if (!g_delay_go_to_settings) {
                    setStatus(2);
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage,
                        refresh: 1
                    })
                }
                A = true;
                m = true
            }
        } else {
            if (db_file != current_database_file && !e && g_use_search_mode_hightlight && ebdic_mode == 1 && g_go_book_index >= 0 && g_go_position) {
                e = true;
                closeDBSelectDialog();
                if (!g_delay_go_to_settings) {
                    setStatus(2);
                    var x = $("#search_text").val().trim();
                    ws.send({
                        cmd: "req_go_to_eb_position",
                        data: g_go_position,
                        scrolly: scrolly,
                        keyword: x
                    })
                }
            }
        }
        if (typeof C.currentPage != "undefined") {
            currentPage = C.currentPage
        }
        if (typeof C.pageCount != "undefined") {
            pageCount = C.pageCount
        }
        cPage = readCookie("currentPage");
        cDatabase = readCookie("current_database_file");
        if (cPage && cDatabase && cDatabase == db_file && cPage <= pageCount && cPage >= 0) {
            currentPage = cPage
        }
        changeCurrentDB(db_file, currentPage, pageCount)
    }
    if (typeof C.notebook_db_pos != "undefined") {
        db_pos = C.notebook_db_pos;
        if (ebdic_mode == 2 && db_pos != g_go_db_pos && !m) {
            closeAllDBDialogs();
            m = true;
            A = true;
            if (!g_delay_go_to_settings) {
                setStatus(2);
                ws.send({
                    cmd: "req_get_note",
                    page: currentPage,
                    refresh: 1
                })
            }
        }
    }
    if (typeof C.web_ui_db_change != "undefined" || !g_init) {
        web_ui_db_change = C.web_ui_db_change;
        if (ebdic_mode == 2 && web_ui_db_change == 1 && !m) {
            closeAllDBDialogs();
            m = true;
            if (!g_delay_go_to_settings) {
                setStatus(2);
                ws.send({
                    cmd: "req_get_note",
                    page: currentPage
                })
            }
        } else {
            if (!e && g_use_search_mode_hightlight && ebdic_mode == 1 && g_go_book_index >= 0 && g_go_position) {
                e = true;
                closeDBSelectDialog();
                if (!g_delay_go_to_settings) {
                    setStatus(2);
                    var x = $("#search_text").val().trim();
                    ws.send({
                        cmd: "req_go_to_eb_position",
                        data: g_go_position,
                        scrolly: scrolly,
                        keyword: x
                    })
                }
            }
        }
    }
    if (typeof C.web_ui_page_size_change != "undefined" || !g_init) {
        var c = 0;
        c = C.web_ui_page_size_change;
        if (c == 1) {
            currentPage = -2
        }
        if (ebdic_mode == 2 && c == 1 && !m) {
            closeAllDBDialogs();
            m = true;
            if (!g_delay_go_to_settings) {
                setStatus(2);
                ws.send({
                    cmd: "req_get_note",
                    page: currentPage
                })
            }
        }
    }
    if (typeof C.web_ui_db_name_change != "undefined" || !g_init) {
        var f = 0;
        f = C.web_ui_db_name_change;
        if (f == 1) {
            currentPage = -2;
            closeEditCustomWordDialog();
            closeConfirmExitEditCustomWordDialog()
        }
        if (ebdic_mode == 2 && f == 1 && !m) {
            closeAllDBDialogs();
            m = true;
            if (!g_delay_go_to_settings) {
                setStatus(2);
                ws.send({
                    cmd: "req_get_note",
                    page: currentPage
                })
            }
        } else {
            if (!e && g_use_search_mode_hightlight && ebdic_mode == 1 && g_go_book_index >= 0 && g_go_position) {
                e = true;
                closeDBSelectDialog();
                if (!g_delay_go_to_settings) {
                    setStatus(2);
                    var x = $("#search_text").val().trim();
                    ws.send({
                        cmd: "req_go_to_eb_position",
                        data: g_go_position,
                        scrolly: scrolly,
                        keyword: x
                    })
                }
            }
        }
    }
    if (typeof C.web_ui_web_search_update != "undefined" || !g_init) {
        var d = C.web_ui_web_search_update;
        if (d == 1) {
            g_web_sites_name_list = null ;
            g_web_sites_url_list = null ;
            g_web_sites_font_size_list = null
        }
    }
    if (typeof C.web_ui_highlight_change != "undefined" || !g_init) {
        var g = 0;
        g = C.web_ui_highlight_change;
        if ((ebdic_mode == 2 && g == 1) || (g_use_search_mode_hightlight && ebdic_mode == 1)) {
            closeAllDBDialogs();
            if (g_go_book_index >= 0 && g_go_position && !e) {
                e = true;
                if (!g_delay_go_to_settings) {
                    setStatus(2);
                    var x = $("#search_text").val().trim();
                    ws.send({
                        cmd: "req_go_to_eb_position",
                        data: g_go_position,
                        scrolly: scrolly,
                        keyword: x
                    })
                }
            }
        }
    }
    if (typeof C.web_ui_db_op_change != "undefined" || !g_init) {
        var l = 0;
        l = C.web_ui_db_op_change;
        if (ebdic_mode == 2 && l == 1) {
            closeAllDBDialogs();
            if (!m) {
                m = true;
                if (!g_delay_go_to_settings) {
                    setStatus(2);
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage
                    })
                }
            }
        }
        if (g_go_book_index >= 0 && g_go_position && !e) {
            e = true;
            if (!g_delay_go_to_settings) {
                setStatus(2);
                var x = $("#search_text").val().trim();
                ws.send({
                    cmd: "req_go_to_eb_position",
                    data: g_go_position,
                    scrolly: scrolly,
                    keyword: x
                })
            }
        }
    }
    closeAddWordDBSelectDialog();
    if (g_delay_go_to_settings) {
        if (m && ebdic_mode == 2) {
            if (A) {
                window.setTimeout(function() {
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage,
                        refresh: 1
                    })
                }, 500)
            } else {
                window.setTimeout(function() {
                    ws.send({
                        cmd: "req_get_note",
                        page: currentPage
                    })
                }, 500)
            }
        } else {
            if (e) {
                window.setTimeout(function() {
                    var D = $("#search_text").val().trim();
                    ws.send({
                        cmd: "req_go_to_eb_position",
                        data: g_go_position,
                        scrolly: scrolly,
                        keyword: D
                    })
                }, 500)
            }
        }
    }
    handleWidgetFlashCardEvent("settings", {
        title_size: listDictionaryTitleSize,
        locale: locale_language,
        list_font_size: settings_list_font_size
    });
    window.setTimeout(function() {
        ws.send({
            cmd: "req_clear_web_ui_change"
        })
    }, 1000)
});
ws.addResponseEvent("rsp_set_search_method", function(c, a) {
    if ($("#search_text").val()) {
        var d = $("#search_text").val();
        send_increment = false;
        keep_increment_word = null ;
        setStatus(1);
        if (searchMethod == 4) {
            showSearchFullDialog()
        }
        g_multi_search_words = null ;
        if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
            ws.send({
                cmd: "req_search",
                data: convertToKana(d),
                data2: romnih(d),
                increment: 0
            })
        } else {
            ws.send({
                cmd: "req_search",
                data: convertToKana(d),
                increment: 0
            })
        }
        addHistoryWords(d);
        setMode(1)
    }
});
function updateNav() {
    if (myhistory.showBackward()) {
        $("#prev_btn").attr("disabled", false)
    } else {
        $("#prev_btn").attr("disabled", true)
    }
    if (myhistory.showForward()) {
        $("#next_btn").attr("disabled", false)
    } else {
        $("#next_btn").attr("disabled", true)
    }
}
function clearViewDicsNav() {
    view_dic_index = -1;
    view_dic_index_map = {};
    view_index_dic_map = {};
    view_dics_size = 0;
    updateViewDicsNav()
}
function updateViewDicsNav() {
    if (view_dics_size <= 0) {
        $("#prev_dic_btn").attr("disabled", true);
        $("#next_dic_btn").attr("disabled", true)
    } else {
        $("#prev_dic_btn").attr("disabled", false);
        $("#next_dic_btn").attr("disabled", false);
        if (view_dic_index <= 0) {
            $("#prev_dic_btn").attr("disabled", true)
        }
        if (view_dic_index >= view_dics_size - 1) {
            $("#next_dic_btn").attr("disabled", true)
        }
    }
}
function updateViewDics(a) {
    wordlist2 = [];
    if (a == "All") {
        wordlist = wordlistComplete_dics
    } else {
        wordlist = dics_wordlist[a]
    }
    if (a == "All") {
        view_dic_index = 0
    } else {
        view_dic_index = view_dic_index_map[a]
    }
    wordlistComplete = wordlist;
    for (i = 0; i < wordlist.length; i++) {
        wordlist2.push(adjustDictionaryTitle(wordlist[i]))
    }
    $("#wordlist").jqxListBox({
        source: wordlist2
    });
    changelistfontFamily(settings_list_font_family);
    if (wordlist.length > 0) {
        $("#wordlist").jqxListBox("selectedIndex", 0)
    }
    updateViewDicsNav()
}
var g_theme_type = 1;
function changeTheme(a) {
    g_theme_type = a;
    if (a == 0) {
        document.body.style.backgroundColor = "#191919";
        document.body.style.color = "#e5e5e5";
        $("#wordlist").jqxListBox({
            theme: "custom"
        });
        $("#content").css("border", "1px solid #a1a1a1");
        $("#content a[href]").css("color", "#33b5e5");
        $("#status").attr("src", "./img/loading_black.gif")
    } else {
        document.body.style.backgroundColor = "#ffffff";
        document.body.style.color = "#191919";
        $("#content").css("border", "1px solid #000000");
        $("#wordlist").jqxListBox({
            theme: "custom2"
        });
        $("#content a[href]").css("color", "#0000ff");
        $("#status").attr("src", "./img/loading.gif")
    }
}
function autoLinkSearchWord(c, e) {
    var a = c;
    if (e == 0) {
        var d = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
        a = c.replace(d, '<a href="$1">$1</a>')
    }
    return a
}
function adjustDictionaryTitleColor(a) {
    fi = a.indexOf("#");
    ei = a.indexOf(">");
    l1 = a.substring(0, fi + 1);
    l2 = a.substring(ei, a.length);
    KEYWORD_COLOR = 16217088;
    if (theme_type == 1) {
        KEYWORD_COLOR = 12262165
    }
    return l1 + KEYWORD_COLOR.toString(16) + l2
}
function dictionaryTitleLang(e, c, d, f) {
    var a = e;
    if (f == -1) {
        if (c == -3) {
            a = item_title_search_word
        } else {
            if (c == -2) {
                a = item_title_custom_word
            } else {
                if (c == -4) {
                    a = item_title_web_search
                }
            }
        }
    }
    return a
}
function dictionaryTitle(a) {
    fi = a.indexOf(">");
    ei = a.indexOf("</");
    new_content = a.substring(0, fi + 1);
    var m = a.substring(fi + 1, ei);
    var f = /.*<ref (.*)>.*/;
    var c = a.match(f);
    var e = -1;
    var d = -1;
    var g = -1;
    if (c && c[1]) {
        t = c[1].trim().split(":");
        e = parseInt(t[0]);
        d = parseInt(t[1]);
        g = parseInt(t[2])
    }
    m = dictionaryTitleLang(m, e, d, g);
    return m
}
function adjustDictionaryTitle(c) {
    c = c.replace(/width=\d+/g, "");
    c = c.replace(/class="fontcode"/g, 'class="listfontcode" onload="scaleFontImage(this)"');
    c = adjustDictionaryTitleColor(c);
    var o = c;
    if (listDictionaryTitleSize >= 0 && listDictionaryTitleSize < 30) {
        fi = c.indexOf(">");
        ei = c.indexOf("</");
        o = c.substring(0, fi + 1);
        var g = c.substring(fi + 1, ei);
        var a = c.substring(ei, c.length);
        var q = /.*<ref (.*)>.*/;
        var d = c.match(q);
        var f = -1;
        var m = -1;
        var e = -1;
        if (d && d[1]) {
            t = d[1].trim().split(":");
            f = parseInt(t[0]);
            m = parseInt(t[1]);
            e = parseInt(t[2])
        }
        g = dictionaryTitleLang(g, f, m, e);
        len = g.trim().length;
        if (listDictionaryTitleSize < g.trim().length) {
            len = listDictionaryTitleSize
        }
        if (len == 0) {
            o = o + "" + a
        } else {
            var n = g.trim().substring(0, len);
            o = o + n + a
        }
    }
    return o
}
ws.addResponseEvent("rsp_go_to_stardic_bword", function(e, a) {
    var f = a.page;
    var g = a.offset;
    var l = a.book_index;
    var d = null ;
    if (typeof a.anchor != "undefined") {
        d = a.anchor
    }
    ref = "<ref " + f + ":" + g + ":" + l + ">";
    myhistory.removeAfterCur();
    myhistory.add(ref);
    parseGoToPage(ref);
    var c = $("#search_text").val().trim();
    if (d != null ) {
        ws.send({
            cmd: "req_go_to_eb_position",
            data: ref,
            keyword: c,
            anchor: d
        })
    } else {
        ws.send({
            cmd: "req_go_to_eb_position",
            data: ref,
            keyword: c
        })
    }
    updateNav()
});
ws.addResponseEvent("rsp_get_ebdic_word", function(g, c) {
    var a = c.keyword;
    var e = c.web_url;
    var f = c.type;
    var d = c.row_id;
    showEBDicWordDialog(false, d, f, a, e)
});
ws.addResponseEvent("rsp_db_op_busy", function(c, a) {
    toastr.info(res_string_toast_notebook_operation_busy);
    setStatus(0)
});
ws.addResponseEvent("rsp_get_jump_hit_word", function(d, c) {
    var a = "";
    a = c.result;
    if (a && ebdic_mode == 1) {
        $("#search_text").val(a)
    }
});
ws.addResponseEvent("rsp_change_tag", function(d, a) {
    var c = a.tagId;
    var e = a.level;
    setStatus(0);
    if ($("#" + c) && e > 0) {
        if (e == 2) {
            $("#" + c).attr("src", "./img/word_tag_red.png")
        } else {
            if (e == 3) {
                $("#" + c).attr("src", "./img/word_tag_blue.png")
            } else {
                $("#" + c).attr("src", "./img/word_tag.png")
            }
        }
    }
});
ws.addResponseEvent("rsp_set_ebdic_word", function(d, c) {
    var a = c.result;
    var e = c.add;
    if (a < 0) {
        if (a == -2 && e != 1) {
            toastr.warning(res_string_toastr_edit_word_not_exist)
        } else {
            toastr.warning("Database error!!")
        }
    } else {
        if (e == 1) {
            toastr.info(res_string_add_custom_word_successfully)
        } else {
            toastr.info(res_string_update_custom_word_successfully)
        }
        if (e == 0 && ebdic_mode == 2) {
            setStatus(2);
            ws.send({
                cmd: "req_get_note",
                page: currentPage,
                type: 2
            })
        }
    }
});
ws.addResponseEvent("rsp_widget_get_status", function(d, a) {
    var e = a.widget_count;
    if (e <= 0) {
        if (g_flash_carrd_window) {
            g_flash_carrd_window.close();
            g_flash_carrd_window = null
        }
        return
    }
    var c = a.open_or_update;
    g_flash_card_data = a.data;
    g_flash_card_play_status = a.play_status;
    if (c == 1) {
        openWidgetFlashCard(g_flash_card_data);
        if (g_flash_card_play_status != null ) {
            g_flash_carrd_window.postMessage({
                cmd: "play_status",
                data: g_flash_card_play_status
            }, server_uri)
        }
    }
});
ws.addResponseEvent("req_get_web_search_url", function(d, a) {
    var c = a.url;
    setStatus(0);
    var e = "<a href='" + c + "'>" + c + "</a>";
    $("#content").html(e);
    $("#content a, #content area").attr("target", "_blank");
    if (theme_type == 1) {
        $("#content a[href]").css("color", "#0000ff");
        $(".keysearch").css("color", "#BB1B15")
    } else {
        $("#content a[href]").css("color", "#33b5e5");
        $(".keysearch").css("color", "#F77400")
    }
    updateCSS()
});
ws.addResponseEvent("rsp_get_notebook_db_file_list", function(c, a) {
    dbs = [];
    if (typeof a.data != "undefined") {
        dbs = a.data
    }
    if (dbs) {
        g_dbs = dbs
    }
    type = 0;
    if (typeof a.type != "undefined") {
        type = a.type
    }
    if (type == 1) {
        showAddWordDBSelectDialog(0)
    } else {
        if (type == 2) {
            showDBSelectDialog()
        } else {
            if (type == 3) {
                if (g_highlight_data_string) {
                    showAddWordDBSelectDialog(2)
                }
            }
        }
    }
});
ws.addResponseEvent("rsp_set_note_db", function(d, a) {
    if (typeof a.data != "undefined") {
        db_name = a.data
    }
    if (typeof a.pageCount != "undefined") {
        pageCount = a.pageCount
    }
    if (typeof a.currentPage != "undefined") {
        currentPage = a.currentPage
    }
    if (typeof a.notebook_row_id != "undefined") {
        g_notebook_row_id = a.notebook_row_id
    }
    if (currentPage == 0) {
        currentPage = pageCount
    }
    changeCurrentDB(db_name, currentPage, pageCount);
    updateTitle();
    if (ebdic_mode == 2) {
        setStatus(2);
        ws.send({
            cmd: "req_get_note",
            page: currentPage,
            refresh: 1
        })
    } else {
        createCookie("currentPage", currentPage);
        toastr.info(res_string_toastr_current_db + current_database_file);
        if (g_use_search_mode_hightlight && ebdic_mode == 1 && g_go_book_index >= 0 && g_go_position) {
            var c = $("#search_text").val().trim();
            ws.send({
                cmd: "req_go_to_eb_position",
                data: g_go_position,
                scrolly: scrolly,
                keyword: c
            })
        }
    }
});
ws.addResponseEvent("rsp_get_note", function(g, d) {
    wordlist = [];
    type = 0;
    if (typeof d.data != "undefined") {
        wordlist = d.data
    }
    if (typeof d.type != "undefined") {
        type = d.type
    }
    currentPage = d.currentPage;
    pageCount = d.pageCount;
    db_name = d.current_database_file;
    changeCurrentDB(db_name, currentPage, pageCount);
    setMode(2);
    myhistory.clear();
    updateNav();
    createCookie("currentPage", currentPage);
    createCookie("current_database_file", current_database_file);
    if (wordlist.length > 0 && type == 0) {
        value = wordlist[0];
        var l = "<!--note ";
        index = value.lastIndexOf(l);
        myhistory.add(value);
        parseGoToPage(value);
        if (g_go_note == 1 && ebdic_mode == 2) {
            g_note_page = g_go_page;
            g_note_offset = g_go_offset;
            g_note_book_index = g_go_book_index;
            g_note_keyword = g_go_keyword;
            g_note_db_name = g_go_db_name;
            g_note_custom_word_row_id = g_go_custom_word_row_id
        }
        updateNav();
        g_cutom_word_name = "";
        if (index != -1) {
            note_info = value.substring(index + l.length, value.length - 3);
            t = note_info.trim().split(":");
            p_book_index = parseInt(t[0]);
            p_page = parseInt(t[1]);
            p_offset = parseInt(t[2]);
            db_pos = parseInt(t[3]);
            keyword = decodeKeyword(t[4]);
            check = parseInt(t[5]);
            var f = /<font[^>]*>[^>]*<\/font> (.*)<ref -2:-[0-9]?:-1> <font color=#F77400><sub><small>.*<!--note [^>]*-->$/;
            var c = value.match(f);
            if (c && c[1]) {
                g_cutom_word_name = c[1].trim()
            }
        } else {
            keyword = ""
        }
        current_word = value;
        $("#search_text").val(keyword);
        $("#search_text").trigger("change");
        if (ebdic_mode == 2) {
            $("#edit_custom_word").attr("disabled", false)
        } else {
            $("#edit_custom_word").attr("disabled", true)
        }
    } else {
        if (type == 0) {
            current_word = ""
        }
    }
    wordlistComplete = wordlist.slice(0);
    for (e = 0; e < wordlist.length; e++) {
        wordlist[e] = adjustDictionaryTitle(wordlist[e])
    }
    var a = -1;
    if (type == 1 || type == 2) {
        a = $("#wordlist").jqxListBox("selectedIndex")
    }
    $("#wordlist").jqxListBox({
        source: wordlist
    });
    changelistfontFamily(settings_list_font_family);
    updateNoteOpBtn();
    if (type == 0) {
        g_resize_set_item_index = true;
        $("#wordlist").jqxListBox("selectedIndex", 0)
    } else {
        if (a >= 0) {
            if (type == 1) {
                g_resize_set_item_index = true
            }
            $("#wordlist").jqxListBox("selectedIndex", a)
        } else {
            if (g_checkbox_selectIndex >= 0) {
                if (type == 1) {
                    g_resize_set_item_index = true
                }
                $("#wordlist").jqxListBox("selectedIndex", g_checkbox_selectIndex)
            }
        }
    }
    g_checkbox_selectIndex = -1;
    updateNoteOpBtn();
    if (pro == 1) {
        if (g_dbs == null ) {
            ws.send({
                cmd: "req_get_notebook_db_file_list",
                type: 0
            })
        } else {}
    }
    if (type == 0) {
        $("#dics_select option").remove();
        for (var e = 0; e < pageCount; e++) {
            if (currentPage == e + 1) {
                $("#dics_select").append($("<option></option>").attr("value", e + 1).attr("selected", true).text(e + 1))
            } else {
                $("#dics_select").append($("<option></option>").attr("value", e + 1).attr("selected", false).text(e + 1))
            }
        }
    }
    if (type == 1) {
        setStatus(0)
    }
});
ws.error = function(a, c) {
    log("Server Error %0", a);
    toastr.options.timeOut = 0;
    if (c) {
        msg = res_string_toastr_unable_connect + "<br>cmd:&nbsp;" + c
    } else {
        msg = res_string_toastr_unable_connect
    }
    setStatus(0);
    toastr.error(msg);
    toastr.options.timeOut = 2000
}
;
ws.close = function() {
    log("WebSocket Close");
    toastr.options.timeOut = 0;
    toastr.error("Websocket disconnected. Reset Server and refresh browser!!");
    toastr.options.timeOut = 2000
}
;
ws.addResponseEvent("rsp_check_dic_exist", function(d, a) {
    data = 1;
    data = a.data;
    if (data >= 0) {
        myhistory.clear();
        myhistory.add(current_word);
        updateNav();
        setStatus(2);
        parseGoToPage(current_word);
        var c = $("#search_text").val().trim();
        ws.send({
            cmd: "req_go_to_eb_position",
            data: current_word,
            keyword: c
        })
    } else {
        toastr.warning("The dictionary has not existed!!")
    }
});
$(document).ready(function() {
    toastr.options.closeButton = true;
    toastr.options.timeOut = 2000;
    toastr.options.positionClass = "toast-bottom-center";
    updateNav();
    ws.send({
        cmd: "req_get_theme",
        data: "0"
    });
    ws.send({
        cmd: "req_settings_data"
    });
    ws.send({
        cmd: "req_get_history_words"
    });
    $("#search_text").focus(function() {});
    $(".clearable").clearSearch({
        callback: function() {},
        toggle: toggleAutoComplete,
        longClick: clearSearchLongClick
    });
    $("#add_btn").attr("disabled", false);
    $("#rom_to_hina_btn").attr("disabled", false);
    $("#setting_btn").attr("disabled", false);
    $("#prev_paragraph_btn").attr("disabled", false);
    $("#next_paragraph_btn").attr("disabled", false);
    $("#menu_btn").attr("disabled", false);
    $("#flashcard_btn").attr("disabled", false);
    $("#checkbox_btn").attr("disabled", true);
    $("#delete_note_btn").attr("disabled", true);
    $("#tag_note_btn").attr("disabled", true);
    $("#custom_word").attr("disabled", false);
    $("#edit_custom_word").attr("disabled", true);
    preloadImage("./img/notechecked.png", "./img/disconnect.png", "./img/loading.gif", "./img/highlight0.png", "./img/highlight1.png", "./img/highlight2.png");
    initWordList();
    resize(g_list_ratio);
    $("#maintool select").click(function(g) {
        if (checkSearchHighlightExist()) {
            g.preventDefault();
            g.stopPropagation();
            return
        }
    });
    if (isFirefox) {
        $(".button_bottom img").css("vertical-align", "-2px");
        $("#rom_to_hina_btn").css("font-size", "14px")
    } else {
        if (isChrome) {
            $(".button_bottom img").css("vertical-align", "bottom");
            $("#rom_to_hina_btn").css("font-size", "12px")
        } else {
            $(".button_bottom img").css("vertical-align", "middle");
            $("#rom_to_hina_btn").css("font-size", "14px")
        }
    }
    debug_btn = $("#debug_btn");
    if (debug_btn) {
        $("#debug_btn").click(function(g) {
            if (!checkConnect()) {
                return
            }
            label = $("#debug_text").val();
            log("[debug click] label=" + label);
            if (debug == true) {
                webSocket.send({
                    cmd: "req_get_debug_info",
                    data: label,
                    on: "0"
                })
            } else {
                webSocket.send({
                    cmd: "req_get_debug_info",
                    data: label,
                    on: "1"
                })
            }
        })
    }
    $("#dics_select").change(function() {
        log("[selected] value =" + $(this).val());
        if (ebdic_mode == 2) {
            if (!checkConnect()) {
                return
            }
            var g = $(this).val();
            log("value=" + g);
            setStatus(2);
            ws.send({
                cmd: "req_get_note",
                page: g
            })
        } else {
            dic = $(this).val();
            updateViewDics(dic)
        }
    });
    $("#search_method_select").change(function() {
        var g = false;
        if ($(this).val() == 5) {
            g = true;
            $("#search_method_select").prop("selectedIndex", searchMethod)
        }
        if (!checkConnect()) {
            return
        }
        if (g) {
            closeMultiSearchDialog();
            if (g_current_use_dics_index < 0 || g_haveMultiSearch == 0) {
                handleShowSelectMultiSearchDicsDialog()
            } else {
                handleShowMultiSearch(g_current_use_dics_index)
            }
            return
        }
        log("[selected] value =" + $(this).val());
        searchMethod = $(this).val();
        if ($("#search_text").val()) {
            setStatus(1)
        }
        ws.send({
            cmd: "req_set_search_method",
            data: searchMethod
        })
    });
    $("#search_text").focus(function() {
        var g = $(this);
        g.mouseup(function() {
            g.unbind("mouseup");
            return false
        })
    });
    $("#wordlist").change(function(g) {});
    $("#search_text").keyup(function(l) {
        log("e.which=" + l.which);
        if (l.which == 113) {
            $("#search_text").select()
        } else {
            if (l.which == 13 && $("#search_text").val()) {
                var g = $("#search_text").val();
                if (ws_connect) {
                    send_increment = false;
                    keep_increment_word = null ;
                    setStatus(1);
                    if (searchMethod == 4) {
                        showSearchFullDialog()
                    }
                    g_multi_search_words = null ;
                    if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
                        ws.send({
                            cmd: "req_search",
                            data: convertToKana(g),
                            data2: romnih(g),
                            increment: 0
                        })
                    } else {
                        ws.send({
                            cmd: "req_search",
                            data: convertToKana(g),
                            increment: 0
                        })
                    }
                    addHistoryWords(g);
                    setMode(1)
                }
                checkConnect()
            } else {
                if (l.which == 40) {
                    if (settings_autocomplete == 1) {
                        var g = $("#search_text").val();
                        if (g == "") {
                            $("#search_text").autocomplete({
                                minLength: 0
                            });
                            $("#search_text").autocomplete("search", "");
                            $("#search_text").autocomplete({
                                minLength: 1
                            })
                        } else {}
                    }
                }
            }
        }
    });
    $("#search_text").keydown(function(g) {
        if (ebdic_mode == 2) {
            highlighter.removeAllHighlights()
        }
    });
    function a(g, n) {
        if (!g) {
            return
        }
        if (!g.trim()) {
            return
        }
        if (!n.trim()) {
            addHistoryWords(g);
            return
        }
        var m = g;
        var l = n;
        if (n.length > g.length) {
            m = n;
            l = g
        }
        if (m.startsWith(l)) {
            return
        }
        addHistoryWords(g)
    }
    $("#search_text").on("input", function(l) {
        if (checkSearchHighlightExist(l)) {
            l.preventDefault();
            l.stopPropagation();
            return
        }
        if (g_rom_to_hina == 1 && g_multi_rom_to_hina == 0) {
            var m = romnih($("#search_text").val());
            $("#search_text").val(m)
        }
        input_value = $("#search_text").val();
        if (search_text_input_value == input_value) {
            return
        }
        var n = search_text_input_value;
        search_text_input_value = input_value;
        if (searchMethod == 4) {
            return
        }
        if (ws_connect) {
            if (!send_increment) {
                if (ebdic_mode != 1) {
                    setMode(1)
                }
                var g = $("#search_text").val();
                log("value=" + g);
                send_increment = true;
                keep_increment_word = null ;
                now_searching_word = g;
                setStatus(1);
                g_multi_search_words = null ;
                a(n, g);
                if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
                    ws.send({
                        cmd: "req_search",
                        data: convertToKana(g),
                        data2: romnih(g),
                        increment: only_increment,
                        from_increment: 1
                    })
                } else {
                    ws.send({
                        cmd: "req_search",
                        data: convertToKana(g),
                        increment: only_increment,
                        from_increment: 1
                    })
                }
            } else {
                ws.send({
                    cmd: "req_search_stop",
                    data: now_searching_word
                });
                keep_increment_word = $("#search_text").val();
                log("keep keep_increment_word=" + keep_increment_word)
            }
        }
    });
    $("#search_btn").click(function(l) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        if (window.getSelection().toString()) {
            $("#search_text").val(window.getSelection().toString());
            $("#search_text").trigger("change")
        }
        if ($("#search_text").val()) {
            var g = $("#search_text").val();
            send_increment = false;
            keep_increment_word = null ;
            if (searchMethod == 4) {
                showSearchFullDialog()
            }
            setStatus(1);
            g_multi_search_words = null ;
            if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
                ws.send({
                    cmd: "req_search",
                    data: convertToKana(g),
                    data2: romnih(g),
                    increment: 0
                })
            } else {
                ws.send({
                    cmd: "req_search",
                    data: convertToKana(g),
                    increment: 0
                })
            }
            addHistoryWords(g);
            setMode(1)
        }
    });
    $("#add_btn").longClick(function(g) {
        if (g_flash_card_row_id >= 0) {
            return
        }
        if (pro == 1) {
            if (!checkConnect()) {
                return
            }
            if (!g_highlight_data_string || g_go_page == -4) {
                return
            }
            if (g_dbs == null ) {
                ws.send({
                    cmd: "req_get_notebook_db_file_list",
                    type: 3
                })
            } else {
                showAddWordDBSelectDialog(2)
            }
            g_add_btn_long_press = true
        }
    });
    $("#add_btn").click(function(m) {
        if (g_flash_card_row_id >= 0) {
            return
        }
        if (g_add_btn_long_press) {
            g_add_btn_long_press = false;
            return
        }
        g_add_btn_long_press = false;
        if (!checkConnect()) {
            return
        }
        var l = current_word;
        var g = myhistory.getTop().ref;
        if (ebdic_mode == 2) {
            toastr.warning("Unable to add a word in page mode!!")
        } else {
            if (!l && !g && g_go_page != -4) {
                toastr.warning(res_string_toastr_no_word_added)
            } else {
                if (true) {
                    if (g_dbs == null ) {
                        ws.send({
                            cmd: "req_get_notebook_db_file_list",
                            type: 1
                        })
                    } else {
                        showAddWordDBSelectDialog(0)
                    }
                } else {
                    addWord(current_database_file, 0, 0)
                }
            }
        }
    });
    $("#rom_to_hina_btn").click(function(g) {
        if (g_rom_to_hina == 1) {
            g_rom_to_hina = 0
        } else {
            g_rom_to_hina = 1
        }
        updateRomHina();
        ws.send({
            cmd: "req_set_romaji_to_hiragana",
            data: g_rom_to_hina
        });
        $("#search_text").select()
    });
    $("#yahoo_btn").click(function(l) {
        if (checkSearchHighlightExist()) {
            return
        }
        if (g_webSearchBtnShow) {
            return
        }
        if (true) {
            if (g_web_sites_name_list == null ) {
                setStatus(2);
                ws.send({
                    cmd: "req_get_web_search_site_list",
                    type: 0
                })
            } else {
                showWebSearchDialog(g_web_sites_name_list, g_web_sites_url_list)
            }
        } else {
            var g = "http://search.yahoo.co.jp/search?p=%s \u3068\u306F";
            openWebSearch(g, "Yahoo")
        }
    });
    $("#play_btn").click(function(o) {
        if (!checkConnect()) {
            return
        }
        if (!current_word) {
            return
        }
        var n = current_word;
        var m = n;
        var g = m.indexOf("</font>");
        m = m.substring(g + 7);
        g = m.lastIndexOf("<ref");
        if (g >= 0) {
            m = m.substring(0, g)
        } else {
            g = m.lastIndexOf("<font");
            m = m.substring(0, g);
            m = m.trim()
        }
        m = m.replace(/<\/?[^>]+(>|$)/g, "");
        if (n) {
            var q = $("#audiotag").attr("src");
            $("#audiotag").attr("src", encodeURIComponent(n + ".mp3"));
            q = $("#audiotag").attr("src");
            try {
                document.getElementById("audiotag").play()
            } catch (l) {
                if (locale_language > 2) {
                    toastr.error(res_string_toastr_no_sound_for + m + '" !!')
                } else {
                    toastr.error('"' + m + res_string_toastr_no_sound_for)
                }
            }
        }
    });
    $("#audiotag").on("error", function(m) {
        var n = $("#audiotag").attr("src");
        var l = n.substring(0, n.length - 4);
        _word = decodeURIComponent(l);
        var g = _word.indexOf("</font>");
        _word = _word.substring(g + 7);
        g = _word.lastIndexOf("<ref");
        if (g >= 0) {
            _word = _word.substring(0, g)
        } else {
            g = _word.lastIndexOf("<font");
            _word = _word.substring(0, g);
            _word = _word.trim()
        }
        _word = _word.replace(/<\/?[^>]+(>|$)/g, "");
        if (locale_language > 2) {
            toastr.error(res_string_toastr_no_sound_for + _word + '" !!')
        } else {
            toastr.error('"' + _word + res_string_toastr_no_sound_for)
        }
    });
    $("#history_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        if (isShowHistoryWordsDialog) {
            return
        }
        if (use_on_line_history) {
            showHistoryWordsDialog(g_history_words)
        } else {
            ws.send({
                cmd: "req_get_history_words"
            })
        }
    });
    $("#dics_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (g_search_dics == null ) {
            setStatus(2);
            ws.send({
                cmd: "req_get_dics"
            })
        } else {
            showSearchDicsDialog(g_search_dics, g_search_dic_index, g_current_dics_start_index)
        }
    });
    $("#note_btn").click(function(g) {
        if (g_note_btn_long_press) {
            g_note_btn_long_press = false;
            return
        }
        g_note_btn_long_press = false;
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        disabled = $("#pages_btn").attr("disabled");
        if (disabled) {
            setStatus(2);
            ws.send({
                cmd: "req_get_note",
                page: currentPage
            })
        }
        $("#dics_select option").remove();
        clearViewDicsNav()
    });
    $("#note_btn").longClick(function(g) {
        g_note_btn_long_press = true;
        if (pro == 1) {
            if (!checkConnect()) {
                return
            }
            if (checkSearchHighlightExist()) {
                return
            }
            if (isShowDBSelectDialog) {
                return
            }
            if (g_dbs == null ) {
                ws.send({
                    cmd: "req_get_notebook_db_file_list",
                    type: 2
                })
            } else {
                showDBSelectDialog()
            }
        }
    });
    $("#left_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_get_note",
            page: currentPage - 1
        })
    });
    $("#right_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_get_note",
            page: currentPage + 1
        })
    });
    $("#left_left_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_get_note",
            page: 1
        })
    });
    $("#right_right_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_get_note",
            page: pageCount
        })
    });
    $("#prev_btn").click(function(l) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        if (myhistory.isCanBackward()) {
            myhistory.updateCur(scrolly, g_go_book_index, g_go_page, g_go_offset, g_go_db_name, g_go_custom_word_row_id);
            pos = myhistory.backward();
            updateNav();
            setStatus(2);
            parseGoToPage(pos.ref, 1);
            var g = $("#search_text").val().trim();
            ws.send({
                cmd: "req_go_to_eb_position",
                data: pos.ref,
                scrolly: pos.scrolly,
                history: 1,
                keyword: g
            })
        }
    });
    $("#next_btn").click(function(l) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        if (myhistory.isCanForward()) {
            myhistory.updateCur(scrolly, g_go_book_index, g_go_page, g_go_offset, g_go_db_name, g_go_custom_word_row_id);
            pos = myhistory.forward();
            updateNav();
            setStatus(2);
            parseGoToPage(pos.ref, 1);
            var g = $("#search_text").val().trim();
            ws.send({
                cmd: "req_go_to_eb_position",
                data: pos.ref,
                scrolly: pos.scrolly,
                history: 1,
                keyword: g
            })
        }
    });
    ws.addResponseEvent("rsp_set_dics", function(l, g) {
        if (typeof g.current_use_dics_index != "undefined") {
            g_current_use_dics_index = g.current_use_dics_index
        }
        if (typeof g.haveMultiSearch != "undefined") {
            g_haveMultiSearch = g.haveMultiSearch
        }
        if ($("#search_text").val()) {
            var m = $("#search_text").val();
            send_increment = false;
            keep_increment_word = null ;
            if (searchMethod == 4) {
                showSearchFullDialog()
            }
            g_multi_search_words = null ;
            if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
                ws.send({
                    cmd: "req_search",
                    data: convertToKana(m),
                    data2: romnih(m),
                    increment: 0
                })
            } else {
                ws.send({
                    cmd: "req_search",
                    data: convertToKana(m),
                    increment: 0
                })
            }
            addHistoryWords(m);
            setMode(1)
        } else {
            setStatus(0)
        }
    });
    ws.addResponseEvent("rsp_set_web_search_site_list", function(l, g) {
        setStatus(0)
    });
    ws.addResponseEvent("rsp_get_dics", function(l, g) {
        setStatus(0);
        dic_index = 0;
        dics = [];
        dics_start_index = -1;
        current_use_dics_index = -1;
        if (typeof g.data != "undefined") {
            dics = g.data
        }
        if (typeof g.dic_index != "undefined") {
            dic_index = g.dic_index
        }
        if (typeof g.current_dics_start_index != "undefined") {
            dics_start_index = g.current_dics_start_index
        }
        if (typeof g.current_use_dics_index != "undefined") {
            current_use_dics_index = g.current_use_dics_index
        }
        if (dics.length <= 0) {
            toastr.info("No dictionaries!!");
            return
        }
        g_search_dics = dics;
        g_search_dic_index = dic_index;
        g_current_dics_start_index = dics_start_index;
        g_current_use_dics_index = current_use_dics_index;
        showSearchDicsDialog(dics, dic_index, dics_start_index)
    });
    ws.addResponseEvent("rsp_get_history_words", function(l, g) {
        g_history_words = [];
        if (typeof g.data != "undefined") {
            g_history_words = g.data
        }
        closeHistoryWordsDialog();
        if (!use_on_line_history) {
            history_words = [];
            if (typeof g.data != "undefined") {
                history_words = g.data
            }
            showHistoryWordsDialog(history_words)
        } else {
            initAutoComplete()
        }
    });
    $("#wordlist").on("change", function(l) {
        var g = l.args;
        adjustWordTag()
    });
    $("#wordlist").on("select", function(q) {
        if (g_resize_set_item_index) {
            g_resize_set_item_index = false;
            return
        }
        g_resize_set_item_index = false;
        updateNoteOpBtn();
        if (!checkConnect()) {
            q.preventDefault();
            return
        }
        $("#wordlist").focus();
        var n = q.args;
        if (n) {
            var m = n.index;
            value = wordlistComplete[m];
            current_word = value;
            g_cutom_word_name = "";
            var u = "<!--note ";
            m = value.lastIndexOf(u);
            if (m != -1) {
                note_info = value.substring(m + u.length, value.length - 3);
                t = note_info.trim().split(":");
                p_book_index = parseInt(t[0]);
                p_page = parseInt(t[1]);
                p_offset = parseInt(t[2]);
                db_pos = parseInt(t[3]);
                keyword = decodeKeyword(t[4]);
                check = parseInt(t[5]);
                var o = /<font[^>]*>[^>]*<\/font> (.*)<ref -2:-[0-9]?:-1> <font color=#F77400><sub><small>.*<!--note [^>]*-->$/;
                var g = value.match(o);
                if (g && g[1]) {
                    g_cutom_word_name = g[1].trim()
                }
                $("#search_text").val(keyword);
                $("#search_text").trigger("change")
            }
            myhistory.clear();
            myhistory.add(current_word);
            updateNav();
            setStatus(2);
            parseGoToPage(value);
            if (g_go_note == 1 && ebdic_mode == 2) {
                g_note_page = g_go_page;
                g_note_offset = g_go_offset;
                g_note_book_index = g_go_book_index;
                g_note_keyword = g_go_keyword;
                g_note_db_name = g_go_db_name;
                g_note_custom_word_row_id = g_go_custom_word_row_id
            }
            var l = $("#search_text").val();
            if (g_go_page != -4 && ebdic_mode == 1 && searchMethod != 4 && !checkContentSearch(l.trim())) {
                ws.send({
                    cmd: "req_go_to_eb_position",
                    data: value,
                    keyword: l,
                    getHit: 1
                })
            } else {
                ws.send({
                    cmd: "req_go_to_eb_position",
                    data: value,
                    keyword: l
                })
            }
            if (l && ebdic_mode != 2) {
                addHistoryWords(l)
            }
            if (ebdic_mode == 2) {
                $("#edit_custom_word").attr("disabled", false)
            } else {
                $("#edit_custom_word").attr("disabled", true)
            }
        }
    });
    $("#pages_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (isShowNotebookPagesDialog) {
            return
        }
        showNotebookPagesDialog()
    });
    $("#prev_dic_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        if (ebdic_mode == 2) {
            setStatus(2);
            ws.send({
                cmd: "req_get_note",
                page: currentPage - 1
            })
        } else {
            view_dic_index--;
            updateViewDics(view_index_dic_map[view_dic_index]);
            dic_index = view_dic_index;
            if (view_dics_size >= 2) {
                dic_index = view_dic_index + 1
            }
            document.getElementById("dics_select").selectedIndex = dic_index
        }
    });
    $("#next_dic_btn").click(function() {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        if (ebdic_mode == 2) {
            setStatus(2);
            ws.send({
                cmd: "req_get_note",
                page: currentPage + 1
            })
        } else {
            view_dic_index++;
            updateViewDics(view_index_dic_map[view_dic_index]);
            dic_index = view_dic_index;
            if (view_dics_size >= 2) {
                dic_index = view_dic_index + 1
            }
            document.getElementById("dics_select").selectedIndex = dic_index
        }
    });
    $("#setting_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist()) {
            return
        }
        if (g_show_setting_dialog) {
            return
        }
        showSettingDialog()
    });
    $("#content").scroll(function() {
        scrolly = $("#content").scrollTop()
    });
    window.onbeforeunload = function(g) {
        if (isShowSearchFullDialog) {
            log("onbeforeunload");
            ws.send({
                cmd: "req_search_full_stop"
            })
        }
    }
    ;
    initToolTip();
    initHighlighter();
    function d() {
        if (g_highlight_check_timer != null ) {
            clearTimeout(g_highlight_check_timer);
            g_highlight_check_timer = null
        }
    }
    function f() {
        if ($("#highlight_btn_1").length > 0) {
            $("#highlight_btn_1").remove()
        }
        if ($("#highlight_btn_2").length > 0) {
            $("#highlight_btn_2").remove()
        }
    }
    function c() {
        g_highlight_check_timer = setTimeout(function() {
            f()
        }, 300)
    }
    function e() {
        g_stop_highlight_over = true;
        setTimeout(function() {
            g_stop_highlight_over = false
        }, 500)
    }
    $("#highlight_btn").hover(function() {
        d();
        if ($("#highlight_btn_1").length > 0 && $("#highlight_btn_2").length > 0) {
            return
        }
        if (g_stop_highlight_over) {
            g_stop_highlight_over = false;
            return
        }
        g_stop_highlight_over = false;
        var g = $("#highlight_btn").offset();
        var m = $("#highlight_btn").outerWidth();
        var q = $("#highlight_btn").outerHeight();
        var l = [2, 1];
        if (g_dynamic_highlight_tool) {
            var l = [0, 1, 2];
            l.splice(g_highlight_color, 1)
        }
        var o = '<button id="highlight_btn_1" style="position:absolute; top:' + (g.top - 2 * q) + "px;left:" + (g.left) + 'px" title=""><img src="./img/highlight' + l[0] + '.png" class="right-tool-img" ></button>';
        var n = '<button id="highlight_btn_2" style="position:absolute; top:' + (g.top - q) + "px;left:" + (g.left) + 'px" title=""><img src="./img/highlight' + l[1] + '.png" class="right-tool-img" ></button>';
        $("#right_tool").before(o + n);
        var u = [res_string_highlight_green, res_string_highlight_orange, res_string_highlight_blue];
        $("#highlight_btn_1").attr("title", u[l[0]]);
        $("#highlight_btn_2").attr("title", u[l[1]]);
        $("#highlight_btn_1").click(function() {
            if (!checkConnect()) {
                return
            }
            if (!isSelectedText()) {
                return
            }
            d();
            f();
            e();
            ws.send({
                cmd: "req_set_highlight_color",
                color: l[0]
            })
        });
        $("#highlight_btn_2").click(function() {
            if (!checkConnect()) {
                return
            }
            if (!isSelectedText()) {
                return
            }
            d();
            f();
            e();
            ws.send({
                cmd: "req_set_highlight_color",
                color: l[1]
            })
        });
        $("#highlight_btn_1").hover(function() {
            d()
        }, function() {
            c()
        });
        $("#highlight_btn_2").hover(function() {
            d()
        }, function() {
            c()
        })
    }, function() {
        c()
    });
    $("#highlight_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (!isSelectedText()) {
            return
        }
        d();
        f();
        e();
        if (g_dynamic_highlight_tool) {
            highlightSelectedText(g_highlight_color)
        } else {
            highlightSelectedText(0)
        }
        unSelect();
        SendHighlightString()
    });
    $("#memo_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (!isSelectedText()) {
            return
        }
        noteSelectedText();
        unSelect()
    });
    $("#eraser_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (!isSelectedText()) {
            return
        }
        h = highlighter.unhighlightSelection();
        if (h.length <= 0) {
            return
        }
        g_delete_highlights = h;
        showConfirmDeleteHighlightDialog(false)
    });
    $("#clear_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        showConfirmDeleteHighlightDialog(true)
    });
    $("#prev_paragraph_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist(g)) {
            return
        }
        if (g_go_book_index < 0) {
            return
        }
        if (g_flash_card_row_id >= 0) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_prev_paragraph",
            page: g_go_page,
            offset: g_go_offset,
            book_index: g_go_book_index
        })
    });
    $("#next_paragraph_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist(g)) {
            return
        }
        if (g_end_book_index < 0) {
            return
        }
        if (g_flash_card_row_id >= 0) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_next_paragraph",
            page: g_end_page,
            offset: g_end_offset,
            book_index: g_end_book_index
        })
    });
    $("#menu_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist(g)) {
            return
        }
        if (isShowMenuDialog) {
            return
        }
        if (g_menu_list == null ) {
            setStatus(2);
            ws.send({
                cmd: "req_get_menu_list"
            })
        } else {
            if (g_menu_list.length <= 0 && g_image_menu_list.length <= 0) {
                toastr.info(res_string_toastr_no_menu);
                return
            }
            showMenuDialog()
        }
    });
    $("#flashcard_btn").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (checkSearchHighlightExist(g)) {
            return
        }
        if (isShowConfirmAddDBDialog) {
            return
        }
        showConfirmAddDBDialog()
    });
    $("#checkbox_btn").click(function(l) {
        if (!checkConnect()) {
            return
        }
        if (ebdic_mode != 2) {
            return
        }
        var g = -1;
        if (g_checkbox == true) {
            g_checkbox = false
        } else {
            g = $("#wordlist").jqxListBox("selectedIndex");
            g_checkbox_selectIndex = g;
            g_checkbox = true
        }
        $("#wordlist").jqxListBox({
            checkboxes: g_checkbox
        });
        g_checkbox_items = [];
        if (g >= 0 && g_checkbox) {
            $("#wordlist").jqxListBox("checkIndex", g)
        }
        if (!g_checkbox && g_checkbox_selectIndex >= 0) {
            g_resize_set_item_index = true;
            $("#wordlist").jqxListBox("selectedIndex", g_checkbox_selectIndex)
        }
        updateNoteOpBtn();
        changelistfontFamily(settings_list_font_family)
    });
    $("#delete_note_btn").click(function(m) {
        if (!checkConnect()) {
            return
        }
        if (ebdic_mode != 2) {
            return
        }
        if (!g_checkbox) {
            selectIndex = $("#wordlist").jqxListBox("selectedIndex");
            if (selectIndex < 0) {
                return
            }
            g_checkbox_items = [];
            var l = $("#wordlist").jqxListBox("getItem", selectIndex);
            var g = /.*<!--note (.*)-->$/;
            k = l.label.match(g);
            if (k && k[1]) {
                t = k[1].trim().split(":");
                book_index = parseInt(t[0]);
                page = parseInt(t[1]);
                offset = parseInt(t[2]);
                db_pos = parseInt(t[3])
            }
            g_checkbox_items.push(db_pos)
        }
        if (g_checkbox_items.length <= 0) {
            return
        }
        g_checkbox_items.sort(function(o, n) {
            a1 = parseInt(o);
            b1 = parseInt(n);
            return a1 > b1
        });
        showConfirmDeleteWordsDialog()
    });
    $("#tag_note_btn").click(function(m) {
        if (!checkConnect()) {
            return
        }
        if (ebdic_mode != 2) {
            return
        }
        if (!g_checkbox) {
            selectIndex = $("#wordlist").jqxListBox("selectedIndex");
            if (selectIndex < 0) {
                return
            }
            g_checkbox_items = [];
            var l = $("#wordlist").jqxListBox("getItem", selectIndex);
            var g = /.*<!--note (.*)-->$/;
            k = l.label.match(g);
            if (k && k[1]) {
                t = k[1].trim().split(":");
                book_index = parseInt(t[0]);
                page = parseInt(t[1]);
                offset = parseInt(t[2]);
                db_pos = parseInt(t[3])
            }
            g_checkbox_items.push(db_pos)
        }
        if (g_checkbox_items.length <= 0) {
            return
        }
        g_checkbox_items.sort(function(o, n) {
            a1 = parseInt(o);
            b1 = parseInt(n);
            return a1 > b1
        });
        setStatus(2);
        ws.send({
            cmd: "req_op_note",
            op_indexes: g_checkbox_items.join(),
            type: 1
        })
    });
    $("#custom_word").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (!checkConnect()) {
            return
        }
        if (isShowChoiceForAddCustomWordDialog) {
            return
        }
        showChoiceForAddCustomWordDialog()
    });
    $("#edit_custom_word").click(function(g) {
        if (!checkConnect()) {
            return
        }
        if (!checkConnect()) {
            return
        }
        if (isShowEditCustomWordDialog || isShowEditEBDicWordDialog) {
            return
        }
        if (g_go_page == -2) {
            showEditCustomWordDialog(false, g_note_row_id, g_cutom_word_name, g_cutom_word_content, (g_go_offset == -1))
        } else {
            if (g_go_page == -3) {
                ws.send({
                    cmd: "req_get_ebdic_word",
                    type: 0,
                    row_id: g_note_row_id
                })
            } else {
                if (g_go_page == -4) {
                    ws.send({
                        cmd: "req_get_ebdic_word",
                        type: 1,
                        row_id: g_note_row_id
                    })
                } else {
                    ws.send({
                        cmd: "req_get_ebdic_word",
                        type: 2,
                        row_id: g_note_row_id
                    })
                }
            }
        }
        return
    });
    $("#wordlist").on("checkChange", function(m) {
        var l = m.args;
        if (l.checked) {
            log("Checked: " + l.label)
        } else {
            log("Unchecked: " + l.label)
        }
        var g = $("#wordlist").jqxListBox("getCheckedItems");
        g_checkbox_items = [];
        $.each(g, function(n) {
            var o = /.*<!--note (.*)-->$/;
            k = this.label.match(o);
            if (k && k[1]) {
                t = k[1].trim().split(":");
                book_index = parseInt(t[0]);
                page = parseInt(t[1]);
                offset = parseInt(t[2]);
                db_pos = parseInt(t[3])
            }
            g_checkbox_items.push(db_pos)
        });
        log(g_checkbox_items);
        if (g_checkbox_items.length > 0) {
            $("#delete_note_btn").attr("disabled", false);
            $("#tag_note_btn").attr("disabled", false)
        } else {
            $("#delete_note_btn").attr("disabled", true);
            $("#tag_note_btn").attr("disabled", true)
        }
        changelistfontFamily(settings_list_font_family)
    });
    $(document).bind("mouseup", function(g) {
        if (handleDivider("mouseup", g)) {
            g.preventDefault();
            return
        }
    });
    $(document).bind("mousedown", function(g) {
        if (handleDivider("mousedown", g)) {
            g.preventDefault();
            return
        }
    });
    $(document).bind("mousemove", function(g) {
        if (handleDivider("mousemove", g)) {
            g.preventDefault();
            return
        }
    });
    g_mouse_down_in_content = false;
    $("#content").bind("mousedown", function(g) {
        g_mouse_down_in_content = true
    });
    $("#content").bind("mouseup", function(l) {
        if (!g_mouse_down_in_content) {
            return
        }
        g_mouse_down_in_content = false;
        selected = isSelectedText();
        if ((selected == true && ebdic_mode == 2) || (selected == true && g_use_search_mode_hightlight && g_notebook_row_id >= 0) || (selected == true && g_searchModeAddHighlight)) {
            if (g_flash_card_row_id < 0) {
                window.setTimeout(function() {
                    checkHighlightButton()
                }, 10)
            }
        } else {
            var g = mobileAndTabletcheck();
            if (!g) {
                disableHighlight()
            }
        }
    });
    setMode(1);
    g_scroll_bar_width = getScrollBarWidth();
    document.getElementById("content").addEventListener("click", function(o) {
        if (g_click_search == 0) {
            return
        }
        var q = o.target;
        if (q && ((q.className == "tabDic") || (q.className == "tabbutton") || (q.onclick) || (q.tagName && q.tagName.toLowerCase() == "a"))) {
            return
        }
        var m = window.getSelection();
        var x = m.toString();
        if (x) {
            return
        }
        while (1) {
            m.modify("extend", "backward", "word");
            var g = m.toString();
            g = g.replace(/[\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E\u3014\u3015\u3010\u3011\uFF01-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF40\uFF5B-\uFF5E]/g, "").trim();
            if (!g.trim()) {
                break
            }
            m.modify("extend", "forward", "word");
            var l = m.toString();
            l = l.replace(/[\x21-\x2F\x3A-\x40\x5B-\x60\x7B-\x7E\u3014\u3015\u3010\u3011\uFF01-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF40\uFF5B-\uFF5E]/g, "").trim();
            if (!l.trim() || g.substr(g.length - l.length) == l) {
                break
            }
            var u = g.trim() + l.trim();
            searchWord(u);
            break
        }
        if (!x) {
            window.getSelection().removeAllRanges()
        }
    })
});
function searchWord(a) {
    if (searchMethod == 4) {
        return
    }
    setStatus(1);
    g_multi_search_words = null ;
    if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
        ws.send({
            cmd: "req_search",
            data: convertToKana(a),
            data2: romnih(a),
            increment: 0
        })
    } else {
        ws.send({
            cmd: "req_search",
            data: convertToKana(a),
            increment: 0
        })
    }
    $("#search_text").val(a);
    addHistoryWords(a);
    setMode(1)
}
function isEmpty(c) {
    if (c == null ) {
        return true
    }
    if (c.length > 0) {
        return false
    }
    if (c.length === 0) {
        return true
    }
    for (var a in c) {
        if (hasOwnProperty.call(c, a)) {
            return false
        }
    }
    return true
}
function checkHighlightButton() {
    selected = isSelectedText();
    var a = mobileAndTabletcheck();
    if (ebdic_mode == 2 && go_note_status == 1) {
        disableHighlight()
    } else {
        if ((a || selected == true) && ebdic_mode == 2 && g_on_notebook_page) {
            enableHighlight()
        } else {
            if ((a || selected == true) && ebdic_mode != 2 && g_use_search_mode_hightlight && g_notebook_row_id >= 0) {
                enableHighlight()
            } else {
                if ((a || selected == true) && g_searchModeAddHighlight && ebdic_mode != 2) {
                    enableHighlight()
                } else {
                    disableHighlight()
                }
            }
        }
    }
}
function disableHighlight() {
    $("#highlight_btn").attr("disabled", true);
    $("#memo_btn").attr("disabled", true);
    $("#eraser_btn").attr("disabled", true);
    if (ebdic_mode == 2 && !isEmpty(notebook_highlight_map)) {
        $("#clear_btn").attr("disabled", false)
    } else {
        if (ebdic_mode == 1 && g_use_search_mode_hightlight && g_notebook_row_id >= 0 && !isEmpty(notebook_highlight_map)) {
            $("#clear_btn").attr("disabled", false)
        } else {
            if (ebdic_mode != 2 && g_searchModeAddHighlight && !isEmpty(notebook_highlight_map)) {
                $("#clear_btn").attr("disabled", false)
            } else {
                $("#clear_btn").attr("disabled", true)
            }
        }
    }
}
function enableHighlight() {
    $("#highlight_btn").attr("disabled", false);
    $("#memo_btn").attr("disabled", false);
    $("#eraser_btn").attr("disabled", false);
    if (ebdic_mode == 2 && !isEmpty(notebook_highlight_map)) {
        $("#clear_btn").attr("disabled", false)
    } else {
        if (ebdic_mode == 1 && g_use_search_mode_hightlight && g_notebook_row_id >= 0 && !isEmpty(notebook_highlight_map)) {
            $("#clear_btn").attr("disabled", false)
        } else {
            if (ebdic_mode != 2 && g_searchModeAddHighlight && !isEmpty(notebook_highlight_map)) {
                $("#clear_btn").attr("disabled", false)
            } else {
                $("#clear_btn").attr("disabled", true)
            }
        }
    }
}
function initHighlighter() {
    rangy.init();
    highlighter = rangy.createHighlighter();
    highlighter.addClassApplier(rangy.createClassApplier("highlight", {
        ignoreWhiteSpace: true,
        tagNames: ["span", "a"]
    }));
    highlighter.addClassApplier(rangy.createClassApplier("highlight1", {
        ignoreWhiteSpace: true,
        tagNames: ["span", "a"]
    }));
    highlighter.addClassApplier(rangy.createClassApplier("highlight2", {
        ignoreWhiteSpace: true,
        tagNames: ["span", "a"]
    }));
    highlighter.addClassApplier(rangy.createClassApplier("note", {
        ignoreWhiteSpace: true,
        elementTagName: "a",
        elementProperties: {
            href: "#",
            onclick: function() {
                var a = highlighter.getHighlightForElement(this);
                if (a) {
                    id = highlighter.serializeSingle(a);
                    id = id.substring("type:textContent|".length);
                    comment = notebook_highlight_map[id][0];
                    tag = notebook_highlight_map[id][1];
                    showEditNoteDialog(id, comment, tag, false)
                }
                return false
            },
            onmouseover: function() {
                var a = highlighter.getHighlightForElement(this);
                if (a) {
                    id = highlighter.serializeSingle(a);
                    id = id.substring("type:textContent|".length);
                    comment = notebook_highlight_map[id][0];
                    $(this).attr("title", comment)
                }
            },
            onmouseout: function() {
                $(this).removeAttr("title")
            }
        }
    }))
}
var highlight_offset = 0;
function getSelectedText() {
    if (window.getSelection) {
        return window.getSelection().toString()
    } else {
        if (document.selection) {
            return document.selection.createRange().text
        }
    }
    return ""
}
function isSelectedText() {
    var a = getSelectedText();
    if (a) {
        return true
    } else {
        return false
    }
}
function isInContain(c) {
    for (i = 0; i < c.length; i++) {
        data = highlighter.serializeSingle(c[i]);
        data = data.substring("type:textContent|".length);
        s = data.split("$");
        var d = parseInt(s[0]);
        var a = parseInt(s[1]);
        if (d < highlight_offset) {
            return false
        } else {
            return true
        }
    }
    return false
}
function highlightSelectedText(f) {
    var g = "highlight" + f;
    if (f == 0) {
        g = "highlight"
    }
    h = highlighter.highlightSelection(g, {
        exclusive: false
    });
    if (g_test_highlight) {
        return
    }
    if (!isInContain(h)) {
        highlighter.unhighlightSelection();
        unSelect();
        return
    }
    for (i = 0; i < h.length; i++) {
        data = highlighter.serializeSingle(h[i]);
        base_data = base0HighlightSingle(highlight_offset, data, true);
        id = data.substring("type:textContent|".length);
        var d = true;
        if (h.length >= 2) {
            var a = id.replace(/\$[^\$]*\$[^\$]*\$$/g, "");
            for (var c in notebook_highlight_map) {
                console.log("key=" + c);
                if (c.startsWith(a)) {
                    d = false;
                    break
                }
            }
        }
        var e = [];
        e.push("");
        e.push(h[i].getText());
        if (d) {
            notebook_highlight_map[id] = e
        }
    }
}
function noteSelectedText() {
    h = highlighter.highlightSelection("note", {
        exclusive: false
    });
    if (!isInContain(h)) {
        highlighter.unhighlightSelection();
        unSelect();
        return
    }
    var a = "";
    var c = "";
    var d = "";
    for (i = 0; i < h.length; i++) {
        data = highlighter.serializeSingle(h[i]);
        base_data = base0HighlightSingle(highlight_offset, data, true);
        comment = "";
        tag = h[i].getText();
        id = data.substring("type:textContent|".length);
        addNotebookHighlight(comment, tag, data);
        log("base_data=" + base_data);
        if (i == 0) {
            a = comment;
            c = tag;
            d = id
        }
    }
    showEditNoteDialog(d, a, c, true)
}
function updateNotebookHighlightComment(d, c, a) {
    p = notebook_highlight_map[d];
    p[0] = c;
    p[1] = a
}
function sortNotebookHighlight() {
    if (sort_notebook_highlight.length > 1) {
        sort_notebook_highlight.sort(function(c, a) {
            if (c.start > a.start || (c.start == a.start && c.end > a.end)) {
                return 1
            } else {
                if (c.start < a.start || (c.start == a.start && c.end < a.end)) {
                    return -1
                } else {
                    return 0
                }
            }
        })
    }
}
function addNotebookHighlight(g, o, f) {
    f = f.substring("type:textContent|".length);
    var c = [];
    c.push(g);
    c.push(o);
    notebook_highlight_map[f] = c;
    try {
        var n = f.split("$");
        var a = parseInt(n[0]);
        var d = parseInt(n[1]);
        var m = n[3];
        new_id = a + "$" + d + "$" + n[2] + "$";
        if (m.startsWith("note")) {
            new_id += m + "$";
            np = {};
            np.note_id = new_id;
            np.start = a;
            np.end = d;
            np.type = 1;
            np.sType = m;
            sort_notebook_highlight.push(np)
        } else {
            new_id += m + "$"
        }
    } catch (l) {
        return
    }
    sortNotebookHighlight()
}
var g_delete_highlights = null ;
function removeHighlightFromSelectedText(a) {
    var c;
    if (!a) {
        c = highlighter.unhighlightSelection()
    } else {
        c = a
    }
    for (i = 0; i < c.length; i++) {
        id = highlighter.serializeSingle(c[i]);
        id = id.substring("type:textContent|".length);
        delete notebook_highlight_map[id];
        s = id.split("$");
        if (s[3] == "note") {
            delete_index = -1;
            for (j = 0; j < sort_notebook_highlight.length; j++) {
                np = sort_notebook_highlight[j];
                if (np.note_id == id) {
                    delete_index = j;
                    break
                }
            }
            if (delete_index >= 0) {
                sort_notebook_highlight.splice(delete_index, 1)
            }
        }
    }
    highlighter.removeAllHighlights();
    data = generateRangyHighlightString();
    if (data) {
        highlighter.deserialize(data)
    }
}
function removeAllHighlight() {
    highlighter.removeAllHighlights();
    notebook_highlight_map = {};
    sort_notebook_highlight = [];
    g_highlight_data_string = ""
}
var g_highlight_data_string = "";
function SendHighlightString() {
    data_string = generateBase0HighlightString();
    if (g_searchModeAddHighlight) {
        g_highlight_data_string = data_string
    }
    if (ebdic_mode != 2 && g_use_search_mode_hightlight && g_notebook_row_id >= 0) {
        setStatus(2);
        ws.send({
            cmd: "req_set_highlight",
            data: data_string,
            notebook_row_id: g_notebook_row_id,
            page: g_go_page,
            offset: g_go_offset,
            book_index: g_go_book_index
        })
    } else {
        if (ebdic_mode == 2) {
            setStatus(2);
            ws.send({
                cmd: "req_set_highlight",
                data: data_string,
                db_pos: g_go_db_pos,
                page: g_go_page,
                offset: g_go_offset,
                book_index: g_go_book_index
            })
        } else {}
    }
}
function generateBase0HighlightString() {
    var c = "";
    var d = 0;
    for (var a in notebook_highlight_map) {
        d++;
        p = notebook_highlight_map[a];
        comment = p[0];
        tag = p[1];
        a = base0HighlightSingle(highlight_offset, a, false);
        if (d == 1) {
            c = a + "@" + encodeNote(comment) + "@" + encodeNote(tag)
        } else {
            c += "#" + a + "@" + encodeNote(comment) + "@" + encodeNote(tag)
        }
    }
    return c
}
function generateRangyHighlightString() {
    var c = "type:textContent";
    var d = 0;
    for (var a in notebook_highlight_map) {
        d++;
        c += "|" + a
    }
    if (d > 0) {
        return c
    } else {
        return ""
    }
}
function unSelect() {
    window.getSelection().removeAllRanges();
    disableHighlight()
}
function deleteHistoryWord(a) {
    a = a.trim();
    if (use_on_line_history && g_history_words != null ) {
        for (i = 0; i < g_history_words.length; i++) {
            if (a == g_history_words[i]) {
                g_history_words.splice(i, 1);
                break
            }
        }
    }
}
var g_recent_add_history_word = "";
function addHistoryWords(a, c) {
    a = a.trim();
    if (!a) {
        return
    }
    if (checkContentSearch(a)) {
        return
    }
    if (g_recent_add_history_word == a) {
        return
    }
    if (g_add_history_timer) {
        clearTimeout(g_add_history_timer)
    }
    g_recent_add_history_word = a;
    if (use_on_line_history && g_history_words != null ) {
        for (i = 0; i < g_history_words.length; i++) {
            if (a == g_history_words[i]) {
                g_history_words.splice(i, 1);
                break
            }
        }
        g_history_words.unshift(a)
    }
    if (!c) {
        ws.send({
            cmd: "req_add_history_word",
            data: a
        })
    }
}
function closeDBSelectDialog() {
    if (isShowDBSelectDialog) {
        $("#dialog-db-select").dialog("close");
        $("#dialog-db-select").dialog("destroy").remove()
    }
    isShowDBSelectDialog = false;
    g_note_btn_long_press = false
}
function showDBSelectDialog() {
    if (isShowDBSelectDialog) {
        return
    }
    beforeShowDialog();
    html_db_options = [];
    html_db_select = "";
    cur_db_index = 0;
    select_db = current_database_file;
    if (g_dbs != null ) {
        for (var a = 0; a < g_dbs.length; a++) {
            if (current_database_file == g_dbs[a]) {
                cur_db_index = a
            }
            html_db_options.push(g_dbs[a])
        }
    } else {
        return
    }
    $("body").append('<div id="dialog-db-select" title="' + dialog_title_db_select_label + '"><div style="margin: 0 auto; text-align: center;"><p><div id="DBlist" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-db-select").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 400,
        height: (isChrome ? 370 : 380),
        closeOnEscape: false,
        beforeClose: function(c, d) {
            isShowDBSelectDialog = false;
            g_note_btn_long_press = false
        },
        close: function(c, d) {
            $("#dialog-db-select").dialog("destroy").remove();
            isShowDBSelectDialog = false;
            g_note_btn_long_press = false
        }
    });
    $("#DBlist").jqxListBox({
        theme: "base",
        source: html_db_options,
        width: "340px",
        height: (isChrome ? 280 : 280) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#DBlist.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#DBlist").jqxListBox("selectedIndex", cur_db_index);
    $("#DBlist").on("change", function(d) {
        var c = d.args;
        var e = c.item.value;
        if (!checkConnect()) {
            return
        }
        log("value=" + e);
        ws.send({
            cmd: "req_set_note_db",
            data: e
        });
        closeDBSelectDialog()
    });
    isShowDBSelectDialog = true;
    $("#dialog-db-select").css("fontFamily", ui_widget_font_family)
}
function closeAddWordDBSelectDialog() {
    if (isShowAddWordDBSelectDialog) {
        $("#dialog-add-word-db-select").dialog("close");
        $("#dialog-add-word-db-select").dialog("destroy").remove()
    }
    isShowAddWordDBSelectDialog = false;
    g_add_btn_long_press = false
}
var g_add_word_db_select_index = -1;
var g_add_word_db_select_index_temp = -1;
function showAddWordDBSelectDialog(a) {
    if (g_dbs.length == 1) {
        addWord(current_database_file, a, 0);
        return
    }
    if (isShowAddWordDBSelectDialog) {
        return
    }
    beforeShowDialog();
    html_db_options = [];
    html_db_select = "";
    cur_db_index = 0;
    if (g_dbs != null ) {
        for (var c = 0; c < g_dbs.length; c++) {
            if (current_database_file == g_dbs[c]) {
                cur_db_index = c
            }
            html_db_options.push(g_dbs[c])
        }
    } else {
        return
    }
    if (g_add_word_db_select_index < 0) {
        g_add_word_db_select_index = cur_db_index
    } else {
        if (g_add_word_db_select_index >= g_dbs.length) {
            g_add_word_db_select_index = cur_db_index
        }
    }
    g_add_word_db_select_index_temp = g_add_word_db_select_index;
    select_db = g_dbs[g_add_word_db_select_index];
    var d = dialog_title_add_word_db_label;
    if (a == 1) {
        d = dialog_title_add_search_word_db_label
    } else {
        if (a == 2 || a == 3) {
            d = dialog_title_add_cutom_word_db_label
        }
    }
    $("body").append('<div id="dialog-add-word-db-select" title="' + d + '"><div style="margin: 0 auto; text-align: center;"><p><div id="addwordDBlist" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-add-word-db-select").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 400,
        height: (isChrome ? 455 - 30 : 490 - 60),
        closeOnEscape: false,
        beforeClose: function(e, f) {
            isShowAddWordDBSelectDialog = false;
            g_add_btn_long_press = false
        },
        close: function(e, f) {
            $("#dialog-add-word-db-select").dialog("destroy").remove();
            isShowAddWordDBSelectDialog = false;
            g_add_btn_long_press = false
        },
        buttons: [{
            text: dialog_ok_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                g_add_word_db_select_index = g_add_word_db_select_index_temp;
                addWord(select_db, a, 0);
                closeAddWordDBSelectDialog()
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    $("#addwordDBlist").jqxListBox({
        theme: "base",
        source: html_db_options,
        width: "340px",
        height: (isChrome ? 280 : 280) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#addwordDBlist.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#addwordDBlist").jqxListBox("selectedIndex", g_add_word_db_select_index);
    $(".jqx-fill-state-focus-base").css("borderColor", "#ff0000");
    $("#addwordDBlist").on("change", function(g) {
        var f = g.args;
        var l = f.item.value;
        var e = f.item.index;
        if (!checkConnect()) {
            return
        }
        log("value=" + l);
        select_db = l;
        g_add_word_db_select_index_temp = e
    });
    isShowAddWordDBSelectDialog = true;
    $("#dialog-add-word-db-select").css("fontFamily", ui_widget_font_family)
}
var isShowWebSearchDialog = false;
function closeWebSearchDialog() {
    if (isShowWebSearchDialog) {
        $("#dialog-web-search").dialog("close");
        $("#dialog-web-search").dialog("destroy").remove()
    }
    isShowWebSearchDialog = false;
    g_webSearchBtnShow = false
}
function SendAndRefreshWebSearch() {
    SendWebSearchList();
    html_options = [];
    for (i = 0; i < g_web_sites_name_list.length; i++) {
        htm_items = '<img id="editWebSearch' + i + '" tapIndex="' + i + '" src="./img/memo.png" class="WebSearchBtn editWebSearch" width=20  ><img id="deleteWebSearch' + i + '" tapIndex="' + i + '" src="./img/clear.png" class="WebSearchBtn deleteWebSearch" width=20 ><span class="websearch_name" style="padding-left:5px">' + g_web_sites_name_list[i] + "</span>";
        html_options.push(htm_items)
    }
    $("#webSearchList").jqxListBox({
        source: html_options
    });
    g_webSearchBtnShow = false;
    $("#dialog-web-search .WebSearchBtn").hide()
}
var g_webSearchBtnShow = false;
function showWebSearchDialog(c, a) {
    if (g_webSearchBtnShow) {
        return
    }
    beforeShowDialog();
    var e = [];
    var d = 0;
    for (d = 0; d < g_web_sites_name_list.length; d++) {
        htm_items = '<img id="editWebSearch' + d + '" tapIndex="' + d + '" src="./img/memo.png" class="WebSearchBtn editWebSearch" width=20  ><img id="deleteWebSearch' + d + '" tapIndex="' + d + '" src="./img/clear.png" class="WebSearchBtn deleteWebSearch" width=20 ><span class="websearch_name" style="padding-left:5px">' + g_web_sites_name_list[d] + "</span>";
        e.push(htm_items)
    }
    $("body").append('<div id="dialog-web-search" title="' + dialog_title_web_search_label + '"><div style="margin: 0 auto; text-align: center;"><p><div id="webSearchList" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-web-search").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 450,
        height: (isChrome ? 455 : 490),
        closeOnEscape: false,
        beforeClose: function(g, l) {
            isShowWebSearchDialog = false;
            g_webSearchBtnShow = false
        },
        close: function(g, l) {
            $("#dialog-web-search").dialog("destroy").remove();
            isShowWebSearchDialog = false;
            g_webSearchBtnShow = false
        },
        buttons: [{
            text: dialog_add_label,
            click: function() {
                if (!checkConnect()) {
                    return
                }
                showEditWebSearchDialog(true, -1)
            }
        }, {
            text: dialog_edit_label,
            click: function() {
                if (!checkConnect()) {
                    return
                }
                if (g_webSearchBtnShow) {
                    $("#dialog-web-search .WebSearchBtn").hide();
                    $("#dialog-web-search .websearch_name").css("padding-left", "5px");
                    g_webSearchBtnShow = false
                } else {
                    $("#dialog-web-search .WebSearchBtn").show();
                    $("#dialog-web-search .websearch_name").css("padding-left", "72px");
                    g_webSearchBtnShow = true
                }
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    $("#webSearchList").jqxListBox({
        theme: "base",
        source: e,
        width: "400px",
        height: (isChrome ? 315 : 350) + "px",
        fontSize: 18,
        websearch: true,
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#webSearchList.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    var f = -1;
    $("#webSearchList").on("change", function(m) {
        var l = m.args;
        var n = l.item.index;
        var g = c[n];
        f = n;
        if (f < 0) {
            return
        }
        closeWebSearchDialog();
        openWebSearch(a[f], g)
    });
    g_webSearchBtnShow = false;
    $("#dialog-web-search .WebSearchBtn").hide();
    $("#dialog-web-search .WebSearchBtn").click(function(m) {
        var g = $(this).attr("tapIndex");
        var n = $(this).attr("id");
        var l = "editWebSearch" + g;
        if (n == l) {
            showEditWebSearchDialog(false, g)
        } else {
            showConfirmDeleteWebSearchDialog(g)
        }
        m.preventDefault();
        m.stopPropagation()
    });
    isShowWebSearchDialog = true;
    $("#dialog-web-search").css("fontFamily", ui_widget_font_family)
}
var isShowConfirmDeleteWebSearchDialog = false;
function closeConfirmDeleteWebSearchDialog() {
    if (isShowConfirmDeleteWebSearchDialog) {
        $("#dialog-confirm-delete-web-search").dialog("close");
        $("#dialog-confirm-delete-web-search").dialog("destroy").remove()
    }
    isShowConfirmDeleteWebSearchDialog = false
}
function showConfirmDeleteWebSearchDialog(a) {
    if (isShowConfirmDeleteWebSearchDialog) {
        return
    }
    beforeShowDialog();
    message = dialog_message_delete_highlight;
    $("body").append('<div id="dialog-confirm-delete-web-search" title="' + dialog_delete_label + '"><span style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + message + "</span></div>");
    $("#dialog-confirm-delete-web-search").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(c, d) {
            isShowConfirmDeleteWebSearchDialog = false
        },
        close: function(c, d) {
            $("#dialog-confirm-delete-words").dialog("destroy").remove();
            isShowConfirmDeleteWebSearchDialog = false
        },
        buttons: [{
            text: dialog_yes_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                g_web_sites_name_list.splice(a, 1);
                g_web_sites_url_list.splice(a, 1);
                g_web_sites_font_size_list.splice(a, 1);
                SendAndRefreshWebSearch();
                $(this).dialog("close")
            }
        }, {
            text: dialog_no_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmDeleteWebSearchDialog = true;
    $("#dialog-confirm-delete-web-search").css("fontFamily", ui_widget_font_family)
}
var isShowChoiceHighlightColorDialog = false;
function closeChoiceHighlightColorDialog() {
    if (isShowChoiceHighlightColorDialog) {
        $("#dialog-choice-highlight-color").dialog("close");
        $("#dialog-choice-highlight-color").dialog("destroy").remove()
    }
    isShowChoiceHighlightColorDialog = false;
    g_choice_highlight_color_dialog = null
}
var g_choice_highlight_color_dialog = null ;
function showChoiceHighlightColorDialog() {
    if (isShowChoiceHighlightColorDialog) {
        return
    }
    beforeShowDialog();
    var a = [];
    a.push(res_string_highlight_green);
    a.push(res_string_highlight_orange);
    a.push(res_string_highlight_blue);
    $("body").append('<div id="dialog-choice-highlight-color" title="' + dialog_title_choice_highlight_color + '"><div style="margin: 0 auto; text-align: center;"><p><div id="HighlightColorChoiceList" style="margin: 0 auto; text-align: center;" ></div><br><br></div></div>');
    g_choice_highlight_color_dialog = $("#dialog-choice-highlight-color").dialog({
        modal: false,
        draggable: true,
        resizable: false,
        width: 250,
        closeOnEscape: false,
        beforeClose: function(c, d) {
            isShowChoiceHighlightColorDialog = false
        },
        close: function(c, d) {
            $("#dialog-choice-highlight-color").dialog("destroy").remove();
            isShowChoiceHighlightColorDialog = false
        }
    });
    $(g_choice_highlight_color_dialog).dialogExtend({
        minimizable: true,
        maximizable: false,
        collapsable: true,
        dblclick: "minimize",
        minimizeLocation: "right"
    });
    $("#HighlightColorChoiceList").jqxListBox({
        theme: "base",
        source: a,
        width: "200px",
        height: (isChrome ? 65 : 100) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#HighlightColorChoiceList.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#HighlightColorChoiceList").jqxListBox("selectedIndex", g_highlight_color);
    $("#HighlightColorChoiceList").on("change", function(d) {
        var c = d.args;
        var e = c.item.index;
        if (!checkConnect()) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_set_highlight_color",
            color: e
        });
        closeChoiceHighlightColorDialog()
    });
    isShowChoiceHighlightColorDialog = true;
    $("#dialog-choice-highlight-color").css("fontFamily", ui_widget_font_family)
}
var isShowChoiceForAddCustomWordDialog = false;
function closeChoiceForAddCustomWordDialog() {
    if (isShowChoiceForAddCustomWordDialog) {
        $("#dialog-choice-for-add-custom-word").dialog("close");
        $("#dialog-choice-for-add-custom-word").dialog("destroy").remove()
    }
    isShowChoiceForAddCustomWordDialog = false
}
function showChoiceForAddCustomWordDialog(a, d, e) {
    if (isShowChoiceForAddCustomWordDialog) {
        return
    }
    beforeShowDialog();
    var c = [];
    c.push(res_string_choice_custom_word);
    c.push(res_string_choice_web_search);
    c.push(res_string_choice_search_word);
    $("body").append('<div id="dialog-choice-for-add-custom-word" title="' + dialog_title_add_custom_word_label + '"><div style="margin: 0 auto; text-align: center;"><p><div id="CustomWordChoiceList" style="margin: 0 auto; text-align: center;" ></div><br><br></div></div>');
    $("#dialog-choice-for-add-custom-word").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 250,
        closeOnEscape: false,
        beforeClose: function(f, g) {
            isShowChoiceForAddCustomWordDialog = false
        },
        close: function(f, g) {
            $("#dialog-choice-for-add-custom-word").dialog("destroy").remove();
            isShowChoiceForAddCustomWordDialog = false
        }
    });
    $("#CustomWordChoiceList").jqxListBox({
        theme: "base",
        source: c,
        width: "200px",
        height: (isChrome ? 65 : 100) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#CustomWordChoiceList.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#CustomWordChoiceList").jqxListBox("selectedIndex", d);
    $("#CustomWordChoiceList").on("change", function(g) {
        var f = g.args;
        var l = f.item.index;
        if (!checkConnect()) {
            return
        }
        if (l == 0) {
            showEditCustomWordDialog(true)
        } else {
            if (l == 1) {
                showEBDicWordDialog(true, -1, 1, "", "")
            } else {
                showEBDicWordDialog(true, -1, 0, "", "")
            }
        }
        closeChoiceForAddCustomWordDialog()
    });
    isShowChoiceForAddCustomWordDialog = true;
    $("#dialog-choice-for-add-custom-word").css("fontFamily", ui_widget_font_family)
}
var isShowEditCustomWordDialog = false;
function closeEditCustomWordDialog() {
    if (isShowEditCustomWordDialog) {
        $("#dialog-edit-custom-word").dialog("close");
        $("#dialog-edit-custom-word").dialog("destroy").remove()
    }
    isShowEditCustomWordDialog = false
}
function showEditCustomWordDialog(g, c, l, n, a) {
    if (isShowEditCustomWordDialog) {
        return
    }
    beforeShowDialog();
    html_custom_word_name_input = '<input id="edit_custom_word_name_input" style="width:350px;font-family:' + ui_widget_font_family + '">';
    html_custom_word_content_input = '<textarea id="edit_custom_word_content_input" rows="15" cols="35" style="width:470px;resize:none;font-family:' + ui_widget_font_family + '">';
    html_use_tag_html = '&nbsp;&nbsp;<input type="checkbox" id="edit_custom_word_use_html" >&nbsp;' + res_string_edit_word_use_html_label;
    $("body").append('<div id="dialog-edit-custom-word" title="' + (g ? dialog_title_add_custom_word_label : dialog_title_edit_custom_word_label) + '"><div style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + res_string_edit_custom_word_heading + "</div>" + html_custom_word_name_input + html_use_tag_html + "<p>" + html_custom_word_content_input + "</div>");
    $("#dialog-edit-custom-word").dialog({
        modal: true,
        draggable: true,
        resizable: true,
        width: 530,
        closeOnEscape: false,
        beforeClose: function(o, q) {
            isShowEditCustomWordDialog = false
        },
        close: function(o, q) {
            $("#dialog-edit-custom-word").dialog("destroy").remove();
            isShowEditCustomWordDialog = false
        },
        resize: function(o, q) {
            dw = q.size.width - q.originalSize.width;
            dh = q.size.height - q.originalSize.height;
            $("#edit_custom_word_name_input").width(i_w + dw);
            $("#edit_custom_word_content_input").width(a_w + dw);
            $("#edit_custom_word_content_input").height(a_h + dh)
        },
        resizeStop: function(o, q) {
            a_h = $("#edit_custom_word_content_input").height();
            a_w = $("#edit_custom_word_content_input").width();
            i_w = $("#edit_custom_word_name_input").width()
        },
        buttons: [{
            text: dialog_ok_label,
            click: function() {
                if (!checkConnect()) {
                    return
                }
                var o = $("#edit_custom_word_name_input").val();
                var q = $("#edit_custom_word_content_input").val();
                if (o.trim().length <= 0 || q.trim().length <= 0) {
                    toastr.error(res_string_toastr_input_invalid);
                    return
                }
                setStatus(2);
                ws.send({
                    cmd: "req_edit_custom_word",
                    add: (g ? 1 : 0),
                    note_row_id: c,
                    name: o,
                    content: q,
                    useHtml: d
                });
                $(this).dialog("close")
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                var o = $("#edit_custom_word_name_input").val();
                var q = $("#edit_custom_word_content_input").val();
                if (g && o.trim().length <= 0 && q.trim().length <= 0) {
                    $(this).dialog("close")
                } else {
                    if (!g && e == o && m == q && f == d) {
                        $(this).dialog("close")
                    } else {
                        showConfirmExitEditCustomWordDialog()
                    }
                }
            }
        }]
    });
    a_h = $("#edit_custom_word_content_input").height();
    a_w = $("#edit_custom_word_content_input").width();
    i_w = $("#edit_custom_word_name_input").width();
    var d = 0;
    if (!g) {
        $("#edit_custom_word_name_input").val(l);
        if (a) {
            $("#edit_custom_word_content_input").val(n);
            $("#edit_custom_word_use_html").attr("checked", true);
            d = 1
        } else {
            n = htmlToPlainText(n);
            $("#edit_custom_word_content_input").val(n);
            $("#edit_custom_word_use_html").attr("checked", false);
            d = 0
        }
    } else {
        $("#edit_custom_word_name_input").val("");
        $("#edit_custom_word_content_input").val("")
    }
    $("#edit_custom_word_use_html").change(function() {
        if (this.checked) {
            d = 1
        } else {
            d = 0
        }
    });
    var e = l;
    var m = n;
    var f = d;
    isShowEditCustomWordDialog = true;
    $("#dialog-edit-custom-word").css("fontFamily", ui_widget_font_family)
}
var isShowConfirmExitEditCustomWordDialog = false;
function closeConfirmExitEditCustomWordDialog() {
    if (isShowConfirmExitEditCustomWordDialog) {
        $("#dialog-confirm-exit-edit-custom-word").dialog("close");
        $("#dialog-confirm-exit-edit-custom-word").dialog("destroy").remove()
    }
    isShowConfirmExitEditCustomWordDialog = false
}
function showConfirmExitEditCustomWordDialog() {
    if (isShowConfirmExitEditCustomWordDialog) {
        return
    }
    beforeShowDialog();
    message = dialog_confirm_custom_word_exit_title;
    $("body").append('<div id="dialog-confirm-exit-edit-custom-word" title="' + res_string_confirm_exit + '"><span style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + message + "</span></div>");
    $("#dialog-confirm-exit-edit-custom-word").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(a, c) {
            isShowConfirmExitEditCustomWordDialog = false
        },
        close: function(a, c) {
            $("#dialog-confirm-exit-edit-custom-word").dialog("destroy").remove();
            isShowConfirmExitEditCustomWordDialog = false
        },
        buttons: [{
            text: dialog_yes_label,
            click: function() {
                $(this).dialog("close");
                closeEditCustomWordDialog()
            }
        }, {
            text: dialog_no_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmExitEditCustomWordDialog = true;
    $("#dialog-confirm-exit-edit-custom-word").css("fontFamily", ui_widget_font_family)
}
var isShowEditEBDicWordDialog = false;
function closeEditEBDicWordDialog() {
    if (isShowEditEBDicWordDialog) {
        $("#dialog-edit-ebdic-word").dialog("close");
        $("#dialog-edit-ebdic-word").dialog("destroy").remove()
    }
    isShowEditEBDicWordDialog = false
}
function addEBDicWord(d, f, e, m, c) {
    var l = m;
    var a = "";
    var n = "";
    var g = m;
    if ((f == 0 && !l && !c) || (f == 1 && !l)) {
        toastr.warning(res_string_toastr_no_word_added)
    } else {
        setStatus(2);
        if (current_database_file == d || d == null ) {
            ws.send({
                cmd: "req_add_word",
                data: a,
                keyword: l,
                historyTop: n,
                topLabel: go_position_label,
                force: e,
                addSearchWord: f,
                web_url: c,
                web_name: g
            })
        } else {
            ws.send({
                cmd: "req_add_word",
                db_name: d,
                data: a,
                keyword: l,
                historyTop: n,
                topLabel: go_position_label,
                force: e,
                addSearchWord: f,
                web_url: c,
                web_name: g
            })
        }
    }
}
function showEBDicWordDialog(d, c, f, a, e) {
    if (isShowEditEBDicWordDialog) {
        return
    }
    beforeShowDialog();
    html_input_site_name = '<input id="ebdic_word_keyword_input" style="width:320px;font-family:' + ui_widget_font_family + '">';
    html_input_url = "";
    if (f == 1) {
        html_input_url = '<div style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + res_string_websearch_url_label + '</div><textarea id="ebdic_word_url_input" rows="3" cols="35" style="width:320px;resize: none;font-family:' + ui_widget_font_family + '">'
    }
    var g = res_string_edit_custom_word_heading;
    if (f == 1) {
        g = res_string_edit_custom_word_heading
    } else {
        if (f == 2) {
            g = res_string_edit_ebidc_word_heading
        }
    }
    $("body").append('<div id="dialog-edit-ebdic-word" title="' + (d ? dialog_add_label : dialog_edit_label) + '"><div style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + g + "</div>" + html_input_site_name + html_input_url + "</div>");
    $("#dialog-edit-ebdic-word").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 380,
        closeOnEscape: false,
        beforeClose: function(l, m) {
            isShowEditEBDicWordDialog = false
        },
        close: function(l, m) {
            $("#dialog-edit-ebdic-word").dialog("destroy").remove();
            isShowEditEBDicWordDialog = false
        },
        buttons: [{
            text: dialog_ok_label,
            click: function() {
                if (!checkConnect()) {
                    return
                }
                var m = $("#ebdic_word_keyword_input").val();
                var l = "";
                if (f == 1) {
                    l = $("#ebdic_word_url_input").val()
                }
                if (m.trim().length <= 0) {
                    toastr.error(res_string_toastr_input_invalid);
                    return
                }
                if (f == 1 && l.trim().length <= 0) {
                    toastr.error(res_string_toastr_input_invalid);
                    return
                }
                if (f == 1 && !validateURL(l)) {
                    toastr.error(res_string_toastr_web_site_incorrect_url);
                    return
                }
                if (d) {
                    if (f == 1) {
                        addEBDicWord(current_database_file, 0, 0, m, l)
                    } else {
                        addEBDicWord(current_database_file, 1, 0, m, "")
                    }
                } else {
                    ws.send({
                        cmd: "req_set_ebdic_word",
                        add: (d ? 1 : 0),
                        type: f,
                        row_id: c,
                        keyword: m,
                        web_url: l
                    })
                }
                closeEditEBDicWordDialog()
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    if (!d) {
        $("#ebdic_word_keyword_input").val(a);
        if (f == 1) {
            $("#ebdic_word_url_input").val(e)
        }
    } else {
        $("#ebdic_word_keyword_input").val("");
        if (f == 1) {
            $("#ebdic_word_url_input").val("")
        }
    }
    isShowEditEBDicWordDialog = true;
    $("#dialog-edit-ebdic-word").css("fontFamily", ui_widget_font_family)
}
var isShowEditWebSearchDialog = false;
function closeEditWebSearchDialog() {
    if (isShowEditWebSearchDialog) {
        $("#dialog-edit-web-search").dialog("close");
        $("#dialog-edit-web-search").dialog("destroy").remove()
    }
    isShowEditWebSearchDialog = false
}
function showEditWebSearchDialog(c, a) {
    if (isShowEditWebSearchDialog) {
        return
    }
    beforeShowDialog();
    html_input_site_name = '<input id="websearch_name_input" style="width:320px;font-family:' + ui_widget_font_family + '">';
    html_input_url = '<textarea id="websearch_url_input" rows="3" cols="35" style="width:320px;resize: none;font-family:' + ui_widget_font_family + '">';
    $("body").append('<div id="dialog-edit-web-search" title="' + (c ? dialog_add_label : dialog_edit_label) + '"><div style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + res_string_websearch_name_label + "</div>" + html_input_site_name + '<div style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + res_string_websearch_url_label + "</div>" + html_input_url + "</div>");
    $("#dialog-edit-web-search").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 380,
        closeOnEscape: false,
        beforeClose: function(d, e) {
            isShowEditWebSearchDialog = false
        },
        close: function(d, e) {
            $("#dialog-edit-web-search").dialog("destroy").remove();
            isShowEditWebSearchDialog = false
        },
        buttons: [{
            text: dialog_ok_label,
            click: function() {
                if (!checkConnect()) {
                    return
                }
                var e = $("#websearch_name_input").val();
                var d = $("#websearch_url_input").val();
                if (e.trim().length <= 0 || d.trim().length <= 0) {
                    toastr.error(res_string_toastr_input_invalid);
                    return
                }
                if (!validateURL(d)) {
                    toastr.error(res_string_toastr_web_site_incorrect_url);
                    return
                }
                if (c) {
                    g_web_sites_name_list.push(e);
                    g_web_sites_url_list.push(d);
                    g_web_sites_font_size_list.push(0)
                } else {
                    g_web_sites_name_list[a] = e;
                    g_web_sites_url_list[a] = d
                }
                SendAndRefreshWebSearch();
                closeEditWebSearchDialog()
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    if (!c) {
        $("#websearch_name_input").val(g_web_sites_name_list[a]);
        $("#websearch_url_input").val(g_web_sites_url_list[a])
    } else {
        $("#websearch_name_input").val("");
        $("#websearch_url_input").val("")
    }
    isShowEditWebSearchDialog = true;
    $("#dialog-edit-web-search").css("fontFamily", ui_widget_font_family)
}
function closeSearchDicsDialog() {
    if (isShowSearchDicsDialog) {
        $("#dialog-search-dics").dialog("close");
        $("#dialog-search-dics").dialog("destroy").remove()
    }
    isShowSearchDicsDialog = false
}
var g_search_dics = null ;
var g_search_dic_index = -2;
var g_current_dics_start_index = -1;
var g_current_use_dics_index = -1;
var g_haveMultiSearch = false;
function showSearchDicsDialog(a, d, f) {
    if (isShowSearchDicsDialog) {
        return
    }
    beforeShowDialog();
    var c = [];
    var e = 0;
    $.each(a, function(l, m) {
        var g = m;
        if ((f == -1 && l == 0) || (l < f)) {
            g = '<font color="#BB1B15">' + m + "</font>"
        }
        c.push(g);
        e++
    });
    $("body").append('<div id="dialog-search-dics" title="' + dialog_title_search_dictionaries_label + '"><div style="margin: 0 auto; text-align: center;"><p><div id="dicslist" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-search-dics").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 400,
        height: (isChrome ? 455 : 490),
        closeOnEscape: false,
        beforeClose: function(g, l) {
            isShowSearchDicsDialog = false
        },
        close: function(g, l) {
            $("#dialog-search-dics").dialog("destroy").remove();
            isShowSearchDicsDialog = false
        }
    });
    $("#dicslist").jqxListBox({
        theme: "base",
        source: c,
        width: "350px",
        height: (isChrome ? 365 : 400) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#dicslist.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#dicslist").jqxListBox("selectedIndex", d);
    $("#dicslist").on("change", function(l) {
        var g = l.args;
        var m = g.item.index;
        if (!checkConnect()) {
            return
        }
        if ($("#search_text").val()) {
            setStatus(1)
        }
        g_search_dic_index = m;
        setStatus(2);
        ws.send({
            cmd: "req_set_dics",
            data: m
        });
        closeSearchDicsDialog()
    });
    isShowSearchDicsDialog = true;
    $("#dialog-search-dics").css("fontFamily", ui_widget_font_family)
}
function multi_search_input(c, a) {
    return "multi_search_input_" + c + "_" + a
}
function multi_search_cand_btn(c, a) {
    return "multi_search_cand_btn_" + c + "_" + a
}
function multi_search_candidate_ref(a) {
    return a.page + ":" + a.offset + ":" + a.book_index
}
var isShowMultiSearchDialog = false;
function closeMultiSearchDialog() {
    closeMutiSearchCandidatesDialog();
    if (isShowMultiSearchDialog) {
        $("#dialog-multi-search").dialog("close");
        $("#dialog-multi-search").dialog("destroy").remove()
    }
    isShowMultiSearchDialog = false;
    g_multi_search_dialog = null
}
var g_multi_search_dialog = null ;
var g_multi_search_words = null ;
var dialog_title_multi_search = "Multi Search";
var g_multi_search_dialog_position = null ;
var g_multi_search_dialog_size = null ;
function showMultiSearchDialog(l) {
    var g = "";
    g += "<ul>";
    for (i = 0; i < l.multi_search_entry_lists.length; i++) {
        g += '<li multi_id="' + i + '"><a href="#tabs-' + (i) + '">' + l.multi_search_list[i] + "</a></li>"
    }
    g += "</ul>";
    for (i = 0; i < l.multi_search_entry_lists.length; i++) {
        g += '<div id="tabs-' + (i) + '">';
        entrylist = l.multi_search_entry_lists[i];
        for (j = 0; j < entrylist.length; j++) {
            entry = entrylist[j];
            g += '<span style="color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + entry.label + "</span><br>";
            g += '<input id="' + multi_search_input(i, j) + '" style="width:60%;min-width:150px;font-family:' + ui_widget_font_family + '">';
            if (entry.haveCandidates) {
                g += '<button class="candidate_btn" id="' + multi_search_cand_btn(i, j) + '" input_id="' + multi_search_input(i, j) + '" input_label="' + entry.label + '" candidates_ref="' + multi_search_candidate_ref(entry) + '" >&gt;</button>'
            }
            g += "<br>"
        }
        g += "</div>"
    }
    $("body").append('<div id="dialog-multi-search" title="' + l.name + '"><div><p><div id="multi_search_edit" >' + g + "</div></div></div>");
    var d = readCookie("multi_search_top");
    var f = readCookie("multi_search_left");
    if (d != null && f != null ) {
        pos = "left+" + f + " top+" + d;
        _position = {
            my: "left top",
            at: pos,
            of: window
        }
    } else {
        _position = {
            my: "center",
            at: "center",
            of: window
        }
    }
    var a = readCookie("multi_search_size_width");
    var c = readCookie("multi_search_size_height");
    g_multi_search_dialog = $("#dialog-multi-search").dialog({
        modal: false,
        draggable: true,
        resizable: true,
        closeOnEscape: true,
        width: (a != null ? a : 480),
        minWidth: 265,
        position: _position,
        height: (c != null ? c : (isChrome ? 485 : 480)),
        dragStop: function(n, o) {
            g_multi_search_dialog_position = o.position;
            createCookie("multi_search_top", o.position.top);
            createCookie("multi_search_left", o.position.left)
        },
        resizeStop: function(n, o) {
            g_multi_search_dialog_position = o.position;
            g_multi_search_dialog_size = o.size;
            createCookie("multi_search_size_width", o.size.width);
            createCookie("multi_search_size_height", o.size.height)
        },
        open: function(n, o) {},
        beforeClose: function(n, o) {},
        close: function(n, o) {
            $("#dialog-multi-search").dialog("destroy").remove();
            isShowMultiSearchDialog = false;
            g_multi_search_dialog = null
        },
        buttons: [{
            text: dialog_search_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                entrylist = l.multi_search_entry_lists[e];
                var n = [];
                g_multi_search_words = [];
                for (j = 0; j < entrylist.length; j++) {
                    var o = $("#" + multi_search_input(e, j)).val();
                    if (o) {
                        g_multi_search_words.push(o);
                        n.push(o.replace(/%/g, "%25").replace(/:/g, "%3A"))
                    } else {
                        n.push("")
                    }
                }
                send_increment = false;
                keep_increment_word = null ;
                setStatus(1);
                ws.send({
                    cmd: "req_search",
                    data: convertToKana(n.join(":")),
                    increment: 0,
                    multi_id: e,
                    multi_book_index: l.book_index
                });
                setMode(1)
            }
        }, {
            text: dialog_clear_label,
            click: function() {
                entrylist = l.multi_search_entry_lists[e];
                for (j = 0; j < entrylist.length; j++) {
                    $("#" + multi_search_input(e, j)).val("")
                }
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    $(g_multi_search_dialog).dialogExtend({
        minimizable: true,
        maximizable: false,
        collapsable: true,
        dblclick: "minimize",
        minimizeLocation: "right"
    });
    var m = $("#" + multi_search_input(0, 0)).outerHeight();
    $(".candidate_btn").css("height", m + "px");
    var e = 0;
    $("#multi_search_edit").tabs({
        activate: function(n, o) {
            e = o.newTab.attr("multi_id")
        }
    });
    for (i = 0; i < l.multi_search_entry_lists.length; i++) {
        entrylist = l.multi_search_entry_lists[i];
        for (j = 0; j < entrylist.length; j++) {
            entry = entrylist[j];
            if (entry.haveCandidates) {
                $("#" + multi_search_cand_btn(i, j)).click(function() {
                    candidates_ref = $(this).attr("candidates_ref");
                    ref_id = $(this).attr("input_id");
                    ref_label = $(this).attr("input_label");
                    refs = candidates_ref.split(":");
                    ref_page = parseInt(refs[0]);
                    ref_offset = parseInt(refs[1]);
                    ref_index = parseInt(refs[2]);
                    var n = 0;
                    g_candidates_history = [];
                    g_history_entry = {
                        page: ref_page,
                        offset: ref_offset,
                        book_index: ref_index
                    };
                    setStatus(2);
                    ws.send({
                        cmd: "req_get_multi_search_candidates",
                        label: ref_label,
                        page: ref_page,
                        offset: ref_offset,
                        book_index: ref_index,
                        candidate_id: ref_id
                    })
                })
            }
        }
    }
    isShowMultiSearchDialog = true;
    $("#dialog-multi-search").css("fontFamily", ui_widget_font_family)
}
var isShowMutiSearchCandidatesDialog = false;
function closeMutiSearchCandidatesDialog() {
    if (isShowMutiSearchCandidatesDialog) {
        $("#dialog-multi-search-candidates").dialog("close");
        $("#dialog-multi-search-candidates").dialog("destroy").remove()
    }
    isShowMutiSearchCandidatesDialog = false
}
var g_candidates_history = [];
var g_history_entry = null ;
function showMutiSearchCandidatesDialog(a, e, c) {
    html_options = [];
    more_img_left = 178;
    if (a.length > 17) {
        more_img_left = 155
    }
    for (var d = 0; d < a.length; d++) {
        entry = a[d];
        more_candidates = "";
        if (entry.haveCandidates) {
            more_candidates = '<img style="position: absolute;left: ' + more_img_left + 'px;"src="./img/more_candidates.png"/>'
        }
        html_options.push(entry.label + more_candidates)
    }
    cbuttons = [{
        text: dialog_backward_label,
        click: function() {
            if (!checkConnect()) {
                return
            }
            $(this).dialog("close");
            if (g_candidates_history.length >= 1) {
                var f = g_candidates_history[g_candidates_history.length - 1];
                g_candidates_history.splice(g_candidates_history.length - 1, 1);
                setStatus(2);
                g_history_entry = f;
                ws.send({
                    cmd: "req_get_multi_search_candidates",
                    label: c,
                    page: f.page,
                    offset: f.offset,
                    book_index: f.book_index,
                    candidate_id: e
                })
            }
        }
    }, {
        text: dialog_cancel_label,
        click: function() {
            $(this).dialog("close")
        }
    }];
    if (g_candidates_history.length <= 0) {
        cbuttons = [{
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    }
    $("body").append('<div id="dialog-multi-search-candidates" title="' + c + '"><div style="margin: 0 auto; text-align: center;"><p><div id="candidatesList" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-multi-search-candidates").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 260,
        height: (isChrome ? 490 : 490),
        closeOnEscape: false,
        open: function(f, g) {},
        beforeClose: function(f, g) {
            log(" page beforeClose")
        },
        close: function(f, g) {
            log(" page close");
            $("#dialog-multi-search-candidates").dialog("destroy").remove();
            isShowMutiSearchCandidatesDialog = false
        },
        buttons: cbuttons
    });
    $("#candidatesList").jqxListBox({
        theme: "base",
        source: html_options,
        width: "200px",
        height: (isChrome ? 350 : 350) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#candidatesList.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#candidatesList").on("change", function(m) {
        var g = m.args;
        var n = g.item.value;
        var f = g.item.index;
        if (!checkConnect()) {
            return
        }
        var l = a[f];
        if (!l.haveCandidates) {
            $("#" + e).val(l.data)
        } else {
            g_candidates_history.push(g_history_entry);
            g_history_entry = l;
            setStatus(2);
            ws.send({
                cmd: "req_get_multi_search_candidates",
                label: c,
                page: l.page,
                offset: l.offset,
                book_index: l.book_index,
                candidate_id: e
            })
        }
        closeMutiSearchCandidatesDialog()
    });
    isShowMutiSearchCandidatesDialog = true;
    $("#dialog-multi-search-candidates").css("fontFamily", ui_widget_font_family)
}
g_multi_search_dics_info = [];
function handleShowMultiSearch(a) {
    if (!g_multi_search_dics_info[a]) {
        setStatus(2);
        ws.send({
            cmd: "req_get_multi_search_info",
            index: a
        })
    } else {
        info = g_multi_search_dics_info[a];
        showMultiSearchDialog(info)
    }
}
var g_multi_search_dics_list = null ;
var g_multi_search_dics_list_index = null ;
function handleShowSelectMultiSearchDicsDialog() {
    if (g_multi_search_dics_list == null ) {
        setStatus(2);
        ws.send({
            cmd: "req_get_multi_search_dics"
        })
    } else {
        if (g_multi_search_dics_list.length <= 0) {
            toastr.info("no available dictionaries for multi search");
            return
        }
        ShowSelectMultiSearchDicsDialog()
    }
}
var isShowSelectMultiSearchDicsDialog = false;
function closeSelectMultiSearchDicsDialog() {
    if (isShowSelectMultiSearchDicsDialog) {
        $("#dialog-select-multi-search-dics").dialog("close");
        $("#dialog-select-multi-search-dics").dialog("destroy").remove()
    }
    isShowSelectMultiSearchDicsDialog = false
}
function ShowSelectMultiSearchDicsDialog() {
    if (isShowSelectMultiSearchDicsDialog) {
        return
    }
    beforeShowDialog();
    html_options = [];
    for (var a = 0; a < g_multi_search_dics_list.length; a++) {
        html_options.push(g_multi_search_dics_list[a])
    }
    $("body").append('<div id="dialog-select-multi-search-dics" title="' + dialog_title_select_multi_search_dics_label + '"><div style="margin: 0 auto; text-align: center;"><p><div id="multiSearchDicsList" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-select-multi-search-dics").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 380,
        height: (isChrome ? 445 : 445),
        closeOnEscape: false,
        open: function(c, d) {},
        beforeClose: function(c, d) {},
        close: function(c, d) {
            $("#dialog-select-multi-search-dics").dialog("destroy").remove();
            isShowSelectMultiSearchDicsDialog = false
        }
    });
    $("#multiSearchDicsList").jqxListBox({
        theme: "base",
        source: html_options,
        width: "320px",
        height: (isChrome ? 355 : 355) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#multiSearchDicsList.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#multiSearchDicsList").on("change", function(d) {
        var c = d.args;
        var e = g_multi_search_dics_list_index[c.item.index];
        if (!checkConnect()) {
            return
        }
        closeSelectMultiSearchDicsDialog();
        handleShowMultiSearch(e)
    });
    isShowSelectMultiSearchDicsDialog = true;
    $("#dialog-select-multi-search-dics").css("fontFamily", ui_widget_font_family)
}
function closeMenuDialog() {
    if (isShowMenuDialog) {
        $("#dialog-menu").dialog("close");
        $("#dialog-menu").dialog("destroy").remove()
    }
    isShowMenuDialog = false
}
function showMenuDialog() {
    if (isShowMenuDialog) {
        return
    }
    beforeShowDialog();
    menu_type = 0;
    html_menu_select_options = "";
    if (g_menu_list.length > 0) {
        html_menu_select_options += "<option value='" + g_menu_type_label[0] + "' selected>" + g_menu_type_label[0] + "</option>"
    }
    if (g_image_menu_list.length > 0) {
        if (g_menu_list.length <= 0) {
            html_menu_select_options += "<option value='" + g_menu_type_label[1] + "' selected>" + g_menu_type_label[1] + "</option>";
            menu_type = 1
        } else {
            html_menu_select_options += "<option value='" + g_menu_type_label[1] + "'>" + g_menu_type_label[1] + "</option>"
        }
    }
    menu_list = g_menu_list;
    menu_list_index = g_menu_list_index;
    if (menu_type == 1) {
        menu_list = g_image_menu_list;
        menu_list_index = g_image_menu_list_index
    }
    html_menu_select = '<select name="menu_select" id="menu_select" style="width:150px;">' + html_menu_select_options + "</select><p>";
    html_options = [];
    for (var a = 0; a < menu_list.length; a++) {
        html_options.push(menu_list[a])
    }
    $("body").append('<div id="dialog-menu" title="' + dialog_title_menu_label + '"><div style="margin: 0 auto; text-align: center;"><p>' + html_menu_select + '<div id="menulist" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-menu").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 380,
        height: (isChrome ? 445 : 445) + (html_menu_select ? 38 : 0),
        closeOnEscape: false,
        open: function(c, d) {},
        beforeClose: function(c, d) {},
        close: function(c, d) {
            $("#dialog-menu").dialog("destroy").remove();
            isShowMenuDialog = false
        }
    });
    $("#menulist").jqxListBox({
        theme: "base",
        source: html_options,
        width: "320px",
        height: (isChrome ? 355 : 355) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#menulist.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#menulist").on("change", function(d) {
        var c = d.args;
        var e = menu_list_index[c.item.index];
        if (!checkConnect()) {
            return
        }
        setStatus(2);
        ws.send({
            cmd: "req_get_menu",
            book_index: e,
            type: menu_type
        });
        closeMenuDialog();
        setMode(3)
    });
    $("#menu_select").change(function() {
        if (!checkConnect()) {
            return
        }
        var c = $(this).val();
        if (g_menu_type_label[0] == c) {
            menu_type = 0;
            menu_list = g_menu_list;
            menu_list_index = g_menu_list_index
        } else {
            menu_type = 1;
            menu_list = g_image_menu_list;
            menu_list_index = g_image_menu_list_index
        }
        $("#menulist").jqxListBox({
            source: menu_list
        })
    });
    isShowMenuDialog = true;
    $("#dialog-menu").css("fontFamily", ui_widget_font_family)
}
function closeNotebookPagesDialog() {
    log(" page closeNotebookPagesDialog");
    if (isShowNotebookPagesDialog) {
        $("#dialog-notebookpages").dialog("close");
        $("#dialog-notebookpages").dialog("destroy").remove()
    }
    isShowNotebookPagesDialog = false
}
function showNotebookPagesDialog() {
    if (isShowNotebookPagesDialog) {
        return
    }
    beforeShowDialog();
    html_options = [];
    for (var a = 0; a < pageCount; a++) {
        html_options.push(a + 1)
    }
    html_db_options = "";
    html_db_select = "";
    if (g_dbs != null ) {
        for (var a = 0; a < g_dbs.length; a++) {
            if (current_database_file == g_dbs[a]) {
                html_db_options += "<option value='" + g_dbs[a] + "' selected>" + g_dbs[a] + "</option>"
            } else {
                html_db_options += "<option value='" + g_dbs[a] + "'>" + g_dbs[a] + "</option>"
            }
        }
        html_db_select = '<select name="db_select" id="db_select" style="width:200px;">' + html_db_options + "</select><p>"
    }
    if (pro == 0) {
        html_db_select = ""
    }
    $("body").append('<div id="dialog-notebookpages" title="' + dialog_title_notebook_pages_label + '"><div style="margin: 0 auto; text-align: center;"><p>' + html_db_select + '<div id="pagelist" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-notebookpages").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 260,
        height: (isChrome ? 448 : 448) + (html_db_select ? 38 : 0),
        closeOnEscape: false,
        open: function(c, d) {},
        beforeClose: function(c, d) {
            log(" page beforeClose")
        },
        close: function(c, d) {
            log(" page close");
            $("#dialog-notebookpages").dialog("destroy").remove();
            isShowNotebookPagesDialog = false
        }
    });
    $("#pagelist").jqxListBox({
        theme: "base",
        source: html_options,
        width: "200px",
        height: (isChrome ? 358 : 358) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#pagelist.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#pagelist").jqxListBox("selectedIndex", currentPage - 1);
    $("#pagelist").on("change", function(d) {
        var c = d.args;
        var e = c.item.value;
        if (!checkConnect()) {
            return
        }
        log("value=" + e);
        setStatus(2);
        ws.send({
            cmd: "req_get_note",
            page: e
        });
        closeNotebookPagesDialog()
    });
    if (html_db_select) {
        $("#db_select").change(function() {
            if (!checkConnect()) {
                return
            }
            var c = $(this).val();
            setStatus(2);
            ws.send({
                cmd: "req_set_note_db",
                data: c
            });
            closeNotebookPagesDialog()
        })
    }
    isShowNotebookPagesDialog = true;
    $("#dialog-notebookpages").css("fontFamily", ui_widget_font_family)
}
function closeConfirmDeleteWordsDialog() {
    if (isShowConfirmDeleteWordsDialog) {
        $("#dialog-confirm-delete-words").dialog("close");
        $("#dialog-confirm-delete-words").dialog("destroy").remove()
    }
    isShowConfirmDeleteWordsDialog = false
}
function showConfirmDeleteWordsDialog() {
    if (isShowConfirmDeleteWordsDialog) {
        return
    }
    beforeShowDialog();
    message = dialog_message_delete_highlight;
    $("body").append('<div id="dialog-confirm-delete-words" title="' + res_string_delete_note + '"><span style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + message + "</span></div>");
    $("#dialog-confirm-delete-words").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(a, c) {
            isShowConfirmDeleteWordsDialog = false
        },
        close: function(a, c) {
            $("#dialog-confirm-delete-words").dialog("destroy").remove();
            isShowConfirmDeleteWordsDialog = false
        },
        buttons: [{
            text: dialog_yes_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                setStatus(2);
                ws.send({
                    cmd: "req_op_note",
                    op_indexes: g_checkbox_items.join(),
                    type: 0
                });
                $(this).dialog("close")
            }
        }, {
            text: dialog_no_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmDeleteWordsDialog = true;
    $("#dialog-confirm-delete-words").css("fontFamily", ui_widget_font_family)
}
var isShowConfirmClearSearchModeHighlightDialog = false;
function closeConfirmClearSearchModeHighlightDialog() {
    if (isShowConfirmClearSearchModeHighlightDialog) {
        $("#dialog-confirm-clear-searchmode-highlight").dialog("close");
        $("#dialog-confirm-clear-searchmode-highlight").dialog("destroy").remove()
    }
    isShowConfirmClearSearchModeHighlightDialog = false
}
function showConfirmClearSearchModeHighlightDialog() {
    if (isShowConfirmClearSearchModeHighlightDialog) {
        return
    }
    beforeShowDialog();
    var a = dialog_message_delete_highlight;
    var c = res_string_confirm_exit;
    $("body").append('<div id="dialog-confirm-clear-searchmode-highlight" title="' + c + '"><span style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + res_discard_highlight + "</span></div>");
    $("#dialog-confirm-clear-searchmode-highlight").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(d, e) {
            isShowConfirmClearSearchModeHighlightDialog = false
        },
        close: function(d, e) {
            $("#dialog-confirm-clear-searchmode-highlight").dialog("destroy").remove();
            isShowConfirmClearSearchModeHighlightDialog = false
        },
        buttons: [{
            text: dialog_yes_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                removeAllHighlight();
                disableHighlight();
                $(this).dialog("close")
            }
        }, {
            text: dialog_no_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmClearSearchModeHighlightDialog = true;
    $("#dialog-confirm-clear-searchmode-highlight").css("fontFamily", ui_widget_font_family)
}
function closeConfirmDeleteHighlightDialog() {
    if (isShowConfirmDeleteHighlightDialog) {
        $("#dialog-confirm-delete-highlight").dialog("close");
        $("#dialog-confirm-delete-highlight").dialog("destroy").remove()
    }
    isShowConfirmDeleteHighlightDialog = false
}
function showConfirmDeleteHighlightDialog(a) {
    if (isShowConfirmDeleteHighlightDialog) {
        return
    }
    beforeShowDialog();
    message = dialog_message_delete_highlight;
    if (a) {
        message = dialog_message_delete_highlight_all
    }
    $("body").append('<div id="dialog-confirm-delete-highlight" title="' + dialog_title_delete_highlight + '"><span style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + message + "</span></div>");
    isOkClicked = false;
    $("#dialog-confirm-delete-highlight").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(c, d) {
            isShowConfirmDeleteHighlightDialog = false
        },
        close: function(c, d) {
            $("#dialog-confirm-delete-highlight").dialog("destroy").remove();
            isShowConfirmDeleteHighlightDialog = false;
            if (!a) {
                highlighter.removeAllHighlights();
                data = generateRangyHighlightString();
                if (data) {
                    highlighter.deserialize(data)
                }
            }
        },
        buttons: [{
            text: dialog_yes_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                if (a) {
                    removeAllHighlight();
                    unSelect();
                    SendHighlightString()
                } else {
                    removeHighlightFromSelectedText(g_delete_highlights);
                    unSelect();
                    SendHighlightString()
                }
                isOkClicked = true;
                $(this).dialog("close")
            }
        }, {
            text: dialog_no_label,
            click: function() {
                isOkClicked = false;
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmDeleteHighlightDialog = true;
    $("#dialog-confirm-delete-highlight").css("fontFamily", ui_widget_font_family)
}
function closeConfirmAddDBDialog() {
    if (isShowConfirmAddDBDialog) {
        $("#dialog-confirm-add-db").dialog("close");
        $("#dialog-confirm-add-db").dialog("destroy").remove()
    }
    isShowConfirmAddDBDialog = false
}
function showConfirmAddDBDialog() {
    if (isShowConfirmAddDBDialog) {
        return
    }
    beforeShowDialog();
    html_input_db_name = '<input id="db_name" style="width:250px;;font-family:' + ui_widget_font_family + '">';
    $("body").append('<div id="dialog-confirm-add-db" title="' + dialog_title_add_db + '"><div style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + res_string_add_db_name + "</div>" + html_input_db_name + "</div>");
    $("#dialog-confirm-add-db").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(a, c) {
            isShowConfirmAddDBDialog = false
        },
        close: function(a, c) {
            $("#dialog-confirm-add-db").dialog("destroy").remove();
            isShowConfirmAddDBDialog = false
        },
        buttons: [{
            text: dialog_ok_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                var a = $("#db_name").val();
                if (a) {
                    setStatus(2);
                    ws.send({
                        cmd: "req_add_db",
                        db_name: a
                    });
                    $(this).dialog("close")
                }
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmAddDBDialog = true;
    $("#dialog-confirm-add-db").css("fontFamily", ui_widget_font_family)
}
function closeConfirmAddWordDialog() {
    if (isShowConfirmAddWordDialog) {
        $("#dialog-confirm-add-word").dialog("close");
        $("#dialog-confirm-add-word").dialog("destroy").remove()
    }
    isShowConfirmAddWordDialog = false
}
function addWord(d, g, f) {
    var n = $("#search_text").val();
    var a = "";
    var q = "";
    var c = "";
    var l = "";
    if (g == 1) {
        a = "";
        q = ""
    } else {
        a = current_word;
        if (g_go_book_index != -1) {
            q = "<ref " + g_go_page + ":" + g_go_offset + ":" + g_go_book_index + ">"
        }
        if (g_go_page == -4) {
            if (settings_web_search_in_new_tab == 1) {
                c = g_add_word_url;
                l = g_web_search_name
            } else {
                var m = document.getElementById("content_iframe");
                if (m) {
                    try {
                        c = m.contentWindow.location.href
                    } catch (o) {
                        c = m.src
                    }
                    l = g_web_search_name;
                    console.log("iframe url=" + c);
                    console.log("iframe web_name=" + l)
                }
            }
        }
    }
    if (ebdic_mode != 1) {
        toastr.warning("Unable to add a word in page mode!!")
    } else {
        if ((g == 0 && !a && !q && g_go_page != -4) || (g == 1 && n.length <= 0)) {
            toastr.warning(res_string_toastr_no_word_added)
        } else {
            if (g == 2 && !g_highlight_data_string) {
                toastr.warning("There is no highlights for custom word!!")
            } else {
                setStatus(2);
                var u = g;
                var x = 0;
                if (g == 2) {
                    if (g_go_page == -3) {
                        u = 1
                    } else {
                        u = 0
                    }
                    x = 1
                }
                if (current_database_file == d || d == null ) {
                    ws.send({
                        cmd: "req_add_word",
                        data: a,
                        keyword: n,
                        historyTop: q,
                        custom_highlight: x,
                        topLabel: go_position_label,
                        force: f,
                        addSearchWord: u,
                        web_url: c,
                        web_name: l,
                        note_info: g_highlight_data_string
                    })
                } else {
                    ws.send({
                        cmd: "req_add_word",
                        db_name: d,
                        data: a,
                        keyword: n,
                        historyTop: q,
                        custom_highlight: x,
                        topLabel: go_position_label,
                        force: f,
                        addSearchWord: u,
                        web_url: c,
                        web_name: l,
                        note_info: g_highlight_data_string
                    })
                }
            }
        }
    }
}
function showConfirmAddWordDialog(c, a) {
    if (isShowConfirmAddWordDialog) {
        return
    }
    beforeShowDialog();
    $("body").append('<div id="dialog-confirm-add-word" title="' + dialog_title_add_word + '"><span style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + dialog_message_add_word + "</span></div>");
    $("#dialog-confirm-add-word").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(d, e) {
            isShowConfirmAddWordDialog = false
        },
        close: function(d, e) {
            $("#dialog-confirm-add-word").dialog("destroy").remove();
            isShowConfirmAddWordDialog = false
        },
        buttons: [{
            text: dialog_yes_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                addWord(c, a, 1);
                $(this).dialog("close")
            }
        }, {
            text: dialog_no_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmAddWordDialog = true;
    $("#dialog-confirm-add-word").css("fontFamily", ui_widget_font_family)
}
function closeHistoryWordsDialog() {
    if (isShowHistoryWordsDialog) {
        $("#dialog-history").dialog("close");
        $("#dialog-history").dialog("destroy").remove()
    }
    isShowHistoryWordsDialog = false
}
function showHistoryWordsDialog(c) {
    if (isShowHistoryWordsDialog) {
        return
    }
    beforeShowDialog();
    if (c == null ) {
        return
    }
    if (c.length <= 0) {
        toastr.info("No history words!!");
        return
    }
    var a = [];
    $.each(c, function(d, e) {
        a.push(e)
    });
    $("body").append('<div id="dialog-history" title="' + dialog_title_recent_word_label + '"><div style="margin: 0 auto; text-align: center;"><p><div id="historylist" style="margin: 0 auto; text-align: center;" ></div></div></div>');
    $("#dialog-history").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 260,
        height: (isChrome ? 455 : 490),
        closeOnEscape: false,
        beforeClose: function(d, e) {
            isShowHistoryWordsDialog = false
        },
        close: function(d, e) {
            $("#dialog-history").dialog("destroy").remove();
            isShowHistoryWordsDialog = false
        }
    });
    $("#historylist").jqxListBox({
        theme: "base",
        source: a,
        loadOnTime: true,
        stepLoad: 200,
        delayOnce: false,
        width: "200px",
        height: (isChrome ? 365 : 400) + "px",
        enableHover: true,
        itemHeight: g_dialog_listitem_heigh
    });
    $("#historylist.jqx-widget").css("fontSize", g_dialog_list_font_size + "px");
    $("#historylist").on("change", function(e) {
        var d = e.args;
        var f = d.item.value;
        send_increment = false;
        keep_increment_word = null ;
        setStatus(1);
        if (searchMethod == 4) {
            showSearchFullDialog()
        }
        g_multi_search_words = null ;
        if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
            ws.send({
                cmd: "req_search",
                data: convertToKana(f),
                data2: romnih(f),
                increment: 0
            })
        } else {
            ws.send({
                cmd: "req_search",
                data: convertToKana(f),
                increment: 0
            })
        }
        addHistoryWords(f);
        setMode(1);
        $("#search_text").val(f);
        $("#search_text").trigger("change");
        closeHistoryWordsDialog()
    });
    isShowHistoryWordsDialog = true;
    $("#dialog-history").css("fontFamily", ui_widget_font_family)
}
settings_autocomplete = 1;
settings_web_search_in_new_tab = 0;
settings_search_size_list = [3, 5, 10, 15, 20, 25, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400, 500, 800, 1000];
settings_inc_search_size = 10;
settings_search_size = 100;
settings_font_familys = ["メイリオ", "メイリオ ボールド", "ＭＳ Ｐゴシック", "ＭＳ Ｐ明朝", "ＭＳ ゴシック", "ＭＳ 明朝", "MS UI Gothic", "Meiryo UI", "Meiryo UI Bold", "游ゴシック Light", "游ゴシック", "游ゴシック Bold", , "游明朝 Light", "游明朝", "游明朝 Demibold", , "sans", "Takao Pゴシック", "TakaoEXゴシック", "Takaoゴシック", "Takao P明朝", "TakaoEX明朝", "Takao明朝", "ヒラギノ角ゴ Pro W3", "ヒラギノ角ゴ ProN W3", "ヒラギノ角ゴ Pro W6", "serif", "sans-serif", "Verdana", "Tahoma", "cursive", "monospace", "fantasy", "Arial", "Arial Black", "Arial Narrow", , "Arial Rounded MT Bold", "Bookman Old Style", "Bradley Hand ITC", "Century", "Century Gothic", "Comic Sans MS", "Courier", "Courier New", "Georgia", "Gentium", "Impact", "King", "Lucida Console", "Lalit", "Modena", "Monotype Corsiva", "Papyrus", "TeX", "Times", "Times New Roman", "Trebuchet MS", "Verona", "Noto Sans CJK JP Medium", "Noto Sans CJK JP Light", "Noto Sans CJK JP DemiLight"];
settings_font_familys = settings_font_familys.sort(function(d, c) {
    return d.toLowerCase().localeCompare(c.toLowerCase())
});
settings_font_size_list = [13, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48];
settings_font_size = 16;
settings_list_font_size = 13;
if (isFirefox) {
    settings_font_family = "serif";
    settings_list_font_family = "serif"
} else {
    settings_font_family = "Verdana";
    settings_list_font_family = "Verdana"
}
settings_line_heights = [1, 1.05, 1.1, 1.15, 1.2, 1.25, 1.3, 1.35, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2, 2.2, 2.4, 2.6];
settings_line_height = 1.5;
settings_paragraphs_sizes = [1, 2, 3, 5, 6, 8, 10, 15, 20, 25, 30];
settings_paragraphs_size = 10;
settings_page_size_label = "Paragraphs size : ";
settings_line_height_label = "Line height : ";
settings_font_label = "Font : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
settings_list_font_label = "List font : ";
settings_inc_search_content_label = " Show the first content for incremental searching";
settings_title = "Settings for web server";
settings_list_size_label = "The maximum list size for each dictionary : ";
settings_inc_list_size_label = "The maximum list size for incremental search : ";
settings_show_highlight_label = " Show highlight tools";
settings_list_layout_ratio_label = "List width ratio :";
settings_autocomplete_label = "Auto complete";
settings_web_search_in_new_tab_label = "Web search in a new tab";
settings_click_search_label = "Click to search";
function update_setting_locale() {
    if (locale_language == 0) {
        settings_page_size_label = "段落のサイズ : ";
        settings_line_height_label = "行の高さ : ";
        settings_font_label = "本文フォント : ";
        settings_list_font_label = "項目フォント : ";
        settings_inc_search_content_label = " インクリメンタルサーチで、第一項目内容の表示。";
        settings_title = "ウェブサービスの設定";
        settings_list_size_label = "項目の最大サイズ(検索ボタン) : ";
        settings_inc_list_size_label = "項目の最大サイズ(インクリメンタルサーチ) : ";
        settings_show_highlight_label = " 右のツール";
        settings_list_layout_ratio_label = "項目横幅の配置比率 :";
        settings_autocomplete_label = "検索語履歴候補リスト";
        settings_web_search_in_new_tab_label = "新しいタブにWeb検索";
        settings_click_search_label = "クリック検索"
    } else {
        if (locale_language == 1) {
            settings_page_size_label = "段落數 : ";
            settings_line_height_label = "行高 : ";
            settings_font_label = "字型 : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            settings_list_font_label = "项目列表字型 : ";
            settings_inc_search_content_label = " 遞增查詢時，顯示第一項目的結果";
            settings_title = "網路服務的設定";
            settings_list_size_label = "符合項目的最大值(查詢鈕) : ";
            settings_inc_list_size_label = "符合項目的最大值(遞增查詢) : ";
            settings_show_highlight_label = " 右工具";
            settings_list_layout_ratio_label = "項目横寛的配置比率 :";
            settings_autocomplete_label = "自動完成最近查詢的單字";
            settings_web_search_in_new_tab_label = "Web查詢在新頁面";
            settings_click_search_label = "點擊查詢"
        } else {
            if (locale_language == 2) {
                settings_page_size_label = "段落数 : ";
                settings_line_height_label = "行高 : ";
                settings_font_label = "字型 : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                settings_list_font_label = "项目列表字型 : ";
                settings_inc_search_content_label = " 增量查询时，显示第一项目的结果";
                settings_title = "网路服务的设置";
                settings_list_size_label = "符合项目的最大值(查询钮) : ";
                settings_inc_list_size_label = "符合项目的最大值(增量查询) : ";
                settings_show_highlight_label = " 右工具";
                settings_list_layout_ratio_label = "项目横宽的配置比率 :";
                settings_autocomplete_label = "自动完成最近查询单字";
                settings_web_search_in_new_tab_label = "Web查询在新页面";
                settings_click_search_label = "点击查询"
            } else {
                settings_page_size_label = "Paragraphs size : ";
                settings_line_height_label = "Line height : ";
                settings_font_label = "Font : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
                settings_list_font_label = "List font : ";
                settings_inc_search_content_label = " Show the first content for incremental searching";
                settings_title = "Settings for web server";
                settings_list_size_label = "The maximum list size (search button) : ";
                settings_inc_list_size_label = "The maximum list size (incremental search) : ";
                settings_show_highlight_label = " Show highlight tool";
                settings_list_layout_ratio_label = "List width ratio :";
                settings_autocomplete_label = "Auto complete";
                settings_web_search_in_new_tab_label = "Web search in a new tab";
                settings_click_search_label = "Click to search"
            }
        }
    }
}
function changelistfontFamily(a) {
    updateListLinkColor();
    if (g_tnw_list_ui) {
        $("#wordlist").jqxListBox("fontFamily", a);
        adjustWordTag();
        return
    }
    padding_top = "3px";
    padding_bottom = "3px";
    padding_bottom_sub = "0px";
    if (settings_list_font_size == 13) {
        padding_top = "3px";
        padding_bottom = "3px";
        padding_bottom_sub = "3px"
    }
    if (a) {
        $(".jqx-listitem-state-normal").css("fontFamily", a)
    }
    $(".jqx-listitem-state-normal").css("padding-bottom", padding_bottom).css("padding-top", padding_top);
    $(".jqx-listitem-state-normal:has(sub)").css("padding-bottom", padding_bottom_sub).css("padding-top", padding_top);
    adjustWordTag()
}
function changelistFontSize(c) {
    if (g_tnw_list_ui) {
        $("#wordlist").jqxListBox("fontSize", c);
        list_itemHeight = (c - 13) + 27;
        adjustWordTag();
        handleWidgetFlashCardEvent("settings", {
            list_font_size: c
        });
        return
    }
    $("#wordlist.jqx-widget").css("fontSize", c + "px");
    list_itemHeight = (c - 13) + 27;
    if (list_itemHeight == 27) {
        $("#wordlist").jqxListBox({
            itemHeight: -1
        })
    } else {
        $("#wordlist").jqxListBox({
            itemHeight: list_itemHeight
        })
    }
    var a = $("#wordlist").find("#verticalScrollBarwordlist");
    a.jqxScrollBar({
        step: list_itemHeight
    });
    adjustWordTag();
    handleWidgetFlashCardEvent("settings", {
        list_font_size: c
    })
}
var g_show_setting_dialog = false;
function showSettingDialog() {
    if (g_show_setting_dialog) {
        return
    }
    beforeShowDialog();
    temp_settings_paragraphs_size = settings_paragraphs_size;
    settings_paragraphs_size_options_html = "";
    for (i = 0; i < settings_paragraphs_sizes.length; i++) {
        if (settings_paragraphs_sizes[i] == settings_paragraphs_size) {
            settings_paragraphs_size_options_html += '<option selected="selected">' + settings_paragraphs_sizes[i] + "</option>"
        } else {
            settings_paragraphs_size_options_html += "<option>" + settings_paragraphs_sizes[i] + "</option>"
        }
    }
    settings_paragraphs_size_options_html = '<p><label for="paragraphs_size" >' + settings_page_size_label + '</label><select name="paragraphs_size" id="paragraphs_size" >' + settings_paragraphs_size_options_html + "</select>";
    settings_inc_search_options_html = "";
    for (i = 0; i < settings_search_size_list.length; i++) {
        if (settings_search_size_list[i] == settings_inc_search_size) {
            settings_inc_search_options_html += '<option selected="selected">' + settings_search_size_list[i] + "</option>"
        } else {
            settings_inc_search_options_html += "<option>" + settings_search_size_list[i] + "</option>"
        }
    }
    settings_search_options_html = "";
    for (i = 0; i < settings_search_size_list.length; i++) {
        if (settings_search_size_list[i] == settings_search_size) {
            settings_search_options_html += '<option selected="selected">' + settings_search_size_list[i] + "</option>"
        } else {
            settings_search_options_html += "<option>" + settings_search_size_list[i] + "</option>"
        }
    }
    settings_line_height_options_html = "";
    for (i = 0; i < settings_line_heights.length; i++) {
        if (settings_line_heights[i] == settings_line_height) {
            settings_line_height_options_html += '<option selected="selected">' + settings_line_heights[i] + "</option>"
        } else {
            settings_line_height_options_html += "<option>" + settings_line_heights[i] + "</option>"
        }
    }
    settings_line_height_options_html = '<p><label for="line_height">' + settings_line_height_label + '</label><select name="line_height" id="line_height"  >' + settings_line_height_options_html + "</select>";
    temp_settings_line_height = settings_line_height;
    settings_font_family_options_html = "";
    settings_list_font_family_options_html = "";
    font_dector = new Detector();
    temp_settings_font_family = settings_font_family;
    temp_settings_font_size = settings_font_size;
    temp_settings_list_font_family = settings_list_font_family;
    temp_settings_list_font_size = settings_list_font_size;
    temp_list_itemHeight = list_itemHeight;
    font_family_count = 0;
    for (i = 0; i < settings_font_familys.length; i++) {
        value = font_dector.detect(settings_font_familys[i]);
        if (value) {
            if (settings_font_family == settings_font_familys[i]) {
                settings_font_family_options_html += '<option selected="selected">' + settings_font_familys[i] + "</option>"
            } else {
                settings_font_family_options_html += "<option>" + settings_font_familys[i] + "</option>"
            }
            if (settings_list_font_family == settings_font_familys[i]) {
                settings_list_font_family_options_html += '<option selected="selected">' + settings_font_familys[i] + "</option>"
            } else {
                settings_list_font_family_options_html += "<option>" + settings_font_familys[i] + "</option>"
            }
            font_family_count++
        }
    }
    if (font_family_count <= 1) {
        settings_font_family_options_html = "";
        settings_list_font_family_options_html = ""
    }
    if (settings_font_family_options_html) {
        settings_font_family_options_html = '<p><label for="font_family">' + settings_font_label + '</label><select name="font_family" id="font_family" style="width:150px;" >' + settings_font_family_options_html + "</select>";
        settings_list_font_family_options_html = '<p><label for="list_font_family" >' + settings_list_font_label + '</label><select name="list_font_family" id="list_font_family" style="width:150px;" >' + settings_list_font_family_options_html + "</select>"
    }
    settings_font_size_options_html = "";
    settings_list_font_size_options_html = "";
    for (i = 0; i < settings_font_size_list.length; i++) {
        if (settings_font_size == settings_font_size_list[i]) {
            settings_font_size_options_html += '<option selected="selected">' + settings_font_size_list[i] + "</option>"
        } else {
            settings_font_size_options_html += "<option>" + settings_font_size_list[i] + "</option>"
        }
        if (settings_list_font_size == settings_font_size_list[i]) {
            settings_list_font_size_options_html += '<option selected="selected">' + settings_font_size_list[i] + "</option>"
        } else {
            settings_list_font_size_options_html += "<option>" + settings_font_size_list[i] + "</option>"
        }
    }
    settings_font_size_options_html = '<select name="font_size" id="font_size">' + settings_font_size_options_html + "</select>";
    settings_list_font_size_options_html = '<select name="list_font_size" id="list_font_size">' + settings_list_font_size_options_html + "</select>";
    if (!settings_font_family_options_html) {
        settings_font_size_options_html = "";
        settings_list_font_size_options_html = ""
    }
    volume_settings = "";
    audioElement = document.getElementById("audiotag");
    value = parseInt(audioElement.volume * 100);
    volume_settings = '<table style="padding:0; margin: 0; border: 0px solid;" cellspacing="0" cellpadding="0" ><tr><td><span class="ui-icon ui-icon-volume-on" style="float:left; margin:-2px 0px 0 0;"></td><td><div id="sound_volume" style="width:260px; margin:15px;"></div></td><td><div id="volume_value" style="color:#1d5987;display:inline">' + value + "</div></td></tr></table>";
    settings_list_ratio_html = '<table style="padding:0; margin: 0; border: 0px solid;" cellspacing="0" cellpadding="0" ><tr><td><span style="">' + settings_list_layout_ratio_label + '</td><td><div id="list_ratio_slider" style="width:260px; margin:15px;"></div></td><td><div id="list_ratio_value" style="color:#1d5987;display:inline">' + value + "</div></td></tr></table>";
    settings_increment_search_content_html = '<p> <input type="checkbox" id="inc_search_content" ' + (only_increment == 1 ? "" : "checked") + ">" + settings_inc_search_content_label;
    temp_only_increment = only_increment;
    settings_highlight_tool_html = '<input type="checkbox" id="show_highlight_tool" ' + (show_highlight_tool == 0 ? "" : "checked") + ">" + settings_show_highlight_label;
    temp_show_highlight_tool = show_highlight_tool;
    settings_autocomplete_html = '<input type="checkbox" id="use_autocomplete" ' + (settings_autocomplete == 0 ? "" : "checked") + ">" + settings_autocomplete_label;
    temp_settings_autocomplete = settings_autocomplete;
    settings_click_search_html = '<input type="checkbox" id="use_click_search" ' + (g_click_search == 0 ? "" : "checked") + ">" + settings_click_search_label;
    temp_click_search = g_click_search;
    if (pro == 0) {
        settings_highlight_tool_html = ""
    } else {
        settings_highlight_tool_html += "&nbsp;&nbsp;"
    }
    settings_web_search_in_new_tab_html = '<input type="checkbox" id="web_search_in_new_tab" ' + (settings_web_search_in_new_tab == 0 ? "" : "checked") + ">" + settings_web_search_in_new_tab_label;
    temp_settings_web_search_in_new_tab = settings_web_search_in_new_tab;
    if (g_enable_resize == 0) {
        settings_list_ratio_html = ""
    }
    $("body").append('<div id="dialog-setting" title="' + settings_title + '"><form action="#"><p><label for="list_size">' + settings_list_size_label + '</label><br><select name="list_size" id="list_size">' + settings_search_options_html + '</select><p><label for="inc_list_size">' + settings_inc_list_size_label + '</label><br><select name="inc_list_size" id="inc_list_size">' + settings_inc_search_options_html + "</select>" + settings_paragraphs_size_options_html + settings_font_family_options_html + settings_font_size_options_html + settings_list_font_family_options_html + settings_list_font_size_options_html + settings_line_height_options_html + settings_list_ratio_html + settings_increment_search_content_html + settings_click_search_html + "<p>" + settings_highlight_tool_html + settings_autocomplete_html + "&nbsp;&nbsp;" + settings_web_search_in_new_tab_html + volume_settings + "</form></div>");
    setting_h_for_font = 0;
    if (settings_font_family_options_html) {
        setting_h_for_font += (37 * 2)
    }
    if (settings_line_height_options_html) {
        setting_h_for_font += 37
    }
    if (settings_increment_search_content_html) {
        setting_h_for_font += 37
    }
    if (settings_paragraphs_size_options_html) {
        setting_h_for_font += 37
    }
    if (settings_highlight_tool_html) {
        setting_h_for_font += 37
    }
    if (settings_autocomplete_html) {
        setting_h_for_font += 37
    }
    if (settings_list_ratio_html) {
        setting_h_for_font += 37
    }
    var a = $(window).height();
    var c = 320 + setting_h_for_font + (isChrome ? -36 : 10);
    if (c > a) {
        c = a
    }
    $("#dialog-setting").dialog({
        modal: false,
        draggable: true,
        resizable: false,
        width: 500,
        closeOnEscape: false,
        beforeClose: function(d, e) {
            g_show_setting_dialog = false
        },
        close: function(d, e) {
            $("#dialog-setting").dialog("destroy").remove();
            g_show_setting_dialog = false;
            audioElement.volume = dialog_volume_value / 100;
            $("#content").css("lineHeight", settings_line_height);
            updateShowHighlightTool(show_highlight_tool);
            resize(g_list_ratio);
            if (settings_font_family_options_html) {
                $("#content").css("fontFamily", settings_font_family);
                $("#content").css("fontSize", settings_font_size + "px");
                $("#content img.fontcode").css("height", settings_font_size + "px");
                $("#content img.fontcode").css("width", "auto");
                changelistFontSize(settings_list_font_size);
                changelistfontFamily(settings_list_font_family)
            }
        },
        buttons: [{
            text: dialog_ok_label,
            click: function() {
                g_list_ratio = temp_list_ratio;
                $(this).dialog("close");
                g_show_setting_dialog = false;
                settings_search_size = dialog_settings_search_size;
                settings_inc_search_size = dialog_settings_inc_search_size;
                dialog_volume_value = temp_dialog_volume_value;
                audioElement.volume = dialog_volume_value / 100;
                settings_line_height = temp_settings_line_height;
                settings_paragraphs_size = temp_settings_paragraphs_size;
                only_increment = temp_only_increment;
                g_click_search = temp_click_search;
                updateClickSearchIcon();
                settings_autocomplete = temp_settings_autocomplete;
                settings_web_search_in_new_tab = temp_settings_web_search_in_new_tab;
                updateAutoComplete(settings_autocomplete);
                show_highlight_tool = temp_show_highlight_tool;
                $("#content").css("lineHeight", settings_line_height);
                updateShowHighlightTool(show_highlight_tool);
                if (settings_font_family_options_html) {
                    settings_font_family = temp_settings_font_family;
                    settings_font_size = temp_settings_font_size;
                    settings_list_font_family = temp_settings_list_font_family;
                    settings_list_font_size = temp_settings_list_font_size;
                    list_itemHeight = temp_list_itemHeight;
                    $("#content").css("fontFamily", settings_font_family);
                    $("#content").css("fontSize", settings_font_size + "px");
                    $("#content img.fontcode").css("height", settings_font_size + "px");
                    $("#content img.fontcode").css("width", "auto");
                    changelistFontSize(settings_list_font_size);
                    changelistfontFamily(settings_list_font_family)
                }
                setStatus(2);
                ws.send({
                    cmd: "req_set_web_settings",
                    list_size: settings_search_size,
                    inc_list_size: settings_inc_search_size,
                    volume: parseInt(audioElement.volume * 100),
                    font_family: (settings_font_family_options_html ? settings_font_family : ""),
                    font_size: (settings_font_family_options_html ? settings_font_size : 16),
                    list_font_family: (settings_font_family_options_html ? settings_list_font_family : ""),
                    list_font_size: (settings_font_family_options_html ? settings_list_font_size : 13),
                    line_height: settings_line_height,
                    only_increment: only_increment,
                    click_search: g_click_search,
                    autocomplete: settings_autocomplete,
                    web_search_in_new_tab: settings_web_search_in_new_tab,
                    paragraphs_size: settings_paragraphs_size,
                    show_highlight_tool: show_highlight_tool,
                    list_layout_ratio: g_list_ratio
                })
            }
        }, {
            text: dialog_cancel_label,
            click: function() {
                $(this).dialog("close");
                g_show_setting_dialog = false
            }
        }]
    });
    $("#paragraphs_size").change(function() {
        var d = $(this).val();
        temp_settings_paragraphs_size = d
    });
    dialog_settings_search_size = settings_search_size;
    dialog_settings_inc_search_size = settings_inc_search_size;
    dialog_volume_value = parseInt(audioElement.volume * 100);
    $("#list_size").change(function() {
        var d = $(this).val();
        dialog_settings_search_size = d
    });
    $("#inc_list_size").change(function() {
        var d = $(this).val();
        dialog_settings_inc_search_size = d
    });
    if (settings_font_family_options_html) {
        $("#font_family").change(function() {
            var d = $(this).val();
            temp_settings_font_family = d;
            $("#content").css("fontFamily", temp_settings_font_family)
        });
        $("#font_size").change(function() {
            var d = $(this).val();
            temp_settings_font_size = d;
            $("#content").css("fontSize", temp_settings_font_size + "px");
            $("#content img.fontcode").css("height", temp_settings_font_size + "px");
            $("#content img.fontcode").css("width", "auto")
        });
        $("#list_font_family").change(function() {
            var d = $(this).val();
            temp_settings_list_font_family = d;
            changelistfontFamily(temp_settings_list_font_family)
        });
        $("#list_font_size").change(function() {
            var d = $(this).val();
            temp_settings_list_font_size = d;
            changelistFontSize(temp_settings_list_font_size);
            $("img.listfontcode").css("height", (temp_settings_list_font_size <= 13 ? 16 : temp_settings_list_font_size) + "px");
            $("img.listfontcode").css("width", "auto");
            changelistfontFamily(settings_list_font_family)
        })
    }
    $("#line_height").change(function() {
        var d = $(this).val();
        temp_settings_line_height = d;
        $("#content").css("lineHeight", temp_settings_line_height)
    });
    $("#inc_search_content").change(function() {
        if (this.checked) {
            temp_only_increment = 0
        } else {
            temp_only_increment = 1
        }
    });
    $("#use_click_search").change(function() {
        if (this.checked) {
            temp_click_search = 1
        } else {
            temp_click_search = 0
        }
    });
    $("#show_highlight_tool").change(function() {
        if (this.checked) {
            temp_show_highlight_tool = 1
        } else {
            temp_show_highlight_tool = 0
        }
        updateShowHighlightTool(temp_show_highlight_tool)
    });
    $("#use_autocomplete").change(function() {
        if (this.checked) {
            temp_settings_autocomplete = 1
        } else {
            temp_settings_autocomplete = 0
        }
    });
    $("#web_search_in_new_tab").change(function() {
        if (this.checked) {
            temp_settings_web_search_in_new_tab = 1
        } else {
            temp_settings_web_search_in_new_tab = 0
        }
    });
    temp_list_ratio = g_list_ratio;
    $("#list_ratio_value").text(g_list_ratio);
    $("#list_ratio_slider").slider({
        value: g_list_ratio,
        orientation: "horizontal",
        min: 0.1,
        max: 0.9,
        step: 0.025,
        range: "min",
        animate: false,
        change: function(d, e) {
            value = e.value;
            $("#list_ratio_value").text(value);
            temp_list_ratio = value
        },
        slide: function(d, e) {
            $("#list_ratio_value").text(e.value);
            resize(e.value)
        }
    });
    audioElement = document.getElementById("audiotag");
    log("audioPlayer.volume = " + audioElement.volume);
    temp_dialog_volume_value = dialog_volume_value;
    $("#sound_volume").slider({
        value: parseInt(audioElement.volume * 100),
        orientation: "horizontal",
        min: 0,
        max: 100,
        step: 1,
        range: "min",
        animate: false,
        change: function(d, e) {
            value = e.value;
            temp_dialog_volume_value = value;
            $("#volume_value").text(value);
            audioElement.volume = temp_dialog_volume_value / 100
        },
        slide: function(d, e) {
            $("#volume_value").text(e.value)
        }
    });
    $("#dialog-settings").css("fontFamily", ui_widget_font_family);
    g_show_setting_dialog = true
}
function closeSearchFullDialog() {
    if (isShowSearchFullDialog) {
        $("#dialog-message").dialog("close");
        $("#dialog-message").dialog("destroy").remove()
    }
    isShowSearchFullDialog = false
}
function showSearchFullDialog() {
    if (isShowSearchFullDialog) {
        return
    }
    beforeShowDialog();
    $("body").append('<div id="dialog-message" title="Full Search"><p>' + dialog_full_search_searching_label + "(" + res_string_all + ': <span id="search_full_dic_hits">0</span>)</p><p><div id="progressbar"></div><span id="search_full_progress">0</span>&nbsp;%</p></div>');
    $("#dialog-message").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        width: 500,
        closeOnEscape: false,
        open: function(a, c) {
            $(".ui-dialog-titlebar-close", $(this).parent()).hide()
        },
        beforeClose: function(a, c) {
            isShowSearchFullDialog = false
        },
        buttons: [{
            text: dialog_cancel_label,
            click: function() {
                ws.send({
                    cmd: "req_search_full_stop"
                })
            }
        }]
    });
    $("#progressbar").progressbar({
        value: 0,
        max: 100
    });
    isShowSearchFullDialog = true;
    $("#dialog-message").css("fontFamily", ui_widget_font_family)
}
function isAllASCII(a) {
    return /^[\x00-\x7F]*$/.test(a)
}
function EmphasizeSearchWord2(A, E, B) {
    var q = "";
    var n = E.length;
    var c = 0;
    var y = 0;
    var l = A.length;
    var u = E.length;
    if (E.length == 0 || A.length <= 0) {
        return A
    }
    var z = isAllASCII(E);
    var x = null ;
    var G = null ;
    if (z) {
        x = A.toLowerCase();
        G = E.toLowerCase()
    }
    while (true) {
        if (x != null ) {
            c = x.indexOf(G, c)
        } else {
            c = A.indexOf(E, c)
        }
        if (c == -1) {
            break
        }
        var C = A.indexOf("<", c);
        var D = A.indexOf(">", c);
        if ((C != -1 && D != -1 && D < C) || (D != -1 && C == -1)) {
            c++;
            continue
        }
        if (z) {
            var m = 10;
            var a = (c - m <= 0 ? 0 : c - m);
            var H = 0;
            if (c - m <= 0) {
                H = c
            } else {
                H = m
            }
            var F = (c + m >= l - 1 ? l - 1 : c + m);
            var o = x.substring(a, F + 1);
            if (H != -1) {
                var g = o.lastIndexOf("&", H);
                var f = o.lastIndexOf(";", H);
                var e = o.indexOf(";", H + u);
                var d = o.indexOf("&", H + u);
                if ((g != -1 && g > f) && (e != -1 && (d == -1 || e < d))) {
                    c++;
                    continue
                }
            }
        }
        q += A.substring(y, c);
        q += "<span class='keysearch'>";
        q += A.substring(c, c + E.length);
        q += "</span>";
        c += n;
        y = c
    }
    if (y < A.length) {
        q += A.substring(y, A.length)
    }
    return q
}
function checkContentSearch(d) {
    var c = d.replace(/\u3000/g, " ").trim();
    var f = c.lastIndexOf("@");
    var a = c.lastIndexOf("#");
    var e = false;
    if (f != -1 && !c.endsWith("@")) {
        e = true
    } else {
        if (a != -1 && !c.endsWith("#")) {
            e = true
        }
    }
    return e
}
function parseContentSearch(d) {
    var c = d.trim();
    var f = "";
    var e = c.lastIndexOf("@");
    var a = c.lastIndexOf("#");
    if (e != -1 && !c.endsWith("@")) {
        f = c.substring(e + 1)
    } else {
        if (a != -1 && !c.endsWith("#")) {
            f = c.substring(0, a)
        }
    }
    return f
}
function old_checkContentSearch(d) {
    var g = d.replace(/\u3000/g, " ").trim();
    var e = false;
    var c = g.indexOf(" ");
    var f = g.lastIndexOf("@");
    var a = g.lastIndexOf("#");
    if ((f != -1 || a != -1) && c != -1 && ((f != -1 && f > c) || (a != -1 && a > c))) {
        e = true
    }
    if ((f != -1 || a != -1) && c == -1) {
        e = true
    }
    return e
}
function old_parseContentSearch(e) {
    var d = e.trim();
    var l = "";
    var f = false;
    var c = d.indexOf(" ");
    var g = d.lastIndexOf("@");
    var a = d.lastIndexOf("#");
    if ((g != -1 || a != -1) && c != -1 && ((g != -1 && g > c) || (a != -1 && a > c))) {
        if (d.endsWith("#") || d.endsWith("@")) {
            if (d.endsWith("@") && g - c > 1) {
                l = d.substring(c + 1, d.length - 1)
            } else {
                if (d.endsWith("#") && a - c > 1) {
                    l = d.substring(0, d.length - 1)
                }
            }
        } else {
            if ((a == -1 || g > a) && g - c > 1) {
                l = d.substring(c + 1, g)
            } else {
                if ((g == -1 || a > a) && a - c > 1) {
                    l = d.substring(0, a)
                }
            }
        }
    }
    if ((g != -1 || a != -1) && c == -1) {
        if (g != -1 && !d.endsWith("@")) {
            l = d.substring(0, g)
        } else {
            if (a != -1 && !d.endsWith("#")) {
                l = d.substring(0, a)
            }
        }
    }
    return l
}
function EmphasizeSearchWord(n, m, l, e, d) {
    if (g_word_emphasize == 0) {
        return m
    }
    multi_keywords = null ;
    if ((typeof d) != "undefined") {
        multi_keywords = d
    }
    if (multi_keywords != null && ebdic_mode == 1) {
        for (i = 0; i < multi_keywords.length; i++) {
            m = EmphasizeSearchWord2(m, multi_keywords[i].trim(), e)
        }
        return m
    }
    if (n != null ) {
        l = n
    }
    l = l.trim();
    if (searchMethod != 4 && checkContentSearch(l)) {
        var a = l.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/\u3000/g, " ");
        var g = parseContentSearch(a);
        if (g_tnw == 1) {
            g = g.trim().replace(" ", "*")
        }
        if (IsRegexString(g)) {
            var c = strstrhtmlpat(m, g, -1, -1, 1);
            if (c != null ) {
                m = c
            }
        } else {
            m = EmphasizeSearchWord2(m, g, e)
        }
    } else {
        if (searchMethod != 3 && searchMethod != 4) {
            var a = l.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/\u3000/g, " ");
            m = EmphasizeSearchWord2(m, a, e)
        } else {
            var a = l;
            if (searchMethod == 4) {
                a = l.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/\u3000/g, " ")
            } else {
                a = l.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/\u3000/g, " ")
            }
            var f = null ;
            if (searchMethod == 4 && a.indexOf("|") != -1) {
                f = a.split("|")
            } else {
                if (searchMethod == 4 && a.indexOf("&") != -1) {
                    f = a.split("&")
                } else {
                    if (searchMethod == 3) {
                        f = a.split(" ")
                    } else {
                        f = [a]
                    }
                }
            }
            for (i = 0; i < f.length; i++) {
                m = EmphasizeSearchWord2(m, f[i].trim(), e)
            }
        }
    }
    return m
}
function IsRegexString(a) {
    return a.contains("*")
}
function PatternIndexOf(a, e, g) {
    var d = new RegExp(a,"ig");
    d.lastIndex = g;
    var c = [];
    c[0] = -1;
    c[1] = 0;
    var f = d.exec(e);
    if (f != null ) {
        c[0] = f.index;
        c[1] = f[0].length
    }
    return c
}
var g_check_tag = false;
function regexFind(m, a, n, O, V) {
    var g = a.length;
    var G = 1;
    var x = "";
    var f = 0;
    var I = 0;
    var R = m.length;
    var L = a.length;
    if (a.length == 0 || m.length <= 0) {
        return null
    }
    var E = false;
    E = isAllASCII(a, true, true);
    var c = null ;
    var N = null ;
    if (E) {
        c = m.toLowerCase();
        N = a.toLowerCase()
    }
    var d = "";
    var T = "";
    var o = null ;
    if (G > 0) {
        var y = null ;
        if (E) {
            y = N
        } else {
            y = a
        }
        var P = "\\.[]{}()*+-?^$|";
        var H = "\\";
        var Q = 0;
        for (Q = 0; Q < y.length; Q++) {
            var K = y[Q];
            if (K == "*") {
                if (g_check_tag) {
                    T += "((?!<br>).)*?"
                } else {
                    T += "[^<>&]*?"
                }
            } else {
                if (P.contains(K)) {
                    K = H + K
                }
                T += K
            }
        }
        d = T
    }
    var e = false;
    while (true) {
        var F = null ;
        if (c != null ) {
            if (G > 0) {
                F = PatternIndexOf(d, c, f);
                f = F[0]
            } else {
                f = c.indexOf(N, f)
            }
        } else {
            if (G > 0) {
                F = PatternIndexOf(d, m, f);
                f = F[0]
            } else {
                f = m.indexOf(a, f)
            }
        }
        if (f == -1) {
            break
        }
        var u = m.indexOf("<", f);
        var U = m.indexOf(">", f);
        if ((u != -1 && U != -1 && U < u) || (U != -1 && u == -1)) {
            f++;
            continue
        }
        if (E) {
            var q = 10;
            var l = (f - q <= 0 ? 0 : f - q);
            var S = 0;
            if (f - q <= 0) {
                S = f
            } else {
                S = q
            }
            var M = (f + q >= R - 1 ? R - 1 : f + q);
            var A = c.substring(l, M + 1);
            if (S != -1) {
                var D = A.lastIndexOf("&", S);
                var C = A.lastIndexOf(";", S);
                var B = A.indexOf(";", S + L);
                var z = A.indexOf("&", S + L);
                if ((D != -1 && D > C) && (B != -1 && (z == -1 || B < z))) {
                    f++;
                    continue
                }
            }
        }
        e = true;
        if (V == 0) {
            break
        }
        x += (m.substring(I, f));
        if (G > 0) {
            x += ("<span class='keysearch'>");
            var J = m.indexOf("<", f);
            if (J >= 0 && J < f + F[1]) {
                F[1] = J - f
            }
            o = (m.substring(f, f + F[1]));
            x += (o);
            x += ("</span>")
        } else {
            x += ("<span class='keysearch'>");
            x += (m.substring(f, f + a.length));
            x += ("</span>")
        }
        if (G > 0) {
            f += F[1]
        } else {
            f += g
        }
        I = f
    }
    if (!e) {
        return null
    }
    if (V == 0) {
        return ""
    }
    if (I < m.length) {
        x += m.substring(I, m.length)
    }
    return x
}
function checkTagExists(l, a, e) {
    var n = a;
    var c = -1;
    var m = ["<b>", "<i>", "<font", "<u>"];
    var g = 4;
    var f = 0;
    var d = 1;
    while (true) {
        c = l.indexOf("<", n);
        if (c < 0 || c >= e) {
            break
        }
        if ((c + 1) <= e && l[c + 1] == "/") {
            n++;
            continue
        }
        d = 0;
        for (f = 0; f < g; f++) {
            if ((c + m[f].length) <= e) {
                if (l.substring(c, c + m[f].length) == m[f]) {
                    d = 1;
                    break
                }
            }
        }
        if (d == 0) {
            return true
        }
        n++
    }
    return false
}
function strstrhtmlpat(o, a, u, S, Y) {
    var z = "";
    var g = 0;
    var I = 0;
    var T = o.length;
    a = a.trim().replace("^\\*+", "").replace("\\*+$", "");
    if (a.length == 0 || o.length <= 0) {
        return null
    }
    var M = o;
    o = o.toLowerCase();
    a = a.toLowerCase();
    var c = a.split("*");
    var e = false;
    var d = [];
    while (true) {
        g = o.indexOf(c[0], g);
        if (g == -1) {
            break
        }
        var y = o.indexOf("<", g);
        var X = o.indexOf(">", g);
        if ((y != -1 && X != -1 && X < y) || (X != -1 && y == -1)) {
            g++;
            continue
        }
        d = [];
        if (isAllASCII(c[0], true, true)) {
            var N = c[0].length;
            var x = 10;
            var n = (g - x <= 0 ? 0 : g - x);
            var V = 0;
            if (g - x <= 0) {
                V = g
            } else {
                V = x
            }
            var Q = (g + x >= T - 1 ? T - 1 : g + x);
            var D = o.substring(n, Q + 1);
            if (V != -1) {
                var G = D.lastIndexOf("&", V);
                var F = D.lastIndexOf(";", V);
                var E = D.indexOf(";", V + N);
                var C = D.indexOf("&", V + N);
                if ((G != -1 && G > F) && (E != -1 && (C == -1 || E < C))) {
                    g++;
                    continue
                }
            }
        }
        d.push([g, c[0].length]);
        var f = g;
        var l = 0;
        var J = g;
        var W = true;
        for (var U = 1; U < c.length; U++) {
            if (c[U].length <= 0) {
                continue
            }
            f = o.indexOf(c[U], J);
            if (f < 0) {
                W = false
            }
            J = f + c[U].length;
            var A = isEntityAndTag(isAllASCII(c[U], true, true), o, o, o.length, c[U].length, f);
            if (A) {
                U = U - 1
            } else {
                d.push([f, c[U].length])
            }
        }
        if (!W) {
            g++;
            continue
        }
        var P = f + c[c.length - 1].length;
        if (checkTagExists(o, g, P)) {
            g++;
            continue
        }
        z += (M.substring(I, g));
        var m = P;
        var R = false;
        var K = o.indexOf("<", g);
        if (K >= 0 && K < P) {
            R = true
        }
        if (!R) {
            z += ("<span class='keysearch'>");
            var q = (M.substring(g, m));
            z += (q);
            z += ("</span>")
        } else {
            for (var U = 0; U < d.length; U++) {
                var B = d[U][0];
                var L = d[U][1];
                z += ("<span class='emphasized_word'>");
                var q = (M.substring(B, B + L));
                z += (q);
                z += ("</span>");
                if (U != d.size.length - 1) {
                    var H = d[U + 1][0];
                    var O = d[U + 1][1];
                    z += (M.substring(B + L, H))
                }
            }
        }
        g = P;
        I = g
    }
    if (I < o.length) {
        z += M.substring(I, o.length)
    }
    return z
}
function isEntityAndTag(x, l, c, g, u, z) {
    var d = l.indexOf("<", z);
    var a = l.indexOf(">", z);
    if ((d != -1 && a != -1 && a < d) || (a != -1 && d == -1)) {
        return true
    }
    if (x) {
        var y = 10;
        var A = (z - y <= 0 ? 0 : z - y);
        var B = 0;
        if (z - y <= 0) {
            B = z
        } else {
            B = y
        }
        var e = (z + y >= g - 1 ? g - 1 : z + y);
        var n = c.substring(A, e + 1);
        if (B != -1) {
            var q = n.lastIndexOf("&", B);
            var o = n.lastIndexOf(";", B);
            var m = n.indexOf(";", B + u);
            var f = n.indexOf("&", B + u);
            if ((q != -1 && q > o) && (m != -1 && (f == -1 || m < f))) {
                return true
            }
        }
    }
    return false
}
function initToolTip() {
    return;
    var a = {
        show: null ,
        position: {
            my: "left top",
            at: "left bottom"
        },
        open: function(c, d) {
            d.tooltip.animate({
                top: d.tooltip.position().top + 10
            }, "fast")
        }
    };
    $("#prev_dic_btn").tooltip(a);
    $("#next_dic_btn").tooltip(a);
    $("#history_btn").tooltip(a);
    $("#yahoo_btn").tooltip(a);
    $("#dics_btn").tooltip(a);
    $("#play_btn").tooltip(a);
    $("#add_btn").tooltip(a);
    $("#setting_btn").tooltip(a);
    $("#prev_btn").tooltip(a);
    $("#next_btn").tooltip(a);
    $("#left_left_btn").tooltip(a);
    $("#left_btn").tooltip(a);
    $("#note_btn").tooltip(a);
    $("#pages_btn").tooltip(a);
    $("#right_btn").tooltip(a);
    $("#right_right_btn").tooltip(a)
}
function scaleFontImage(a) {
    a.setAttribute("height", (settings_list_font_size <= 13 ? 16 : settings_list_font_size) + "px");
    a.setAttribute("width", "auto");
    delete a
}
function base0HighlightSingle(d, c, a) {
    if (a) {
        c = c.substring("type:textContent|".length)
    }
    v = c.split("$");
    v[0] = parseInt(v[0]) - d;
    v[1] = parseInt(v[1]) - d;
    jv = v.join("$");
    return jv
}
function regenHighlight(e, d) {
    d = d.substring("type:textContent|".length);
    var c = d.split("|");
    var a = "type:textContent";
    for (i = 0; i < c.length; i++) {
        v = c[i].split("$");
        v[0] = parseInt(v[0]) + e;
        v[1] = parseInt(v[1]) + e;
        jv = v.join("$");
        a += "|" + jv
    }
    return a
}
function setDisconnect(a) {
    if (a) {
        $("#status").attr("src", "./img/disconnect.png");
        $("#status").show()
    } else {
        if (g_theme_type == 0) {
            $("#status").attr("src", "./img/loading_black.gif")
        } else {
            $("#status").attr("src", "./img/loading.gif")
        }
        $("#status").hide()
    }
}
function setStatus(a) {
    var c;
    if (a == 0) {
        c = "ebdic"
    } else {
        if (a == 1) {
            c = "searching ..."
        } else {
            if (a == 2) {
                c = "processing ..."
            }
        }
    }
    log("[setStatus] msg=" + c);
    if (a == 0) {
        $("#status").hide()
    } else {
        $("#status").show()
    }
    audioElement = document.getElementById("audiotag");
    if (!audioElement.paused) {
        audioElement.pause()
    }
    $("#audio_div").hide()
}
function encodeKeyword(a) {
    return a.replace(/%/g, "%25").replace(/&/g, "%26").replace(/:/g, "%3A").replace(/</g, "&lt;").replace(/>/g, "&gt;")
}
function decodeKeyword(a) {
    return a.replace(/%3A/g, ":").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/%26/g, "&").replace(/%25/g, "%")
}
function encodeWebSite(a) {
    return a.replace(/%/g, "%25").replace(/:/g, "%3A").replace(/=/g, "%3D").replace(/\?/g, "%3F").replace(/\//g, "%2F").replace(/</g, "%3C").replace(/>/g, "%3E").replace(/"/g, "%22").replace(/'/g, "%26")
}
function decodeWebSite(a) {
    return a.replace(/%3A/g, ":").replace(/%3C/g, "<").replace(/%3D/g, "=").replace(/%3F/g, "?").replace(/%2F/g, "/").replace(/%3E/g, ">").replace(/%22/g, '"').replace(/%26/g, "'").replace(/%25/g, "%")
}
var notebook_highlight_map = {};
var sort_notebook_highlight = [];
function decodeNote(a) {
    return a.replace(/%40/g, "@").replace(/%3D/g, "=").replace(/%26/g, "&").replace(/%23/g, "#").replace(/%25/g, "%")
}
function encodeNote(a) {
    return a.replace(/%/g, "%25").replace(/@/g, "%40").replace(/=/g, "%3D").replace(/&/g, "%26").replace(/#/g, "%23")
}
function parseHighlightExtra(g, d) {
    notebook_highlight_map = {};
    sort_notebook_highlight = [];
    var x = "type:textContent|";
    var m = "";
    var q = g.split("#");
    for (i = 0; i < q.length; i++) {
        var o = q[i].split("@");
        var c = {
            "0": "",
            "1": ""
        };
        if (o.length <= 1) {
            c[0] = "";
            c[1] = ""
        } else {
            if (o.length == 2) {
                c[0] = decodeNote(o[1]);
                c[1] = ""
            } else {
                c[0] = decodeNote(o[1]);
                c[1] = decodeNote(o[2])
            }
        }
        new_id = "";
        try {
            var u = o[0].split("$");
            var a = parseInt(u[0]) + d;
            var f = parseInt(u[1]) + d;
            var n = u[3];
            new_id = a + "$" + f + "$" + u[2] + "$";
            if (n.startsWith("note")) {
                new_id += n + "$";
                np = {};
                np.note_id = new_id;
                np.start = a;
                np.end = f;
                np.type = 1;
                sort_notebook_highlight.push(np)
            } else {
                new_id += n + "$"
            }
        } catch (l) {
            return ""
        }
        notebook_highlight_map[new_id] = c;
        if (i == 0) {
            m = x + o[0]
        } else {
            m += "|" + o[0]
        }
    }
    sortNotebookHighlight();
    return m
}
var g_close_edit_note_from_out = false;
function closeEditNoteDialog() {
    if (isShowEditNoteDialog) {
        g_close_edit_note_from_out = true;
        $("#dialog-edit-note").dialog("close");
        g_close_edit_note_from_out = false;
        $("#dialog-edit-note").dialog("destroy").remove()
    }
    isShowEditNoteDialog = false
}
function showEditNoteDialog(e, d, a, c) {
    if (isShowEditNoteDialog) {
        return
    }
    beforeShowDialog();
    prev_comment = d;
    np = null ;
    index = -1;
    for (i = 0; i < sort_notebook_highlight.length; i++) {
        npp = sort_notebook_highlight[i];
        if (npp.note_id == e) {
            np = npp;
            index = i;
            break
        }
    }
    index_label = (index + 1) + "/" + sort_notebook_highlight.length;
    dialog_title = "[" + index_label + "]\u00a0\u00a0" + dialog_title_edit_note;
    $("body").append('<div id="dialog-edit-note" title="' + dialog_title + '"><div style="color:#2e6e9e">' + dialog_edit_note_tag + ':\u00a0\u00a0<span id="edit-note-tag" class="ellipsis_tag" style="color:gray;width:400px;">' + a + '</span></div><br><div style="margin: 0 auto; text-align: center;"><textarea id="memo_content" rows="15" cols="40" style=" resize: none;">' + d + "</textarea></div></div>");
    $("#dialog-edit-note").dialog({
        modal: true,
        draggable: true,
        resizable: false,
        width: 430,
        closeOnEscape: false,
        beforeClose: function(f, g) {
            isShowEditNoteDialog = false
        },
        open: function() {
            $("#edit_note_delete_btn").html('<img src="./img/note_delete.png">');
            w = $("#edit_note_ok_btn").width();
            h = $("#edit_note_ok_btn").height() + 1;
            $("#edit_note_delete_btn").css("width", w + "px");
            $("#edit_note_delete_btn").css("height", h + "px")
        },
        close: function(g, l) {
            if (!g_close_edit_note_from_out) {
                var m = $("textarea#memo_content").val();
                if (g_flash_card_row_id < 0) {
                    if (m != d || d == "") {
                        updateNotebookHighlightComment(e, m, a);
                        SendHighlightString()
                    }
                }
            } else {
                if (c) {
                    delete notebook_highlight_map[e];
                    var f = -1;
                    for (j = 0; j < sort_notebook_highlight.length; j++) {
                        np = sort_notebook_highlight[j];
                        if (np.note_id == e) {
                            f = j;
                            break
                        }
                    }
                    if (f >= 0) {
                        sort_notebook_highlight.splice(f, 1)
                    }
                    highlighter.removeAllHighlights();
                    data = generateRangyHighlightString();
                    if (data) {
                        highlighter.deserialize(data)
                    }
                    unSelect()
                }
            }
            $("#dialog-edit-note").dialog("destroy").remove();
            isShowEditNoteDialog = false
        },
        buttons: [{
            text: "\u25C0",
            click: function() {
                if (!checkConnect()) {
                    return
                }
                if (sort_notebook_highlight.length == 1) {
                    return
                }
                if (index == 0) {
                    index = sort_notebook_highlight.length - 1
                } else {
                    index--
                }
                var f = $("textarea#memo_content").val();
                o_comment = notebook_highlight_map[e][0];
                if (g_flash_card_row_id < 0) {
                    if (o_comment != f || o_comment == "") {
                        updateNotebookHighlightComment(e, f, a);
                        SendHighlightString()
                    }
                }
                np = sort_notebook_highlight[index];
                p = notebook_highlight_map[np.note_id];
                d = p[0];
                a = p[1];
                e = np.note_id;
                c = false;
                $("textarea#memo_content").val(d);
                index_label = (index + 1) + "/" + sort_notebook_highlight.length;
                dialog_title = "[" + index_label + "]\u00a0\u00a0" + dialog_title_edit_note;
                $("#dialog-edit-note").dialog({
                    title: dialog_title
                });
                $("#edit-note-tag").text(a)
            }
        }, {
            text: "\u25B6",
            click: function() {
                if (!checkConnect()) {
                    return
                }
                if (sort_notebook_highlight.length == 1) {
                    return
                }
                if (index == sort_notebook_highlight.length - 1) {
                    index = 0
                } else {
                    index++
                }
                var f = $("textarea#memo_content").val();
                o_comment = notebook_highlight_map[e][0];
                if (g_flash_card_row_id < 0) {
                    if (o_comment != f || o_comment == "") {
                        updateNotebookHighlightComment(e, f, a);
                        SendHighlightString()
                    }
                }
                np = sort_notebook_highlight[index];
                p = notebook_highlight_map[np.note_id];
                d = p[0];
                a = p[1];
                e = np.note_id;
                c = false;
                $("textarea#memo_content").val(d);
                index_label = (index + 1) + "/" + sort_notebook_highlight.length;
                dialog_title = "[" + index_label + "]\u00a0\u00a0" + dialog_title_edit_note;
                $("#dialog-edit-note").dialog({
                    title: dialog_title
                });
                $("#edit-note-tag").text(a)
            }
        }, {
            id: "edit_note_delete_btn",
            click: function() {
                if (!checkConnect()) {
                    return
                }
                if (e) {
                    showConfirmDeleteEditNoteDialog(e, c)
                } else {
                    $(this).dialog("close")
                }
            }
        }, {
            text: dialog_ok_label,
            id: "edit_note_ok_btn",
            click: function() {
                if (!checkConnect()) {
                    return
                }
                $(this).dialog("close")
            }
        }]
    });
    if (g_flash_card_row_id >= 0) {
        $("#memo_content").attr("readonly", "readonly");
        $("#edit_note_delete_btn").button("disable")
    }
    isShowEditNoteDialog = true;
    $("#dialog-confirm-delete-edit-note-words").css("fontFamily", ui_widget_font_family)
}
var isShowConfirmDeleteEditNoteDialog = false;
function closeConfirmDeleteEditNoteDialog() {
    if (isShowConfirmDeleteEditNoteDialog) {
        $("#dialog-confirm-delete-edit-note-words").dialog("close");
        $("#dialog-confirm-delete-edit-note-words").dialog("destroy").remove()
    }
    isShowConfirmDeleteEditNoteDialog = false
}
function showConfirmDeleteEditNoteDialog(d, c) {
    if (isShowConfirmDeleteEditNoteDialog) {
        return
    }
    beforeShowDialog();
    var a = d;
    message = dialog_message_delete_highlight;
    $("body").append('<div id="dialog-confirm-delete-edit-note-words" title="' + dialog_title_delete_highlight + '"><span style="font-weight: bold;color:#2e6e9e;font-family:' + ui_widget_font_family + '">' + message + "</span></div>");
    $("#dialog-confirm-delete-edit-note-words").dialog({
        modal: true,
        draggable: false,
        resizable: false,
        closeOnEscape: false,
        beforeClose: function(e, f) {
            isShowConfirmDeleteEditNoteDialog = false
        },
        close: function(e, f) {
            $("#dialog-confirm-delete-edit-note-words").dialog("destroy").remove();
            isShowConfirmDeleteEditNoteDialog = false
        },
        buttons: [{
            text: dialog_yes_label,
            click: function() {
                if (!checkConnect()) {
                    $(this).dialog("close");
                    return
                }
                delete notebook_highlight_map[a];
                var e = -1;
                for (j = 0; j < sort_notebook_highlight.length; j++) {
                    np = sort_notebook_highlight[j];
                    if (np.note_id == a) {
                        e = j;
                        break
                    }
                }
                if (e >= 0) {
                    sort_notebook_highlight.splice(e, 1)
                }
                highlighter.removeAllHighlights();
                data = generateRangyHighlightString();
                if (data) {
                    highlighter.deserialize(data)
                }
                unSelect();
                if (!c) {
                    SendHighlightString()
                }
                closeEditNoteDialog();
                $(this).dialog("close")
            }
        }, {
            text: dialog_no_label,
            click: function() {
                $(this).dialog("close")
            }
        }]
    });
    isShowConfirmDeleteEditNoteDialog = true;
    $("#dialog-confirm-delete-edit-note-words").css("fontFamily", ui_widget_font_family)
}
var g_go_page = -1;
var g_go_offset = -1;
var g_go_book_index = -1;
var g_go_db_pos = -1;
var g_go_note = 0;
var g_go_history = 0;
var g_go_position = "";
var g_go_keyword = "";
var g_go_db_name = "";
var g_go_custom_word_row_id = -1;
function parseGoToPage(e, d) {
    g_go_position = e;
    g_go_history = 0;
    g_go_db_pos = -1;
    if (d) {
        g_go_history = 1
    }
    var c = /.*<!--note (.*)-->$/;
    a = e.match(c);
    if (a && a[1]) {
        t = a[1].trim().split(":");
        g_go_book_index = parseInt(t[0]);
        g_go_page = parseInt(t[1]);
        g_go_offset = parseInt(t[2]);
        g_go_db_pos = parseInt(t[3]);
        g_go_keyword = "";
        g_go_db_name = "";
        g_go_custom_word_row_id = -1;
        if (t[4]) {
            g_go_keyword = decodeKeyword(t[4])
        }
        if (t[6]) {
            g_go_db_name = decodeKeyword(t[6])
        }
        if (t[7]) {
            g_go_custom_word_row_id = parseInt(t[7])
        }
        g_go_note = 1;
        return
    }
    c = /.*<ref (.*)>.*/;
    a = e.match(c);
    if (a && a[1]) {
        t = a[1].trim().split(":");
        g_go_page = parseInt(t[0]);
        g_go_offset = parseInt(t[1]);
        g_go_book_index = parseInt(t[2]);
        g_go_note = 0;
        if (g_go_page == -4 && ebdic_mode == 1) {
            var c = /.*<!--website ([^>]*)-->.*/;
            var a = e.match(c);
            if (a && a[1]) {
                site = a[1].trim().split(":");
                g_web_search_name = decodeWebSite(site[1])
            }
        }
        return
    }
}
(function(c) {
    (jQuery.browser = jQuery.browser || {}).mobile = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(c) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(c.substr(0, 4))
})(navigator.userAgent || navigator.vendor || window.opera);
function mobileAndTabletcheck() {
    return jQuery.browser.mobile
}
window.onresize = function(a) {
    resize(g_list_ratio);
    window.setTimeout(function() {
        resize(g_list_ratio)
    }, 10)
}
;
var g_list_ratio = 0.275;
var g_click_search = 0;
var layout_margin_h = 65;
var magic_num = 28;
var magic_num2 = 4;
var magic_num3 = 3;
var g_resize_set_item_index = false;
function resize(d) {
    if (g_enable_resize == 0) {
        $("#wordlist").jqxListBox({
            width: "250px",
            height: "520px"
        });
        $("#content").css("width", "700px");
        $("#content").css("height", "500px");
        return
    }
    ww = $(window).width();
    wh = $(window).height();
    w = ww;
    h = wh - (layout_margin_h);
    if (pro == 1 || g_use_full_search == 1) {
        if (ww > 955) {
            $("#maintool").width(935);
            $("#status").css("left", "180px")
        } else {
            $("#maintool").width(570);
            $("#status").css("left", "20px")
        }
    } else {
        if (ww > 928) {
            $("#maintool").width(885);
            $("#status").css("left", "180px")
        } else {
            $("#maintool").width(540);
            $("#status").css("left", "20px")
        }
    }
    mw = $("#maintool").width();
    mh = $("#maintool").height();
    rw = 42;
    if (show_highlight_tool) {
        rh = 472
    } else {
        rh = 378
    }
    if (!g_highlight_show) {
        rw = magic_num3
    }
    table_cellspacing = parseInt($("#table_container").css("border-spacing"));
    pl = parseInt($("#table_container").css("padding-left"));
    pr = parseInt($("#table_container").css("padding-right"));
    w = w - table_cellspacing * 4 - rw - magic_num;
    w = w - pl - pr;
    if (w <= (mw + table_cellspacing * 2)) {
        w = (mw - table_cellspacing * 2)
    } else {}
    pb = parseInt($("#maintool").css("padding-bottom"));
    ch = h - mh - pb;
    if (ch < (rh - 10)) {
        ch = rh - 10
    }
    kw = parseInt(w * d) + "px";
    if (g_tnw_list_ui) {
        kh = (ch) + "px"
    } else {
        kh = (ch + 20) + "px"
    }
    khh = ch + "px";
    content_ratio = 1 - d;
    var c = $("#wordlist").jqxListBox("selectedIndex");
    var a = [];
    if (g_checkbox) {
        $("#wordlist").jqxListBox("selectedIndex");
        a = $("#wordlist").jqxListBox("getCheckedItems")
    }
    $("#wordlist").jqxListBox({
        width: kw,
        height: kh
    });
    $("#content").width(parseInt(w * content_ratio) + magic_num2);
    setWordListWidth(parseInt(w * d));
    $("#content").height(ch);
    if (c != -1 && !g_checkbox) {
        g_resize_set_item_index = true;
        $("#wordlist").jqxListBox("selectedIndex", c)
    }
    if (g_checkbox) {
        refreshCheckBox(a)
    }
    changelistfontFamily(settings_list_font_family)
}
function refreshCheckBox(a) {
    console.log("refreshCheckBox");
    for (i = 0; i < a.length; i++) {
        $("#wordlist").jqxListBox("checkIndex", a[i].index)
    }
}
function setWordListWidth(a) {
    if (a <= 35) {
        return
    }
    ww = $(window).width();
    wh = $(window).height();
    w = ww;
    h = wh - (layout_margin_h);
    mw = $("#maintool").width();
    mh = $("#maintool").height();
    rw = 42;
    if (!g_highlight_show) {
        rw = magic_num3
    }
    table_cellspacing = parseInt($("#table_container").css("border-spacing"));
    pl = parseInt($("#table_container").css("padding-left"));
    pr = parseInt($("#table_container").css("padding-right"));
    w = w - table_cellspacing * 4 - rw - magic_num;
    w = w - pl - pr;
    if (w <= (mw + table_cellspacing * 2)) {
        w = (mw - table_cellspacing * 2)
    } else {}
    pb = parseInt($("#maintool").css("padding-bottom"));
    ch = h - mh - pb;
    if (ch < (rh - 10)) {
        ch = rh - 10
    }
    kw = parseInt(a) + "px";
    kh = (ch + 20) + "px";
    khh = ch + "px";
    cw = w - a;
    if (cw <= 35) {
        return
    }
    $("#wordlist").jqxListBox({
        width: kw,
        height: kh
    });
    changelistfontFamily(settings_list_font_family);
    $("#content").width(cw + magic_num2);
    $("#content").height(ch);
    g_word_tag_width = a - 5 - 23;
    if (g_tnw_list_ui) {
        g_word_tag_width = a - 10 - 23
    }
    adjustWordTag()
}
function adjustWordTag() {
    cc = 18;
    if (g_tnw_list_ui) {
        cc = 22
    }
    wordlist_id = $("#wordlist").jqxListBox("id");
    var e = 0;
    if ($(wordlist_id).hasScrollBar()) {
        e = g_scroll_bar_width
    }
    var d = g_word_tag_width - e;
    $(".wordTag").css("left", (d - (g_checkbox ? cc : 0)) + "px");
    var c = ((list_itemHeight - 27) / 2);
    if (g_tnw_list_ui) {
        var a = 0;
        $(".wordTag").css("top", (c < 0 ? 0 : c + a) + "px")
    } else {
        a = (isFirefox ? 1 : 3);
        $(".wordTag").css("top", (c < 0 ? 0 : c + a) + "px")
    }
    if (settings_list_font_size == 13) {
        $(".wordTag").css("width", "21px")
    }
    $(".wordTag").show()
}
function clickWordTag(a, f) {
    if (!checkConnect()) {
        return
    }
    var d = $(a).attr("rowID");
    var c = "wordTag" + d;
    if (f) {
        f.stopPropagation()
    } else {
        window.event.stopPropagation()
    }
    setStatus(1);
    ws.send({
        cmd: "req_change_tag",
        rowId: d,
        tagId: c
    })
}
function loadWordTag(a) {
    if (g_tnw_list_ui) {
        return
    }
    cc = 18;
    if (g_tnw_list_ui) {
        cc = 22
    }
    $(a).css("left", (g_word_tag_width - (g_checkbox ? cc : 0)) + "px");
    tag_top = ((list_itemHeight - 27) / 2);
    if (g_tnw_list_ui) {
        tap_top = (settings_font_size + 8 - 14) / 2
    }
    top_offset = (isFirefox ? 1 : 3);
    $(a).css("top", (tag_top < 0 ? 0 : tag_top + top_offset) + "px");
    $(a).show()
}
g_handle_divider = false;
function handleDivider(a, c) {
    var d = $("#content").offset();
    content_height = $("#content").height();
    x2 = d.left;
    y1 = d.top;
    c_y2 = (d.top + content_height);
    d = $("#wordlist").offset();
    wordlist_width = $("#wordlist").width();
    wordlist_height = $("#wordlist").height();
    w_y2 = (d.top + wordlist_height);
    x1 = (d.left + wordlist_width);
    y2 = (c_y2 > w_y2 ? c_y2 : w_y2);
    g_divider_base_x = d.left;
    x1 = x1 + 1;
    x2 = x2 - 1;
    if (a == "mousedown") {
        if (x1 <= c.pageX && c.pageX <= x2 && y1 <= c.pageY && c.pageY <= y2) {
            $("html,body").css("cursor", "col-resize");
            $("#wordlist").css("cursor", "col-resize");
            g_handle_divider = true;
            return g_handle_divider
        }
    } else {
        if (a == "mouseup") {
            handle = false;
            if (g_handle_divider) {
                $("html,body").css("cursor", "");
                $("#wordlist").css("cursor", "");
                handle = true
            }
            g_handle_divider = false;
            return handle
        } else {
            if (a == "mousemove") {
                if (g_handle_divider) {
                    new_width = c.pageX - g_divider_base_x;
                    setWordListWidth(new_width)
                } else {
                    if (x1 <= c.pageX && c.pageX <= x2 && y1 <= c.pageY && c.pageY <= y2) {
                        $("html,body").css("cursor", "col-resize");
                        $("#wordlist").css("cursor", "col-resize")
                    } else {
                        $("html,body").css("cursor", "");
                        $("#wordlist").css("cursor", "")
                    }
                }
                return g_handle_divider
            }
        }
    }
}
function convertToKana(a) {
    return a
}
function updateRomHina() {
    if (g_rom_to_hina == 1) {
        $("#rom_to_hina_btn").css("color", "#000000");
        $("#rom_to_hina_btn").css("font-weight", "bold");
        $("#rom_to_hina_btn").attr("title", res_string_rom_to_hira)
    } else {
        $("#rom_to_hina_btn").css("color", "#c1c1c1");
        $("#rom_to_hina_btn").css("font-weight", "bold");
        $("#rom_to_hina_btn").attr("title", res_string_rom_to_hira)
    }
}
function initWordList() {
    if (g_theme_type == 1) {
        $("#wordlist").jqxListBox({
            theme: "custom2",
            source: [],
            enableHover: false
        })
    } else {
        $("#wordlist").jqxListBox({
            theme: "custom",
            source: [],
            enableHover: false
        })
    }
    if (!g_tnw_list_ui) {
        var a = $("#wordlist").find("#verticalScrollBarwordlist");
        a.jqxScrollBar({
            step: list_itemHeight
        })
    }
}
function log(a) {}
function createCookie(d, e, f) {
    if (f) {
        var c = new Date();
        c.setTime(c.getTime() + (f * 24 * 60 * 60 * 1000));
        var a = "; expires=" + c.toGMTString()
    } else {
        var a = ""
    }
    document.cookie = d + "=" + e + a + "; path=/"
}
function readCookie(d) {
    var f = d + "=";
    var a = document.cookie.split(";");
    for (var e = 0; e < a.length; e++) {
        var g = a[e];
        while (g.charAt(0) == " ") {
            g = g.substring(1, g.length)
        }
        if (g.indexOf(f) == 0) {
            return g.substring(f.length, g.length)
        }
    }
    return null
}
function eraseCookie(a) {
    createCookie(a, "", -1)
}
(function(a) {
    a.fn.longClick = function(e, c) {
        var d;
        c = c || 500;
        a(this).mousedown(function() {
            d = setTimeout(function() {
                e()
            }, c);
            return false
        });
        a(document).mouseup(function() {
            clearTimeout(d);
            return false
        })
    }
})(jQuery);
if (typeof String.prototype.startsWith != "function") {
    String.prototype.startsWith = function(a) {
        return ( this.indexOf(a) === 0)
    }
}
if (typeof String.prototype.contains != "function") {
    String.prototype.contains = function(a) {
        return ( this.indexOf(a) >= 0)
    }
}
if (typeof String.prototype.endsWith != "function") {
    String.prototype.endsWith = function(a) {
        return ( this.substr(this.length - a.length) === a)
    }
}
function stringToBoolean(a) {
    switch (a.toLowerCase()) {
    case "true":
    case "yes":
    case "1":
        return true;
    case "false":
    case "no":
    case "0":
    case null :
        return false;
    default:
        return Boolean(a)
    }
}
function changeCurrentDB(a, e, c) {
    current_database_file = a;
    $("#note_btn").attr("title", res_string_notebook + ": " + current_database_file);
    if ((typeof (c) != "undefined") && (typeof (e) != "undefined")) {
        var d = e;
        if (e == -2 || e == -1) {
            d = 0
        }
        $("#pages_btn").html(d + "/" + c);
        pageCount = c
    }
    updateNoteNavi()
}
var g_flash_carrd_window = null ;
$(window).on("beforeunload", function(a) {
    if (g_flash_carrd_window) {
        g_flash_carrd_window.close();
        g_flash_carrd_window = null
    }
});
$(window).on("message", receiveMessage);
function receiveMessage(l) {
    var g = l.originalEvent.data.cmd;
    if (g == "rowId") {
        var f = l.originalEvent.data.data;
        var a = l.originalEvent.data.keyword;
        $("#search_text").val(a);
        var c = $("#search_text").val().trim();
        setStatus(1);
        ws.send({
            cmd: "req_go_to_eb_position",
            data: f,
            keyword: c
        })
    } else {
        if (g == "search") {
            var d = l.originalEvent.data.keyword;
            if (d) {
                send_increment = false;
                keep_increment_word = null ;
                setStatus(2);
                if (searchMethod == 4) {
                    showSearchFullDialog()
                }
                g_multi_search_words = null ;
                if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
                    ws.send({
                        cmd: "req_search",
                        data: convertToKana(d),
                        data2: romnih(d),
                        increment: 0
                    })
                } else {
                    ws.send({
                        cmd: "req_search",
                        data: convertToKana(d),
                        increment: 0
                    })
                }
                addHistoryWords(d);
                setMode(1);
                $("#search_text").val(d);
                $("#search_text").trigger("change");
                closeHistoryWordsDialog()
            } else {
                toastr.info(res_string_toastr_keyword_is_empty)
            }
        }
    }
}
var g_flash_card_data = null ;
var g_flash_card_play_status = null ;
function handleWidgetFlashCardEvent(c, a) {
    if (c == "update") {
        g_flash_card_data = a
    } else {
        if (c == "play_status") {
            g_flash_card_play_status = a
        }
    }
    if (!g_flash_carrd_window) {
        return
    }
    if (c == "update") {
        openWidgetFlashCard(a)
    } else {
        if (c == "destroy_widget") {
            g_flash_carrd_window.close();
            g_flash_carrd_window = null
        } else {
            g_flash_carrd_window.postMessage({
                cmd: c,
                data: a
            }, server_uri)
        }
    }
}
function openWidgetFlashCard(c) {
    var d = "flash card";
    if (!g_flash_carrd_window) {
        var a = 150 + (settings_list_font_size - 16);
        g_flash_carrd_window = window.open(loc + "flashcard.html", "FlashCard", config = "height=" + a + ",width=420,toolbar=no,location=no,menubar=no");
        $(g_flash_carrd_window).on("beforeunload", function() {
            g_flash_carrd_window = null
        });
        $(g_flash_carrd_window).on("load", function() {
            g_flash_carrd_window.postMessage({
                cmd: "settings",
                data: {
                    theme: g_theme_type,
                    title_size: listDictionaryTitleSize,
                    locale: locale_language,
                    list_font_size: settings_list_font_size
                }
            }, server_uri);
            if (c) {
                g_flash_carrd_window.postMessage({
                    cmd: "update",
                    data: c
                }, server_uri)
            }
        })
    } else {
        g_flash_carrd_window.postMessage({
            cmd: "update",
            data: c
        }, server_uri)
    }
}
function openpopupvideo(c, a) {
    var d = window.open("", "", config = "height=620,width=820,toolbar=no,location=no,menubar=no");
    html_content = '<!DOCTYPE html> 	<html>  <head><meta name="viewport" content="width=320, initial-scale=1"/> 	<title>' + a + '</title> 	<style type="text/css"> 		body {			background: #333;			text-align: center;			margin-top: 10%;		}		#videoCanvas {			width: 640px;			height: 480px;		}	</style> </head> <body> 	<canvas id="videoCanvas" width="640" height="480"> 		<p> 			Please use a browser that supports the Canvas Element, like 			<a href="http://www.google.com/chrome">Chrome</a>, 			<a href="http://www.mozilla.com/firefox/">Firefox</a>, 			<a href="http://www.apple.com/safari/">Safari</a> or Internet Explorer 10 		</p> 	</canvas> 	<script type="text/javascript" src="./js/jsmpg.js"><\/script> 	<script type="text/javascript"> 		var mpegLoaded = function( player ) {     		console.log("width="+player.width+",height="+player.height);		}; 		var canvas = document.getElementById("videoCanvas"); 		var player = new jsmpeg("' + c + '", {canvas:canvas, autoplay: true, loop: true, onload: mpegLoaded});		canvas.addEventListener("click", function(){ 			if(player.playing) { player.pause(); } else { player.play(); } 		}, false); 		//player.play(); 	<\/script> </body> </html>	';
    d.document.write(html_content);
    d.document.close()
}
var g_search_have_note = false;
var g_content_offset = 0;
function updateTitle() {
    g_search_have_note = false;
    if (ebdic_mode != 2 && g_notebook_row_id >= 0) {
        document.title = "*ebdic";
        g_search_have_note = true
    } else {
        document.title = "ebdic"
    }
}
function beforeShowDialog() {
    if (g_multi_search_dialog != null ) {
        $(g_multi_search_dialog).dialogExtend("minimize")
    }
    if (g_choice_highlight_color_dialog != null ) {
        $(g_choice_highlight_color_dialog).dialogExtend("minimize")
    }
}
function calcHighlightBase() {
    var a = rangy.createRange();
    var c = document.getElementById("wordlist");
    a.selectNode(document.body);
    b = a.getBookmark(c);
    var d = b.end;
    c = document.getElementById("maintool");
    a.selectNode(document.body);
    b = a.getBookmark(c);
    d = b.end + d;
    a.selectNode(document.documentElement);
    b = a.getBookmark(document.head);
    d = b.end + d;
    return d
}
function initAutoComplete() {
    $("#search_text").autocomplete({
        source: g_history_words,
        open: function(a, c) {
            g_autocomplete_show = true;
            $(".ui-autocomplete").scrollTop(0)
        },
        close: function(a, c) {
            g_autocomplete_show = false
        },
        response: function(d, e) {
            var c = 22;
            if (isFirefox) {
                c = 24
            }
            var a = c * e.content.length;
            if (a >= 384) {
                $(".ui-autocomplete").css("height", "384px")
            } else {
                if (a <= 3 * c) {
                    $(".ui-autocomplete").css("height", (3 * c) + "px")
                } else {
                    $(".ui-autocomplete").css("height", a + "px")
                }
            }
        }
    });
    $("#search_text").autocomplete({
        select: function(a, d) {
            var c = d.item.label;
            send_increment = false;
            keep_increment_word = null ;
            setStatus(1);
            if (searchMethod == 4) {
                showSearchFullDialog()
            }
            g_multi_search_words = null ;
            if (g_rom_to_hina == 1 && searchMethod != 4 && searchMethod != 3 && g_multi_rom_to_hina == 1) {
                ws.send({
                    cmd: "req_search",
                    data: convertToKana(c),
                    data2: romnih(c),
                    increment: 0
                })
            } else {
                ws.send({
                    cmd: "req_search",
                    data: convertToKana(c),
                    increment: 0
                })
            }
            addHistoryWords(c);
            setMode(1);
            $("#search_text").autocomplete("disable");
            $("#search_text").val(c);
            $("#search_text").trigger("change");
            window.setTimeout(function() {
                $("#search_text").autocomplete("enable")
            }, 500)
        }
    });
    g_init_autocomplete = true;
    updateAutoComplete(settings_autocomplete)
}
var g_autocomplete_show = false;
var g_init_autocomplete = false;
function toggleAutoComplete() {
    if (!g_autocomplete_show) {
        $("#search_text").focus();
        $("#search_text").autocomplete({
            minLength: 0
        });
        $("#search_text").autocomplete("search", "");
        $("#search_text").autocomplete({
            minLength: 1
        })
    } else {
        $("#search_text").autocomplete("close")
    }
}
function updateAutoComplete(a) {
    if (!g_init_autocomplete) {
        return
    }
    if (a == 1) {
        settings_autocomplete = 1;
        $("#search_text").autocomplete("enable");
        $("#search_text").trigger("change")
    } else {
        settings_autocomplete = 0;
        $("#search_text").autocomplete("disable");
        $("#search_text").trigger("change");
        if (g_autocomplete_show) {
            $("#search_text").autocomplete("close")
        }
    }
}
function updateHighlightColor() {}
var preload_images = new Array();
function setHighlightColorImg(d) {
    if (!g_dynamic_highlight_tool) {
        d = 0
    }
    var c = [res_string_highlight_green, res_string_highlight_orange, res_string_highlight_blue];
    var a = "./img/highlight" + d + ".png";
    $("#highlight_btn_img").attr("src", a);
    $("#highlight_btn").attr("title", c[d])
}
function preloadImage() {
    for (i = 0; i < preloadImage.arguments.length; i++) {
        preload_images[i] = new Image();
        preload_images[i].src = preloadImage.arguments[i]
    }
}
function clearSearchLongClick() {
    if (settings_autocomplete == 0) {
        updateAutoComplete(1);
        g_add_btn_long_press = true;
        toastr.info('"' + settings_autocomplete_label + '" ' + res_string_start_autocomplete);
        ws.send({
            cmd: "req_set_web_setting",
            autocomplete: 1
        })
    } else {
        updateAutoComplete(0);
        g_add_btn_long_press = true;
        toastr.info('"' + settings_autocomplete_label + '" ' + res_string_stop_autocomplete);
        ws.send({
            cmd: "req_set_web_setting",
            autocomplete: 0
        })
    }
}
var g_use_web_search_in_ebdic = 1;
var g_web_search_url = "";
var g_web_search_name = "";
function openWebSearch(c, e) {
    var a = $("#search_text").val();
    if (a.length <= 0) {
        toastr.warning(res_string_toastr_input_empty);
        return
    }
    g_web_search_name = e;
    addHistoryWords(a);
    a = encodeURIComponent(a);
    c = c.replace(/%s/g, a);
    var d = window.open(c, "_blank");
    d.focus()
}
function SendWebSearchList() {
    var f = [];
    var c = [];
    var e = [];
    var a = 0;
    for (a = 0; a < g_web_sites_name_list.length; a++) {
        var d = g_web_sites_name_list[a];
        f.push(d.replace(/%/g, "%25").replace(/:/g, "%3A"))
    }
    for (a = 0; a < g_web_sites_url_list.length; a++) {
        var d = g_web_sites_url_list[a];
        c.push(d.replace(/%/g, "%25").replace(/:/g, "%3A"))
    }
    for (a = 0; a < g_web_sites_font_size_list.length; a++) {
        var d = g_web_sites_font_size_list[a];
        e.push(d)
    }
    setStatus(2);
    ws.send({
        cmd: "req_set_web_search_site_list",
        web_sites_name_list: f.join(":"),
        web_sites_url_list: c.join(":"),
        web_sites_font_size_list: e.join(":")
    })
}
function validateURL(a) {
    var c = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
    return c.test(a)
}
function htmlToPlainText(a) {
    return a.replace(/<br>/g, "\n").replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&amp;/g, "&")
}
function updateListLinkColor() {
    if (theme_type == 1) {
        $("#wordlist a[href]").css("color", "#0000ff")
    } else {
        $("#wordlist a[href]").css("color", "#33b5e5")
    }
}
function updateCSS() {
    if (theme_type == 1) {
        $(".keyword").css("color", "#BB1B15");
        $("#content.ebdicDiv b").css("color", "#BB1B15")
    } else {
        $(".keyword").css("color", "#F77400");
        $("#content.ebdicDiv b").css("color", "#F77400")
    }
    $("#wordlist ref").addClass("list_ref")
}
function enableParagraphBtn(a) {
    if (a) {
        $("#prev_paragraph_btn").attr("disabled", false);
        $("#next_paragraph_btn").attr("disabled", false)
    } else {
        $("#prev_paragraph_btn").attr("disabled", true);
        $("#next_paragraph_btn").attr("disabled", true)
    }
}
function IframeContent() {
    var a = document.getElementById("content_iframe");
    if (!a) {
        return
    }
}
function initIframe() {
    var a = document.getElementById("content_iframe");
    if (!a) {
        return
    }
    a.onload = function() {
        if (this.getAttribute("is-reset") == "1") {
            this.style.opacity = 0;
            this.style.display = "block";
            var c = this.getAttribute("src-url");
            var d = "<html><body><br><br><div style='margin: 0 auto; text-align: center;'><a target='_blank' href='" + c + "'>" + c + "</a></div></body></html>";
            ifrm = (a.contentWindow) ? a.contentWindow : (a.contentDocument.document) ? a.contentDocument.document : a.contentDocument;
            ifrm.document.open();
            ifrm.document.write(d);
            ifrm.document.close();
            this.setAttribute("src", c);
            this.setAttribute("is-reset", 0)
        } else {
            this.style.opacity = "1"
        }
    }
}
function changeIFrameUrl(a) {
    var c = document.getElementById("content_iframe");
    if (!c) {
        return
    }
    c.style.display = "none";
    c.setAttribute("is-reset", 1);
    c.setAttribute("src", "about:blank");
    c.setAttribute("src-url", a)
}
(function(a) {
    a.fn.hasScrollBar = function() {
        return this.get(0).scrollHeight > this.height()
    }
})(jQuery);
function getScrollBarWidth() {
    var d = document.createElement("p");
    d.style.width = "100%";
    d.style.height = "200px";
    var e = document.createElement("div");
    e.style.position = "absolute";
    e.style.top = "0px";
    e.style.left = "0px";
    e.style.visibility = "hidden";
    e.style.width = "200px";
    e.style.height = "150px";
    e.style.overflow = "hidden";
    e.appendChild(d);
    document.body.appendChild(e);
    var c = d.offsetWidth;
    e.style.overflow = "scroll";
    var a = d.offsetWidth;
    if (c == a) {
        a = e.clientWidth
    }
    document.body.removeChild(e);
    return ( c - a)
}
jQuery.ui.autocomplete.prototype._resizeMenu = function() {
    var a = this.menu.element;
    a.outerWidth(this.element.outerWidth())
}
;
function checkSearchHighlightExist(a) {
    if (!g_searchModeAddHighlight) {
        return false
    }
    if (ebdic_mode == 2) {
        return false
    }
    if (g_notebook_row_id >= 0) {
        return false
    }
    if (!highlighter) {
        return false
    }
    if (!g_highlight_data_string || g_highlight_data_string.length <= 0) {
        return false
    }
    if (a && a == 1) {
        return true
    }
    showConfirmClearSearchModeHighlightDialog();
    return true
}
var go_note_status = 0;
function setDicNotExist() {
    g_go_page = -1;
    g_go_offset = -1;
    g_go_book_index = -1;
    g_go_db_pos = -1;
    g_go_note = 0;
    g_go_history = 0;
    g_go_position = "";
    g_go_keyword = "";
    g_go_db_name = "";
    g_go_custom_word_row_id = -1;
    go_history = 0;
    g_on_notebook_page = false;
    g_note_page = -1;
    g_note_offset = -1;
    g_note_book_index = -1;
    g_note_keyword = "";
    g_note_db_name = "";
    g_note_custom_word_row_id = -1;
    go_note_status = 1
}
function updateClickSearchIcon() {
    if (g_click_search == 1) {
        $("#content").css("cursor", "alias")
    } else {
        $("#content").css("cursor", "default")
    }
}
function showContent(d) {
    var f = document.write;
    var e = "";
    document.write = function(l) {
        if (e != l) {
            e += l
        }
    }
    ;
    $("#content").html(d);
    document.write = f;
    if (e) {
        var g = $(e);
        var a = window.onload;
        var c = setTimeout(function() {
            if (window.onload != a) {
                window.onload();
                window.onload = a
            }
            clearTimeout(c);
            c = null
        }, 200);
        $("#content").append(g)
    }
}
;